/**
 * 天干速查表
 */
export declare const HEAVENLY_STEMS: readonly ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"];
/**
 * 地支速查表
 */
export declare const EARTHLY_BRANCHES: readonly ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"];
/** 十二生肖（按地支顺序） */
export declare const ZODIAC: readonly ["鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪"];
/**
 * 每月地支（按月序）
 */
export declare const MONTHLY_EARTHLY_BRANCHES: readonly ["寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥", "子", "丑"];
/** 五虎遁速查表，按天干从甲开始 */
export declare const FIVE_TIGER: string[];
