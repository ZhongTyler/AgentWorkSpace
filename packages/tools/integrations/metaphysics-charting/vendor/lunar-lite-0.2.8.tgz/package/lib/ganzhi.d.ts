import { HeavenlyStemAndEarthlyBranchDate, Options } from "./types";
/**
 * 通过农历获取生辰干支
 *
 * @param dateStr 农历日期 YYYY-MM-DD
 * @param timeIndex 时辰索引【0～12】
 * @param isLeap 是否为闰月
 * @returns HeavenlyStemAndEarthlyBranchResult
 */
export declare const getHeavenlyStemAndEarthlyBranchByLunarDate: (dateStr: string, timeIndex: number, isLeap?: boolean, options?: Options) => HeavenlyStemAndEarthlyBranchDate;
/**
 * 将阳历转化为干支纪年
 *
 * @param dateStr 公历日期 YYYY-MM-DD
 * @param timeIndex 时辰索引【0～12】
 * @returns HeavenlyStemAndEarthlyBranchResult
 */
export declare const getHeavenlyStemAndEarthlyBranchBySolarDate: (dateStr: string | Date, timeIndex: number, options?: Options) => HeavenlyStemAndEarthlyBranchDate;
