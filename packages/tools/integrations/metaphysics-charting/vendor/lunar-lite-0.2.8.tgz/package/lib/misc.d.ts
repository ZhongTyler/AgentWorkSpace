import { EarthlyBranch } from "./types";
/**
 * 获取星座
 *
 * @param  solarDateStr [description]
 * @return 星座
 */
export declare const getSign: (solarDateStr: string) => string;
/**
 * 通过年支获取生肖
 *
 * @param earthlyBranchOfYear 年支
 * @example
 * const zodiac = calendar.getZodiac("卯") ;// zodiac='兔'
 */
export declare const getZodiac: (earthlyBranchOfYear: EarthlyBranch) => "鼠" | "牛" | "虎" | "兔" | "龙" | "蛇" | "马" | "羊" | "猴" | "鸡" | "狗" | "猪";
/**
 * 按照传入阳历日期获取该月农历月份天数
 *
 * @param solarDateStr 阳历日期
 * @returns {number} 日期天数
 */
export declare const getTotalDaysOfLunarMonth: (solarDateStr: string) => number;
