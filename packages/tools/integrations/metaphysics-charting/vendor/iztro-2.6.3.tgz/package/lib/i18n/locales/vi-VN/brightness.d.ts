declare const _default: {
    readonly miao: "Miếu";
    readonly wang: "Vượng";
    readonly de: "Đắc";
    readonly li: "Lợi";
    readonly ping: "Bình";
    readonly bu: "Bất";
    readonly xian: "Hãm";
};
export default _default;
