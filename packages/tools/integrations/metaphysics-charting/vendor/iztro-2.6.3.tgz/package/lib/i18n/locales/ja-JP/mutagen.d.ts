declare const _default: {
    readonly sihuaLu: "禄";
    readonly sihuaQuan: "権";
    readonly sihuaKe: "科";
    readonly sihuaJi: "忌";
};
export default _default;
