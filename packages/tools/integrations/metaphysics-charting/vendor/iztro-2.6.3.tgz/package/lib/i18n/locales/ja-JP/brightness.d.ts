declare const _default: {
    readonly miao: "廟";
    readonly wang: "旺";
    readonly de: "得";
    readonly li: "利";
    readonly ping: "平";
    readonly bu: "不";
    readonly xian: "陥";
};
export default _default;
