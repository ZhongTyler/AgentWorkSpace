declare const _default: {
    readonly soulPalace: "命宮";
    readonly bodyPalace: "身宮";
    readonly siblingsPalace: "兄弟";
    readonly spousePalace: "夫妻";
    readonly childrenPalace: "子女";
    readonly wealthPalace: "財帛";
    readonly healthPalace: "疾厄";
    readonly surfacePalace: "遷移";
    readonly friendsPalace: "奴僕";
    readonly careerPalace: "官禄";
    readonly propertyPalace: "田宅";
    readonly spiritPalace: "福徳";
    readonly parentsPalace: "父母";
    readonly originalPalace: "来因";
};
export default _default;
