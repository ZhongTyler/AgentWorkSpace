package xiaohongshu

import "testing"

func TestFavoriteBoardsURL(t *testing.T) {
	got, err := favoriteBoardsURL("https://www.xiaohongshu.com/user/profile/abc?tab=fav")
	if err != nil {
		t.Fatalf("favoriteBoardsURL returned an error: %v", err)
	}
	want := "https://www.xiaohongshu.com/user/profile/abc?subTab=board&tab=fav"
	if got != want {
		t.Fatalf("favoriteBoardsURL() = %q, want %q", got, want)
	}
}

func TestValidateFavoriteAlbumID(t *testing.T) {
	for _, albumID := range []string{"6518ee49000000001701b88c", "album_123-abc"} {
		if err := validateFavoriteAlbumID(albumID); err != nil {
			t.Fatalf("validateFavoriteAlbumID(%q) returned an error: %v", albumID, err)
		}
	}

	for _, albumID := range []string{"", "album/id", "album?x=1"} {
		if err := validateFavoriteAlbumID(albumID); err == nil {
			t.Fatalf("validateFavoriteAlbumID(%q) succeeded, want an error", albumID)
		}
	}
}
