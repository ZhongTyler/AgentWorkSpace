package xiaohongshu

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"strings"
	"time"

	"github.com/go-rod/rod"
	"github.com/sirupsen/logrus"
)

// FavoriteAlbum 是当前登录账号收藏页中的一个专辑。
//
// 专辑只返回可用于后续读取的公开元数据；不会执行新建、删除或调整专辑等写操作。
type FavoriteAlbum struct {
	ID        string `json:"id"`
	Name      string `json:"name"`
	NoteCount int    `json:"note_count"`
}

// FavoriteAlbumsResponse 是收藏专辑列表的只读响应。
type FavoriteAlbumsResponse struct {
	Albums []FavoriteAlbum `json:"albums"`
}

// FavoriteAlbumFeed 是专辑中一条笔记的卡片信息。
// XsecToken 仅供调用方立即转交给 get_feed_detail；调用方不得把它写入资料或日志。
type FavoriteAlbumFeed struct {
	FeedID         string `json:"feed_id"`
	XsecToken      string `json:"xsec_token"`
	Title          string `json:"title"`
	Type           string `json:"type"`
	AuthorID       string `json:"author_id"`
	AuthorNickname string `json:"author_nickname"`
	LikedCount     string `json:"liked_count"`
	CommentCount   string `json:"comment_count"`
	CollectedCount string `json:"collected_count"`
	CoverURL       string `json:"cover_url,omitempty"`
}

// FavoriteAlbumFeedsResponse 是单个收藏专辑已加载笔记的只读响应。
// 服务会尝试滚动加载后续页面；若页面持续停滞或达到安全上限，HasMore 仍会保留为 true。
type FavoriteAlbumFeedsResponse struct {
	Album   FavoriteAlbum       `json:"album"`
	Feeds   []FavoriteAlbumFeed `json:"feeds"`
	Cursor  string              `json:"cursor,omitempty"`
	HasMore bool                `json:"has_more"`
}

type favoriteAlbumPayload struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Total int    `json:"total"`
}

type favoriteAlbumFeedPayload struct {
	NoteID       string       `json:"noteId"`
	XsecToken    string       `json:"xsecToken"`
	DisplayTitle string       `json:"displayTitle"`
	Type         string       `json:"type"`
	User         User         `json:"user"`
	InteractInfo InteractInfo `json:"interactInfo"`
	Cover        Cover        `json:"cover"`
}

// FavoriteAlbumAction 通过当前已登录账号的个人页读取收藏专辑。
type FavoriteAlbumAction struct {
	page *rod.Page
}

const (
	maxFavoriteAlbumLoadRounds = 24
	favoriteAlbumStagnantLimit = 3
)

func NewFavoriteAlbumAction(page *rod.Page) *FavoriteAlbumAction {
	return &FavoriteAlbumAction{page: page.Timeout(60 * time.Second)}
}

// GetMyFavoriteAlbumsViaSidebar 读取当前账号收藏页的专辑列表。
func (a *FavoriteAlbumAction) GetMyFavoriteAlbumsViaSidebar(ctx context.Context) (*FavoriteAlbumsResponse, error) {
	page := a.page.Context(ctx).Timeout(60 * time.Second)
	if err := NewNavigate(page).ToProfilePage(ctx); err != nil {
		return nil, fmt.Errorf("failed to navigate to profile page via sidebar: %w", err)
	}

	page.MustWaitStable()
	boardsURL, err := favoriteBoardsURL(page.MustInfo().URL)
	if err != nil {
		return nil, err
	}
	page.MustNavigate(boardsURL)
	page.MustWaitStable()

	return extractFavoriteAlbums(page)
}

// GetFavoriteAlbumFeeds 读取指定专辑的笔记卡片，并尝试自动加载后续条目。
func (a *FavoriteAlbumAction) GetFavoriteAlbumFeeds(ctx context.Context, albumID string) (*FavoriteAlbumFeedsResponse, error) {
	if err := validateFavoriteAlbumID(albumID); err != nil {
		return nil, err
	}

	page := a.page.Context(ctx).Timeout(60 * time.Second)
	page.MustNavigate("https://www.xiaohongshu.com/board/" + url.PathEscape(albumID))
	page.MustWaitStable()
	// MustWait 的回调必须返回布尔值；直接返回响应式 board 对象会触发 CDP 的循环引用序列化错误。
	page.MustWait(`() => !!(window.__INITIAL_STATE__ && window.__INITIAL_STATE__.board)`)
	if err := loadAllFavoriteAlbumFeeds(page, albumID); err != nil {
		return nil, err
	}

	return extractFavoriteAlbumFeeds(page, albumID)
}

type favoriteAlbumFeedState struct {
	Count   int  `json:"count"`
	HasMore bool `json:"hasMore"`
}

func readFavoriteAlbumFeedState(page *rod.Page, albumID string) (favoriteAlbumFeedState, error) {
	quotedAlbumID, err := json.Marshal(albumID)
	if err != nil {
		return favoriteAlbumFeedState{}, fmt.Errorf("failed to encode album_id: %w", err)
	}

	result, err := page.Eval(fmt.Sprintf(`() => {
		const board = window.__INITIAL_STATE__ && window.__INITIAL_STATE__.board;
		if (!board) return "";
		const unwrap = (value) => value && (value.value !== undefined ? value.value : value._value);
		const feedMap = unwrap(board.boardFeedsMap) || {};
		const feeds = feedMap[%s] || {};
		return JSON.stringify({count: Array.isArray(feeds.notes) ? feeds.notes.length : 0, hasMore: !!feeds.hasMore});
	}`, string(quotedAlbumID)))
	if err != nil {
		return favoriteAlbumFeedState{}, fmt.Errorf("failed to read favorite album feed state: %w", err)
	}
	if result.Value.String() == "" {
		return favoriteAlbumFeedState{}, fmt.Errorf("favorite album feed state not found")
	}

	var state favoriteAlbumFeedState
	if err := json.Unmarshal([]byte(result.Value.String()), &state); err != nil {
		return favoriteAlbumFeedState{}, fmt.Errorf("failed to unmarshal favorite album feed state: %w", err)
	}
	return state, nil
}

func loadAllFavoriteAlbumFeeds(page *rod.Page, albumID string) error {
	lastCount := -1
	stagnantRounds := 0

	for round := 0; round < maxFavoriteAlbumLoadRounds; round++ {
		state, err := readFavoriteAlbumFeedState(page, albumID)
		if err != nil {
			return err
		}
		if !state.HasMore {
			return nil
		}
		if state.Count == lastCount {
			stagnantRounds++
		} else {
			stagnantRounds = 0
			lastCount = state.Count
		}
		if stagnantRounds >= favoriteAlbumStagnantLimit {
			logrus.Warnf("收藏专辑笔记加载停滞，保留当前 %d 条；请稍后重试", state.Count)
			return nil
		}

		if _, err := page.Eval(`() => {
			const height = Math.max(window.innerHeight || 800, 800);
			window.scrollBy(0, height * 0.9);
			window.scrollTo(0, document.documentElement.scrollHeight);
			return true;
		}`); err != nil {
			return fmt.Errorf("failed to scroll favorite album page: %w", err)
		}
		time.Sleep(700 * time.Millisecond)
		page.MustWaitStable()
	}

	state, err := readFavoriteAlbumFeedState(page, albumID)
	if err == nil && state.HasMore {
		logrus.Warnf("收藏专辑笔记达到加载上限，当前读取 %d 条", state.Count)
	}
	return nil
}

func favoriteBoardsURL(profileURL string) (string, error) {
	parsed, err := url.Parse(profileURL)
	if err != nil {
		return "", fmt.Errorf("invalid profile URL: %w", err)
	}
	if parsed.Scheme == "" || parsed.Host == "" {
		return "", fmt.Errorf("invalid profile URL %q", profileURL)
	}

	query := parsed.Query()
	query.Set("tab", "fav")
	query.Set("subTab", "board")
	parsed.RawQuery = query.Encode()
	return parsed.String(), nil
}

func validateFavoriteAlbumID(albumID string) error {
	if albumID == "" {
		return fmt.Errorf("album_id 不能为空")
	}
	for _, r := range albumID {
		if !(r >= 'a' && r <= 'z') && !(r >= 'A' && r <= 'Z') && !(r >= '0' && r <= '9') && r != '_' && r != '-' {
			return fmt.Errorf("album_id 只能包含字母、数字、下划线或连字符")
		}
	}
	return nil
}

func extractFavoriteAlbums(page *rod.Page) (*FavoriteAlbumsResponse, error) {
	result := page.MustEval(`() => {
		const board = window.__INITIAL_STATE__ && window.__INITIAL_STATE__.board;
		if (!board) return "";
		const unwrap = (value) => value && (value.value !== undefined ? value.value : value._value);
		const candidates = [unwrap(board.userBoardList), unwrap(board.boardListData)];
		const albums = candidates.find((value) => Array.isArray(value)) || [];
		return JSON.stringify(albums);
	}`).String()
	if result == "" {
		return nil, fmt.Errorf("board.userBoardList.value not found in __INITIAL_STATE__")
	}

	var payloads []favoriteAlbumPayload
	if err := json.Unmarshal([]byte(result), &payloads); err != nil {
		return nil, fmt.Errorf("failed to unmarshal favorite albums: %w", err)
	}

	response := &FavoriteAlbumsResponse{Albums: make([]FavoriteAlbum, 0, len(payloads))}
	for _, payload := range payloads {
		if payload.ID == "" || strings.TrimSpace(payload.Name) == "" {
			continue
		}
		response.Albums = append(response.Albums, FavoriteAlbum{
			ID:        payload.ID,
			Name:      payload.Name,
			NoteCount: payload.Total,
		})
	}
	return response, nil
}

func extractFavoriteAlbumFeeds(page *rod.Page, albumID string) (*FavoriteAlbumFeedsResponse, error) {
	quotedAlbumID, err := json.Marshal(albumID)
	if err != nil {
		return nil, fmt.Errorf("failed to encode album_id: %w", err)
	}

	result := page.MustEval(fmt.Sprintf(`() => {
		const board = window.__INITIAL_STATE__ && window.__INITIAL_STATE__.board;
		if (!board) return "";
		const unwrap = (value) => value && (value.value !== undefined ? value.value : value._value);
		const details = unwrap(board.boardDetails) || {};
		const feedMap = unwrap(board.boardFeedsMap) || {};
		const feeds = feedMap[%s] || {};
		return JSON.stringify({album: details, feeds: feeds.notes || [], cursor: feeds.cursor || "", hasMore: !!feeds.hasMore});
	}`, string(quotedAlbumID))).String()
	if result == "" {
		return nil, fmt.Errorf("board details not found in __INITIAL_STATE__")
	}

	var payload struct {
		Album   favoriteAlbumPayload       `json:"album"`
		Feeds   []favoriteAlbumFeedPayload `json:"feeds"`
		Cursor  string                     `json:"cursor"`
		HasMore bool                       `json:"hasMore"`
	}
	if err := json.Unmarshal([]byte(result), &payload); err != nil {
		return nil, fmt.Errorf("failed to unmarshal favorite album feeds: %w", err)
	}
	if payload.Album.ID == "" {
		return nil, fmt.Errorf("未找到收藏专辑 %q", albumID)
	}

	response := &FavoriteAlbumFeedsResponse{
		Album: FavoriteAlbum{
			ID:        payload.Album.ID,
			Name:      payload.Album.Name,
			NoteCount: payload.Album.Total,
		},
		Feeds:   make([]FavoriteAlbumFeed, 0, len(payload.Feeds)),
		Cursor:  payload.Cursor,
		HasMore: payload.HasMore,
	}
	for _, feed := range payload.Feeds {
		if feed.NoteID == "" || feed.XsecToken == "" {
			continue
		}
		nickname := feed.User.Nickname
		if nickname == "" {
			nickname = feed.User.NickName
		}
		response.Feeds = append(response.Feeds, FavoriteAlbumFeed{
			FeedID:         feed.NoteID,
			XsecToken:      feed.XsecToken,
			Title:          feed.DisplayTitle,
			Type:           feed.Type,
			AuthorID:       feed.User.UserID,
			AuthorNickname: nickname,
			LikedCount:     feed.InteractInfo.LikedCount,
			CommentCount:   feed.InteractInfo.CommentCount,
			CollectedCount: feed.InteractInfo.CollectedCount,
			CoverURL:       feed.Cover.URLPre,
		})
	}
	return response, nil
}
