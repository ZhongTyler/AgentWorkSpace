# Changelog

All notable changes to this project. Each entry links to its full per-version file in [changelog/](changelog/).

## [0.5.21](changelog/0.5.x/0.5.21.md) — 2026-10-05

Framework ^0.13.6 → ^0.13.12: tool error results now end with a request ID, the Docker image installs dependencies in a build-platform deps stage, and server.json launches with npx.

## [0.5.20](changelog/0.5.x/0.5.20.md) — 2026-09-23 · 🛡️ Security

Upstream text is fenced in content[] so a comment or highlight body can no longer pass for server-authored lines, titles are entity-decoded instead of HTML-stripped, each HN link renders once as its full URL, and typed placeholder text survives stripping.

## [0.5.19](changelog/0.5.x/0.5.19.md) — 2026-09-23

hn_get_thread gains a resumable cursor, root relationships, and poll options; hn_get_stories/hn_get_thread/hn_get_user report failed item fetches instead of dropping them, and a 429's Retry-After now reaches the recovery hint.

## [0.5.18](changelog/0.5.x/0.5.18.md) — 2026-09-23

hn_search_content gains filter-only and story-scoped search plus ISO 8601 date validation and minPoints guarding against unscored types; the feed, thread, and search tools now distinguish terminal pages from truncation.

## [0.5.17](changelog/0.5.x/0.5.17.md) — 2026-09-19

Adopted mcp-ts-core ^0.13.6: the server declares stateless session mode in source, argument rejections carry a reason and a schema-derived recovery hint, and tool errors close with their reason and retryable status.

## [0.5.16](changelog/0.5.x/0.5.16.md) — 2026-09-13

Adopted mcp-ts-core ^0.13.0 (blank/unsubstituted env vars now read as unset, dev skills moved to framework-skills/) plus a matching HN_CONCURRENCY_LIMIT fix and routine dependency bumps

## [0.5.15](changelog/0.5.x/0.5.15.md) — 2026-09-04 · 🛡️ Security

Cleared 6 transitive advisories in fast-uri and qs via overrides; adopted mcp-ts-core's retried upstream 500s and cancellation classification

## [0.5.14](changelog/0.5.x/0.5.14.md) — 2026-08-24

MCP SDK v2 compatibility, explicit stateless HTTP serving, and current framework-managed tooling

## [0.5.13](changelog/0.5.x/0.5.13.md) — 2026-07-28

hn_get_user gains submissionOffset to page through a user's full submission history; hn_search_content gains a compact view that drops duplicated body text; upstream HTTP failures now classify onto a typed reason and recovery hint instead of a raw fetch error.

## [0.5.12](changelog/0.5.x/0.5.12.md) — 2026-07-28

Reject fractional and blank/whitespace-only tool inputs; hn_search_content reports Algolia's own page count instead of a recomputation; hn_get_user's Firebase username segment is percent-encoded; hn_get_thread omits totalAvailable instead of rendering undefined. @cyanheads/mcp-ts-core ^0.10.9 → ^0.11.0.

## [0.5.11](changelog/0.5.x/0.5.11.md) — 2026-06-20

@cyanheads/mcp-ts-core ^0.10.6 → ^0.10.9 — check-dependency-specifiers + plugin-manifest devcheck guards, ctx.content collector, canvas SQL gate classification; dropped unused direct hono dependency; TypeScript 6 adopted

## [0.5.10](changelog/0.5.x/0.5.10.md) — 2026-06-12

@cyanheads/mcp-ts-core ^0.9.21 → ^0.10.6 — truncation enrichment signals on every tool, explicit server identity, hardened MCPB bundle packaging

## [0.5.9](changelog/0.5.x/0.5.9.md) — 2026-06-04

hn_get_user: surface submission pagination notice via enrichment block

## [0.5.8](changelog/0.5.x/0.5.8.md) — 2026-06-02

@cyanheads/mcp-ts-core ^0.9.16 → ^0.9.21 — per-request log context fix, secret-stripped error messages, withRetry fail-fast on non-retryable errors

## [0.5.7](changelog/0.5.x/0.5.7.md) — 2026-05-30

enrichment adoption — ranked-feed and search tools surface result context (counts, query echo, empty-result guidance) in a typed enrichment block reaching both structuredContent JSON and content[] markdown trailer

## [0.5.6](changelog/0.5.x/0.5.6.md) — 2026-05-28

@cyanheads/mcp-ts-core ^0.9.6 → ^0.9.13: 413 body cap, HTTP session-init gate, quieter client-error logging, GET /mcp surfaces keywords; dep refresh; package.json keyword additions

## [0.5.5](changelog/0.5.x/0.5.5.md) — 2026-05-23

Fix duplicate `hono` installs causing `@hono/otel` crash on every HTTP request. `hono ^4.12.22` added as direct dependency to force deduplication.

## [0.5.4](changelog/0.5.x/0.5.4.md) — 2026-05-23

Maintenance. `@cyanheads/mcp-ts-core ^0.9.1 → ^0.9.6`, `zod` added as explicit dependency. `manifest.json` + `.mcpbignore` scaffolded for MCPB bundle support. Install badges added to README. New scripts: `list-skills`, `lint:packaging`, `bundle`, `audit:refresh`.

## [0.5.3](changelog/0.5.x/0.5.3.md) — 2026-05-21

Field-test refinements to two `format()` output paths. `hn_get_stories` now distinguishes offset-past-end from genuinely-empty feeds. `hn_get_user` no longer duplicates the item type when rendering a typeless submission. Also migrates the project to the framework's directory-based changelog convention.

## [0.5.2](changelog/0.5.x/0.5.2.md) — 2026-05-16

Maintenance + capability release. Adopts the MCP spec server-level `instructions` field on `createApp()` so clients forward orientation text (item types, ID reuse, case-sensitive usernames, sparsity) to the model. Framework `^0.8.20 → ^0.9.1` brings Workers `nodejs_compat` fix, SSRF hardening, gated `tasks` capability, build-time-only lint.

## [0.5.1](changelog/0.5.x/0.5.1.md) — 2026-05-11

`hn_get_thread` schema patch: `comments[].isOp` and `omitted` are now absence-by-default. `isOp` changed `z.boolean()` → `z.literal(true).optional()`; `omitted` made optional. Wire payload shrinks on the common case (no OP reply, no moderation truncation); `format()` output unchanged.

## [0.5.0](changelog/0.5.x/0.5.0.md) — 2026-05-11

Enrichment release. Four new fields: `domain` on stories/search hits (hostname extracted from `url`), `highlights` on search hits (Algolia `_highlightResult` with `<em>…</em>` preserved), `isOp` on thread comments (author equals root item author), `omitted: { deleted, dead }` counters on threads. Closes #1, #2, #3, #4.

## [0.4.3](changelog/0.4.x/0.4.3.md) — 2026-05-11 · 🛡️ Security

Maintenance. Framework `^0.8.17 → ^0.8.20` (bundles `hono` security patches GHSA-p77w-8qqv-26rm / GHSA-qp7p-654g-cw7p / GHSA-hm8q-7f3q-5f36). Engine bumps `bun >=1.3` / `node >=24`, Dockerfile base `oven/bun:1.3`. `@hono/otel` + `pino-pretty` moved to devDependencies. New `api-telemetry` skill.

## [0.4.2](changelog/0.4.x/0.4.2.md) — 2026-05-05

Bundles two releases. (1) `hn_search_content` `dateRange` rejects unparseable dates via Zod `.refine()`. (2) Framework `^0.7.0 → ^0.8.17` brings the typed-error-contract API; adopted contracts on `hn_get_thread` (`item_not_found`) and `hn_get_user` (`user_not_found`); search empty-result message names applied filters.

## [0.4.0](changelog/0.4.x/0.4.0.md) — 2026-04-24

Framework `^0.5.3 → ^0.7.0` (20 releases). `.describe()` now required recursively on array-element schemas — added to `stories[]`, `comments[]`, `submissions[]`, `hits[]`. New skills `api-linter`, `release-and-publish`, `security-pass`. `.github/ISSUE_TEMPLATE/` scaffolded.

## [0.3.0](changelog/0.3.x/0.3.0.md) — 2026-04-20

Framework `^0.4.1 → ^0.5.3` adopts the `format-parity` lint rule. `format()` output expanded across all four tools: meta lines lead with `id:N`, dual ISO + Unix timestamps, comment depth/parent annotations, indent capped at 10 levels.

## [0.2.0](changelog/0.2.x/0.2.0.md) — 2026-04-19

Upstream resilience. `withRetry` + `fetchWithTimeout` wrap HN Firebase + Algolia fetches with 10s per-request timeout, HTML-error-body detection (for rate-limited 200 OK responses), and `ctx.signal` cancellation. `hn_get_stories` schema fields made optional to preserve upstream sparsity. Framework `^0.2.10 → ^0.4.1`.

## [0.1.9](changelog/0.1.x/0.1.9.md) — 2026-03-30

Framework `^0.2.7 → ^0.2.10`. Biome patch. Skill refreshes — `add-tool` v1.1 (tool response design), `add-resource` v1.1 (tool coverage guidance), `design-mcp-server` v2.1 (live API probing, batch input design, resilience planning).

## [0.1.8](changelog/0.1.x/0.1.8.md) — 2026-03-28

Framework patch `^0.2.6 → ^0.2.7`.

## [0.1.7](changelog/0.1.x/0.1.7.md) — 2026-03-28

Framework patch `^0.2.4 → ^0.2.6`.

## [0.1.6](changelog/0.1.x/0.1.6.md) — 2026-03-28 · 🛡️ Security

Framework `^0.1.28 → ^0.2.4`. `format()` output overhauled across all tools (markdown headers, IDs, dates, actionable hints). Security overrides for `path-to-regexp`, `picomatch`, `brace-expansion`. New `report-issue-framework` / `report-issue-local` skills.

## [0.1.5](changelog/0.1.x/0.1.5.md) — 2026-03-23 · ⚠️ Breaking

Tool rename pass: all four tools gain `hn_` namespace prefix (`get_stories` → `hn_get_stories`, `get_thread` → `hn_get_thread`, `get_user` → `hn_get_user`, `search_hn` → `hn_search_content`). Breaking for any caller using the unprefixed names.

## [0.1.4](changelog/0.1.x/0.1.4.md) — 2026-03-23

TypeScript major `^5.9.3 → ^6.0.2`. Framework `^0.1.25 → ^0.1.28`. Vitest patch. `remotes` entry on `server.json` with public streamable-http URL. `tsconfig.json` simplified (relative path alias).

## [0.1.3](changelog/0.1.x/0.1.3.md) — 2026-03-21

Framework patch `^0.1.23 → ^0.1.25`.

## [0.1.2](changelog/0.1.x/0.1.2.md) — 2026-03-21

Framework patch `^0.1.23 → ^0.1.24`. Publishing instructions added to CLAUDE.md.

## [0.1.1](changelog/0.1.x/0.1.1.md) — 2026-03-21

Renamed package to scoped `@cyanheads/hn-mcp-server`. Conditional OpenTelemetry install via `OTEL_ENABLED` Docker build arg. Framework `^0.1.22 → ^0.1.23`.

## [0.1.0](changelog/0.1.x/0.1.0.md) — 2026-03-21

Initial release. Four read-only tools (`hn_get_stories`, `hn_get_thread`, `hn_get_user`, `hn_search_content`) over HN Firebase + Algolia. Concurrency-limited batch fetching, HTML stripping with code-block/link preservation, stdio + streamable-http transports.
