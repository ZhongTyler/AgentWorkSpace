import type { Client } from '@modelcontextprotocol/client';
import type { CallToolResult, McpServer, ServerContext, Tool } from '@modelcontextprotocol/server';
import { logger } from './utils/logger.js';
import { logGradioEvent } from './utils/query-logger.js';
import { z } from 'zod';
import { gradioMetrics, getMetricsSafeName } from './utils/gradio-metrics.js';
import { createGradioToolName } from './utils/gradio-utils.js';
import { callGradioTool, applyResultPostProcessing, type GradioToolCallOptions } from './utils/gradio-tool-caller.js';
import { parseDisabledTools } from './utils/disabled-tools.js';
import { createProgressRelay } from './utils/progress-relay.js';
import { registerProxyAppResource, rewriteProxyAppToolMeta } from './utils/proxy-apps.js';
import { createRemoteToolAnnotations } from './utils/remote-tool-annotations.js';
import * as hfMcp from '@llmindset/hf-mcp';

// Define types for JSON Schema
interface JsonSchemaProperty {
	type?: string | string[];
	description?: string;
	default?: unknown;
	enum?: unknown[];
	[key: string]: unknown;
}

interface JsonSchema {
	type?: string | string[];
	properties?: Record<string, JsonSchemaProperty>;
	required?: string[];
	[key: string]: unknown;
}

// Define type for array format schema
export interface EndpointConnection {
	endpointId: string;
	originalIndex: number;
	client: Client | null; // Will be null when using schema-only approach
	tools: Tool[];
	name?: string;
	emoji?: string;
	mcpUrl?: string; // Store the MCP URL for lazy connection during tool calls
	isPrivate?: boolean;
}

interface RegisterRemoteToolsOptions {
	stripImageContent?: boolean;
}

export function parseSchemaResponse(
	schemaResponse: unknown,
	endpointId: string,
	subdomain: string
): Array<{ name: string; description?: string; inputSchema: JsonSchema; _meta?: Record<string, unknown> }> {
	try {
		const parsed = hfMcp.parseGradioSchemaResponse(schemaResponse);
		gradioMetrics.recordSchemaFormat(parsed.format);

		logger.debug(
			{
				endpointId,
				toolCount: parsed.tools.length,
				tools: parsed.tools.map((t) => t.name),
				format: parsed.format,
			},
			'Retrieved schema'
		);

		return parsed.tools as Array<{
			name: string;
			description?: string;
			inputSchema: JsonSchema;
			_meta?: Record<string, unknown>;
		}>;
	} catch (error) {
		if (error instanceof Error && error.message.includes('no tools found')) {
			// Preserve legacy error wording expected by tests/callers
			throw new Error('No tools found in schema', { cause: error });
		}
		logger.error(
			{
				endpointId,
				subdomain,
				schemaType: typeof schemaResponse,
				error: error instanceof Error ? error.message : String(error),
			},
			'Invalid schema format'
		);
		throw error;
	}
}

/**
 * Creates the display information for a tool
 */
function createToolDisplayInfo(connection: EndpointConnection, tool: Tool): { title: string; description: string } {
	const displayName = connection.name || 'Unknown Space';
	const title = `${displayName} - ${tool.name}${connection.emoji ? ` ${connection.emoji}` : ''}`;
	const description = tool.description
		? `${tool.description} (from ${displayName})`
		: `${tool.name} tool from ${displayName}`;
	return { title, description };
}

/**
 * Creates the tool handler function
 */
function createToolHandler(
	connection: EndpointConnection,
	tool: Tool,
	outwardFacingName: string,
	hfToken?: string,
	sessionInfo?: {
		clientSessionId?: string;
		requestId?: string;
		protocolEra?: 'legacy' | 'modern';
		protocolVersion?: string;
		clientCapabilities?: Record<string, unknown>;
		userHash?: string;
		isAuthenticated?: boolean;
		clientInfo?: { name: string; version: string };
	},
	options: RegisterRemoteToolsOptions = {}
): (params: Record<string, unknown>, extra: ServerContext) => Promise<CallToolResult> {
	const clientCorrelationId = sessionInfo?.clientSessionId ?? sessionInfo?.requestId;
	return async (params: Record<string, unknown>, extra) => {
		logger.info({ tool: tool.name, params }, 'Calling remote tool');

		// Track metrics for logging
		const startTime = Date.now();
		let success = false;
		let error: string | undefined;
		let responseSizeBytes: number | undefined;
		let notificationCount = 0;

		try {
			// Validate MCP URL
			if (!connection.mcpUrl) {
				throw new Error('No MCP URL available for tool execution');
			}

			const progressRelay = createProgressRelay(extra);
			const result = await callGradioTool(
				connection.mcpUrl,
				tool.name,
				params,
				hfToken,
				progressRelay
					? async (progress) => {
							notificationCount++;
							await progressRelay(progress);
						}
					: undefined
			);

			// Calculate response size (rough estimate based on JSON serialization)
			try {
				responseSizeBytes = JSON.stringify(result).length;
			} catch {
				// If serialization fails, don't worry about size
			}

			success = !result.isError;
			if (result.isError) {
				// Extract a meaningful error message from MCP content items
				const first =
					Array.isArray(result.content) && result.content.length > 0 ? (result.content[0] as unknown) : undefined;
				let message: string | undefined;
				if (typeof first === 'string') {
					message = first;
				} else if (first && typeof first === 'object') {
					const obj = first as Record<string, unknown>;
					if (typeof obj.text === 'string') {
						message = obj.text;
					} else if (typeof obj.message === 'string') {
						message = obj.message;
					} else if (typeof obj.error === 'string') {
						message = obj.error;
					} else {
						try {
							message = JSON.stringify(obj);
						} catch {
							message = String(obj);
						}
					}
				} else if (first !== undefined) {
					// Fallback for other primitive types
					message = String(first);
				}

				error = message || 'Unknown error';

				// Bubble up the error so upstream callers and metrics can track failures
				throw new Error(error);
			}

			// Record success in gradio metrics when no error and no exception thrown
			if (success) {
				const metricsName = getMetricsSafeName(outwardFacingName);
				gradioMetrics.recordSuccess(metricsName);
			}

			// Prepare post-processing options
			const postProcessOptions: GradioToolCallOptions = {
				stripImageContent: options.stripImageContent,
				toolName: tool.name,
				outwardFacingName,
			};

			// Apply standard image filtering.
			return applyResultPostProcessing(result, postProcessOptions);
		} catch (err) {
			// Ensure meaningful error output instead of [object Object]
			const errObj =
				err instanceof Error
					? err
					: new Error(
							typeof err === 'string'
								? err
								: (() => {
										try {
											return JSON.stringify(err);
										} catch {
											return String(err);
										}
									})()
						);
			logger.error({ tool: tool.name, err: errObj, errMessage: errObj.message }, 'Remote tool call failed');
			const metricsName = getMetricsSafeName(outwardFacingName);
			gradioMetrics.recordFailure(metricsName);
			// Set error if not already set
			if (!error) {
				error = errObj.message;
			}
			throw errObj;
		} finally {
			// Always log the Gradio event, even if there was a crash
			const endTime = Date.now();
			logGradioEvent(connection.name || connection.endpointId, clientCorrelationId || 'unknown', {
				durationMs: endTime - startTime,
				isAuthenticated: !!hfToken,
				clientName: sessionInfo?.clientInfo?.name,
				clientVersion: sessionInfo?.clientInfo?.version,
				success,
				error,
				responseSizeBytes,
				notificationCount,
				clientSessionId: sessionInfo?.clientSessionId,
				requestId: sessionInfo?.requestId,
				protocolEra: sessionInfo?.protocolEra,
				protocolVersion: sessionInfo?.protocolVersion,
				clientCapabilities: sessionInfo?.clientCapabilities,
				userHash: sessionInfo?.userHash,
			});
		}
	};
}

/**
 * Registers multiple remote tools from a Gradio endpoint
 */
export function registerRemoteTools(
	server: McpServer,
	connection: EndpointConnection,
	hfToken?: string,
	sessionInfo?: {
		clientSessionId?: string;
		requestId?: string;
		protocolEra?: 'legacy' | 'modern';
		protocolVersion?: string;
		clientCapabilities?: Record<string, unknown>;
		userHash?: string;
		isAuthenticated?: boolean;
		clientInfo?: { name: string; version: string };
	},
	options: RegisterRemoteToolsOptions = {}
): void {
	const disabledTools = parseDisabledTools();
	const registeredResources = new Set<string>();
	connection.tools.forEach((tool, toolIndex) => {
		// Generate tool name
		const outwardFacingName = createGradioToolName(
			tool.name,
			connection.originalIndex,
			connection.isPrivate,
			toolIndex
		);
		if (disabledTools.has(outwardFacingName)) {
			logger.info({ toolName: outwardFacingName }, 'Skipping disabled remote tool');
			return;
		}

		// Create display info
		const { title, description } = createToolDisplayInfo(connection, tool);
		const { meta, resourceMapping } = connection.mcpUrl
			? rewriteProxyAppToolMeta(tool._meta, `gradio-${connection.endpointId}`, tool.name)
			: { meta: tool._meta };

		// Convert schema
		const schemaShape = convertToolSchemaToZod(tool);

		// Create handler
		const handler = createToolHandler(connection, tool, outwardFacingName, hfToken, sessionInfo, options);

		// Log registration
		logger.trace(
			{
				endpointId: connection.endpointId,
				originalName: tool.name,
				outwardFacingName: outwardFacingName,
				description: tool.description,
			},
			'Registering remote tool'
		);

		// Log the exact structure we're getting
		logger.trace(
			{
				toolName: tool.name,
				inputSchema: tool.inputSchema,
			},
			'Remote tool inputSchema structure'
		);

		// Register the tool
		server.registerTool(
			outwardFacingName,
			{
				title: title,
				description,
				inputSchema: z.object(schemaShape),
				annotations: createRemoteToolAnnotations(title),
				_meta: meta,
			},
			handler
		);

		if (resourceMapping && connection.mcpUrl) {
			registerProxyAppResource(
				server,
				resourceMapping,
				{
					name: `gradio-app:${outwardFacingName}`,
					title,
					description: `MCP App resource proxied from ${connection.name || connection.endpointId}.`,
					serverUrl: connection.mcpUrl,
					hfToken,
				},
				registeredResources
			);
		}
	});
}

function convertToolSchemaToZod(tool: Tool): Record<string, z.ZodTypeAny> {
	const schemaShape: Record<string, z.ZodTypeAny> = {};

	if (typeof tool.inputSchema === 'object' && 'properties' in tool.inputSchema) {
		const jsonSchema = tool.inputSchema as JsonSchema;
		const props = jsonSchema.properties || {};
		const required = jsonSchema.required || [];

		for (const [key, jsonSchemaProperty] of Object.entries(props)) {
			const isRequired = required.includes(key);

			// Convert to Zod schema, skipping defaults for required fields
			let zodSchema = convertJsonSchemaToZod(jsonSchemaProperty, isRequired);

			// Make optional if not in required array
			if (!isRequired) {
				zodSchema = zodSchema.optional();
			}

			schemaShape[key] = zodSchema;
		}
	}

	return schemaShape;
}

/**
 * Converts a JSON Schema property to a Zod schema
 * @param jsonSchemaProperty - The JSON schema property to convert
 * @param skipDefault - If true, won't apply default values (useful for required fields)
 */
export function convertJsonSchemaToZod(jsonSchemaProperty: JsonSchemaProperty, skipDefault = false): z.ZodTypeAny {
	let zodSchema: z.ZodTypeAny;
	const nullableType = getNullableJsonSchemaType(jsonSchemaProperty);
	const nullableUnionSchema = getNullableUnionSchema(jsonSchemaProperty);

	// Special handling for FileData types
	if (
		jsonSchemaProperty.title === 'FileData' ||
		(jsonSchemaProperty.format === 'a http or https url to a file' &&
			typeof jsonSchemaProperty.default === 'object' &&
			jsonSchemaProperty.default !== null)
	) {
		// Create FileData object schema
		zodSchema = z.object({
			path: z.string(),
			url: z.string().optional(),
			size: z.number().nullable().optional(),
			orig_name: z.string().optional(),
			mime_type: z.string().nullable().optional(),
			is_stream: z.boolean().optional(),
			meta: z
				.object({
					_type: z.string().optional(),
				})
				.optional(),
		});
	} else if (nullableUnionSchema) {
		zodSchema = convertJsonSchemaToZod(nullableUnionSchema, true).nullable();
	} else if (jsonSchemaProperty.enum && Array.isArray(jsonSchemaProperty.enum) && jsonSchemaProperty.enum.length > 0) {
		// Handle enum types
		if (jsonSchemaProperty.enum.every((v): v is string => typeof v === 'string')) {
			const enumValues = jsonSchemaProperty.enum as [string, ...string[]];
			zodSchema = z.enum(enumValues);
		} else {
			// Fallback for non-string enums - create a union of literals
			const literals: z.ZodTypeAny[] = jsonSchemaProperty.enum.map((v) => {
				if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean' || v === null) {
					return z.literal(v);
				}
				// For other types, convert to string
				return z.literal(String(v));
			});

			if (literals.length === 1) {
				// We know literals[0] exists because we checked length === 1
				zodSchema = literals[0] ?? z.any();
			} else if (literals.length >= 2) {
				// Ensure we have at least 2 elements for union
				zodSchema = z.union(literals as [z.ZodTypeAny, z.ZodTypeAny, ...z.ZodTypeAny[]]);
			} else {
				// This shouldn't happen due to our length check, but handle it anyway
				zodSchema = z.any();
			}
		}
	} else {
		// Convert based on type
		switch (nullableType ?? jsonSchemaProperty.type) {
			case 'string':
				zodSchema = z.string();
				break;
			case 'integer':
				zodSchema = z.number().int();
				break;
			case 'number':
				zodSchema = z.number();
				break;
			case 'boolean':
				zodSchema = z.boolean();
				break;
			case 'null':
				zodSchema = z.null();
				break;
			case 'array':
				zodSchema = z.array(z.any()); // Simplified for now
				break;
			case 'object':
				zodSchema = z.object({}); // Simplified for now
				break;
			default:
				zodSchema = z.any();
		}

		if (nullableType) {
			zodSchema = zodSchema.nullable();
		}
	}

	// Enhance description for file inputs
	let description = jsonSchemaProperty.description || '';
	if (jsonSchemaProperty.format === 'a http or https url to a file' || jsonSchemaProperty.title === 'FileData') {
		description = description
			? `${description} (File input: provide URL or file path)`
			: 'a http or https url to a file';
	}

	if (description) {
		zodSchema = zodSchema.describe(description);
	}

	// Apply default value from the Schema
	if (
		!skipDefault &&
		'default' in jsonSchemaProperty &&
		jsonSchemaProperty.default !== undefined &&
		jsonSchemaProperty.default !== null
	) {
		let defaultValue = jsonSchemaProperty.default;

		// For FileData types, keep the full object as default
		// For other string types with object defaults, extract URL
		if (
			jsonSchemaProperty.type === 'string' &&
			typeof defaultValue === 'object' &&
			defaultValue !== null &&
			'url' in defaultValue &&
			jsonSchemaProperty.title !== 'FileData'
		) {
			const urlValue = (defaultValue as Record<string, unknown>).url;
			if (typeof urlValue === 'string') {
				defaultValue = urlValue;
			}
		}

		zodSchema = zodSchema.default(defaultValue);
	}

	return zodSchema;
}

function getNullableJsonSchemaType(jsonSchemaProperty: JsonSchemaProperty): string | undefined {
	const { type } = jsonSchemaProperty;
	if (!Array.isArray(type) || !type.includes('null')) {
		return undefined;
	}

	const nonNullTypes = type.filter((value): value is string => value !== 'null');
	return nonNullTypes.length === 1 ? nonNullTypes[0] : undefined;
}

function getNullableUnionSchema(jsonSchemaProperty: JsonSchemaProperty): JsonSchemaProperty | undefined {
	const variants = getSchemaVariants(jsonSchemaProperty.anyOf) ?? getSchemaVariants(jsonSchemaProperty.oneOf);
	if (!variants) {
		return undefined;
	}

	const nonNullVariants = variants.filter((variant) => variant.type !== 'null');
	const hasNullVariant = nonNullVariants.length !== variants.length;
	const nonNullVariant = nonNullVariants[0];
	if (!hasNullVariant || nonNullVariants.length !== 1 || !nonNullVariant) {
		return undefined;
	}

	const { anyOf: _anyOf, oneOf: _oneOf, ...base } = jsonSchemaProperty;
	return {
		...base,
		...nonNullVariant,
		description: jsonSchemaProperty.description ?? nonNullVariant.description,
		default: jsonSchemaProperty.default,
	};
}

function getSchemaVariants(value: unknown): JsonSchemaProperty[] | undefined {
	if (!Array.isArray(value) || !value.every(isJsonSchemaProperty)) {
		return undefined;
	}

	return value;
}

function isJsonSchemaProperty(value: unknown): value is JsonSchemaProperty {
	return typeof value === 'object' && value !== null && !Array.isArray(value);
}
