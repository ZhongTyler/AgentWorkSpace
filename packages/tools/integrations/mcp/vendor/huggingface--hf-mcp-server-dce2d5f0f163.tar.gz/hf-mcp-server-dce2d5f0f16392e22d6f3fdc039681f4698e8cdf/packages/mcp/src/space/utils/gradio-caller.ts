import { Client, StreamableHTTPClientTransport, Protocol } from '@modelcontextprotocol/client';
import type {
	StreamableHTTPClientTransportOptions,
	CallToolResult,
	Progress,
	RequestOptions,
	Transport,
} from '@modelcontextprotocol/client';
import { logger } from '../../logger.js';
import { fetchWithProfile, NETWORK_FETCH_PROFILES } from '../../network/fetch-profile.js';
import { createGradioMcpPolicy, parseAndValidateUrl } from '../../network/url-policy.js';

class GradioClient extends Client {
	override async connect(transport: Transport, _options?: RequestOptions): Promise<void> {
		await Protocol.prototype.connect.call(this, transport);
	}
}

export interface GradioCallResult {
	result: CallToolResult;
	capturedHeaders: Record<string, string>;
}

export interface GradioCallOptions {
	/** Called for every response to capture custom headers */
	onHeaders?: (headers: Headers) => void;
	/** Log the X-Proxied-Replica header to stderr once */
	logProxiedReplica?: boolean;
	/** Receives progress reported by the upstream Gradio MCP server. */
	onProgress?: (progress: Progress) => void | Promise<void>;
}

/**
 * Extract the replica ID from the X-Proxied-Replica header.
 * Example: "oyerizs4-dspr4" => "dspr4"
 */
export function extractReplicaId(headerValue: string | undefined): string | null {
	if (!headerValue) return null;
	const parts = headerValue.split('-');
	if (parts.length < 2) return null;
	const replicaId = parts[parts.length - 1];
	if (!replicaId || replicaId.trim() === '') return null;
	return replicaId;
}

/**
 * Rewrites any Gradio API URLs in text content to include the replica path segment.
 * Example: https://mcp-tools-qwen-image-fast.hf.space/gradio_api =>
 *          https://mcp-tools-qwen-image-fast.hf.space/--replicas/<replica_id>/gradio_api
 */
export function rewriteReplicaUrlsInResult(
	result: CallToolResult,
	proxiedReplicaHeader: string | undefined
): CallToolResult {
	if (process.env.NO_REPLICA_REWRITE) return result;
	const replicaId = extractReplicaId(proxiedReplicaHeader);
	if (!replicaId) return result;

	const urlPattern = /https:\/\/([^\s"']+)\/gradio_api(\S*)?/g;

	const rewriteText = (text: string): string =>
		text.replace(urlPattern, (_match, host, rest = '') => {
			return `https://${host}/--replicas/${replicaId}/gradio_api${rest}`;
		});

	let changed = false;
	const newContent = result.content.map((item) => {
		if (typeof item === 'string') {
			const rewritten = rewriteText(item);
			if (rewritten !== item) {
				changed = true;
				return { type: 'text', text: rewritten } satisfies (typeof result.content)[number];
			}
			return { type: 'text', text: item } satisfies (typeof result.content)[number];
		}

		if (item && typeof item === 'object' && 'text' in item && typeof item.text === 'string') {
			const rewritten = rewriteText(item.text);
			if (rewritten !== item.text) {
				changed = true;
				return { ...item, text: rewritten };
			}
		}

		return item;
	});

	if (!changed) return result;
	return {
		...result,
		content: newContent,
	};
}

/**
 * Shared helper to call a Gradio MCP tool over Streamable HTTP, capturing response headers (including X-Proxied-Replica).
 * This handles Streamable HTTP setup and cleans up the client connection.
 */
export async function callGradioToolWithHeaders(
	mcpUrl: string,
	toolName: string,
	parameters: Record<string, unknown>,
	hfToken: string | undefined,
	options: GradioCallOptions = {}
): Promise<GradioCallResult> {
	const validatedMcpUrl = parseAndValidateUrl(mcpUrl, createGradioMcpPolicy());
	const protocol = validatedMcpUrl.protocol === 'http:' ? 'http:' : 'https:';
	const mcpRequestProfile = NETWORK_FETCH_PROFILES.gradioMcpHost(validatedMcpUrl.hostname, protocol);

	const capturedHeaders: Record<string, string> = {};
	let loggedHeader = false;

	const handleHeaders = (headers: Headers): void => {
		const proxiedReplica = headers.get('x-proxied-replica') ?? '';
		if (proxiedReplica) {
			capturedHeaders['x-proxied-replica'] = proxiedReplica;
		}
		if (options.logProxiedReplica && !loggedHeader) {
			loggedHeader = true;
		}
		options.onHeaders?.(headers);
	};

	const captureHeadersFetch: StreamableHTTPClientTransportOptions['fetch'] = async (url, init) => {
		const method = init?.method ?? 'GET';
		let requestSummary: {
			method?: unknown;
			id?: unknown;
			isBatch?: boolean;
		} | null = null;
		if (typeof init?.body === 'string') {
			try {
				const parsed = JSON.parse(init.body) as
					{ method?: unknown; id?: unknown } | Array<{ method?: unknown; id?: unknown }>;
				if (Array.isArray(parsed)) {
					requestSummary = {
						isBatch: true,
						method: parsed[0]?.method,
						id: parsed[0]?.id,
					};
				} else if (parsed && typeof parsed === 'object') {
					requestSummary = {
						isBatch: false,
						method: parsed.method,
						id: parsed.id,
					};
				}
			} catch {
				requestSummary = null;
			}
		}
		logger.trace('[gradio] upstream fetch', {
			method,
			url: url.toString(),
			hasBody: Boolean(init?.body),
			requestSummary,
		});
		const { response } = await fetchWithProfile(url.toString(), mcpRequestProfile, {
			requestInit: init,
		});
		logger.trace('[gradio] upstream response', {
			method,
			url: url.toString(),
			status: response.status,
			contentType: response.headers.get('content-type') ?? null,
			mcpSessionId: response.headers.get('mcp-session-id') ?? null,
		});
		handleHeaders(response.headers);
		return response;
	};

	const skipInitialize = process.env.GRADIO_SKIP_INITIALIZE === 'true';

	// Create MCP client
	const clientInfo = {
		name: 'hf-mcp-gradio-client',
		version: '1.0.0',
	};
	const clientOptions = {
		capabilities: {},
	};
	const remoteClient = skipInitialize
		? new GradioClient(clientInfo, clientOptions)
		: new Client(clientInfo, clientOptions);

	// Create Streamable HTTP transport with HF token if available
	const transportOptions: StreamableHTTPClientTransportOptions = {
		fetch: captureHeadersFetch,
	};
	if (hfToken) {
		const customHeaders = {
			'X-HF-Authorization': `Bearer ${hfToken}`,
		};

		// Headers for Streamable HTTP requests
		transportOptions.requestInit = {
			headers: customHeaders,
		};
	}

	logger.trace('[gradio] connecting streamable client', {
		mcpUrl: validatedMcpUrl.toString(),
		hasToken: Boolean(hfToken),
		skipInitialize,
	});
	const transport = new StreamableHTTPClientTransport(validatedMcpUrl, transportOptions);
	let isClosing = false;
	transport.onmessage = (message) => {
		const messageInfo =
			message && typeof message === 'object'
				? {
						hasId: 'id' in message,
						id: (message as { id?: unknown }).id ?? null,
						method: 'method' in message ? (message as { method?: unknown }).method : null,
						isResult: 'result' in message,
						isError: 'error' in message,
					}
				: { messageType: typeof message };
		logger.trace('[gradio] transport message', messageInfo);
	};
	transport.onerror = (error) => {
		if (isClosing && error instanceof Error && error.message.includes('AbortError')) {
			logger.trace('[gradio] transport aborted after close', { message: error.message });
			return;
		}
		logger.trace('[gradio] transport error', { error });
	};
	transport.onclose = () => {
		logger.trace('[gradio] transport closed');
	};
	let connectCompleted = false;
	const connectWatchdog = setTimeout(() => {
		if (!connectCompleted) {
			logger.trace('[gradio] connect still pending', { mcpUrl: validatedMcpUrl.toString() });
		}
	}, 15000);
	await remoteClient.connect(transport);
	connectCompleted = true;
	clearTimeout(connectWatchdog);
	logger.trace('[gradio] connected streamable client', { mcpUrl: validatedMcpUrl.toString() });

	try {
		const requestOptions: RequestOptions = {
			onprogress: (progress) => {
				logger.trace('[gradio] upstream progress event', { toolName, progress });
				if (options.onProgress) {
					void Promise.resolve(options.onProgress(progress)).catch((error: unknown) => {
						logger.trace('[gradio] downstream progress callback failed', { toolName, error });
					});
				}
			},
			resetTimeoutOnProgress: true,
		};

		const result = await remoteClient.request(
			{
				method: 'tools/call',
				params: {
					name: toolName,
					arguments: parameters,
				},
			},
			requestOptions
		);
		logger.trace('[gradio] tool request completed', { toolName, isError: result.isError });

		const proxiedReplica = capturedHeaders['x-proxied-replica'];
		const rewritten = rewriteReplicaUrlsInResult(result, proxiedReplica);

		return { result: rewritten, capturedHeaders };
	} finally {
		isClosing = true;
		await remoteClient.close();
	}
}
