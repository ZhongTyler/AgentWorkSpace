package ghmcp

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"

	"github.com/github/github-mcp-server/v2/internal/oauth"
	"github.com/github/github-mcp-server/v2/internal/requeststate"
	"github.com/github/github-mcp-server/v2/pkg/errors"
	"github.com/github/github-mcp-server/v2/pkg/github"
	"github.com/github/github-mcp-server/v2/pkg/http/transport"
	"github.com/github/github-mcp-server/v2/pkg/inventory"
	"github.com/github/github-mcp-server/v2/pkg/lockdown"
	mcplog "github.com/github/github-mcp-server/v2/pkg/log"
	"github.com/github/github-mcp-server/v2/pkg/observability"
	"github.com/github/github-mcp-server/v2/pkg/observability/metrics"
	"github.com/github/github-mcp-server/v2/pkg/raw"
	"github.com/github/github-mcp-server/v2/pkg/scopes"
	"github.com/github/github-mcp-server/v2/pkg/translations"
	"github.com/github/github-mcp-server/v2/pkg/utils"
	gogithub "github.com/google/go-github/v92/github"
	"github.com/modelcontextprotocol/go-sdk/mcp"
	"github.com/shurcooL/githubv4"
)

// githubClients holds all the GitHub API clients created for a server instance.
type githubClients struct {
	rest       *gogithub.Client
	gql        *githubv4.Client
	raw        *raw.Client
	repoAccess *lockdown.RepoAccessCache
}

// createGitHubClients creates all the GitHub API clients needed by the server.
func createGitHubClients(cfg github.MCPServerConfig, apiHost utils.APIHostResolver) (*githubClients, error) {
	restURL, err := apiHost.BaseRESTURL(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed to get base REST URL: %w", err)
	}

	uploadURL, err := apiHost.UploadURL(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed to get upload URL: %w", err)
	}

	graphQLURL, err := apiHost.GraphqlURL(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed to get GraphQL URL: %w", err)
	}

	rawURL, err := apiHost.RawURL(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed to get Raw URL: %w", err)
	}

	// allowedHosts scopes the bearer token to the configured GitHub hosts, so a
	// response that redirects off them does not carry the token to the redirect
	// target. See transport.BearerAuthTransport.
	allowedHosts := []string{
		restURL.Host,
		uploadURL.Host,
		graphQLURL.Host,
		rawURL.Host,
	}

	// Construct REST client. BearerAuthTransport handles both static and
	// provider-backed tokens so every authentication mode uses the same host
	// restrictions.
	//
	// ETagTransport sits below the user-agent (and auth) layers so that, by the
	// time it runs, the Authorization header is set and can scope the
	// conditional-request cache per token. It adds ETag/If-None-Match handling
	// so unchanged resources are revalidated with a 304 instead of being
	// re-downloaded in full.
	//
	// The conditional-request cache is enabled only for the REST API client on
	// this long-lived local (stdio) server. The raw-content client below uses a
	// separate transport without it, so large file bodies are never buffered
	// into the cache. The hosted, horizontally-scaled server builds a fresh REST
	// client per request (see pkg/github RequestDeps) and does not use this path.
	restUATransport := &transport.UserAgentTransport{
		Transport: &transport.ETagTransport{Transport: http.DefaultTransport},
		Agent:     stdioUserAgent(cfg, nil),
	}
	restClient, err := newRESTClient(cfg, restUATransport, restURL.String(), uploadURL.String(), allowedHosts)
	if err != nil {
		return nil, fmt.Errorf("failed to create REST client: %w", err)
	}

	// Construct GraphQL client
	// We use NewEnterpriseClient unconditionally since we already parsed the API host
	gqlHTTPClient := &http.Client{
		Transport: &transport.BearerAuthTransport{
			Transport: &transport.GraphQLFeaturesTransport{
				Transport: &transport.UserAgentTransport{
					Transport: http.DefaultTransport,
					Agent:     stdioUserAgent(cfg, nil),
				},
			},
			Token:         cfg.Token,
			TokenProvider: cfg.TokenProvider,
			AllowedHosts:  allowedHosts,
		},
	}

	gqlClient := githubv4.NewEnterpriseClient(graphQLURL.String(), gqlHTTPClient)

	// Create raw content client. It shares the REST client's authentication but
	// uses a transport without the conditional-request cache: raw file bodies can
	// be large and are streamed rather than retained in memory.
	rawUATransport := &transport.UserAgentTransport{
		Transport: http.DefaultTransport,
		Agent:     stdioUserAgent(cfg, nil),
	}
	rawRESTClient, err := newRESTClient(cfg, rawUATransport, restURL.String(), uploadURL.String(), allowedHosts)
	if err != nil {
		return nil, fmt.Errorf("failed to create raw REST client: %w", err)
	}
	rawClient, err := raw.NewClient(rawRESTClient, rawURL)
	if err != nil {
		return nil, fmt.Errorf("failed to create raw client: %w", err)
	}

	// Set up repo access cache for lockdown mode
	var repoAccessCache *lockdown.RepoAccessCache
	if cfg.LockdownMode {
		opts := []lockdown.RepoAccessOption{
			lockdown.WithLogger(cfg.Logger.With("component", "lockdown")),
		}
		if cfg.RepoAccessTTL != nil {
			opts = append(opts, lockdown.WithTTL(*cfg.RepoAccessTTL))
		}
		repoAccessCache = lockdown.NewRepoAccessCache(gqlClient, restClient, opts...)
	}

	return &githubClients{
		rest:       restClient,
		gql:        gqlClient,
		raw:        rawClient,
		repoAccess: repoAccessCache,
	}, nil
}

// newRESTClient builds a go-github REST client that sends requests through the
// supplied user-agent transport. Authentication uses BearerAuthTransport for
// both static and provider-backed tokens, and allowedHosts scopes the token to
// the configured GitHub hosts so it is never leaked to off-host redirects.
func newRESTClient(cfg github.MCPServerConfig, uaTransport *transport.UserAgentTransport, restURL, uploadURL string, allowedHosts []string) (*gogithub.Client, error) {
	return gogithub.NewClient(
		gogithub.WithHTTPClient(&http.Client{Transport: &transport.BearerAuthTransport{
			Transport:     uaTransport,
			Token:         cfg.Token,
			TokenProvider: cfg.TokenProvider,
			AllowedHosts:  allowedHosts,
		}}),
		gogithub.WithEnterpriseURLs(restURL, uploadURL),
	)
}

func NewStdioMCPServer(ctx context.Context, cfg github.MCPServerConfig) (*mcp.Server, error) {
	apiHost, err := utils.NewAPIHost(cfg.Host)
	if err != nil {
		return nil, fmt.Errorf("failed to parse API host: %w", err)
	}

	hostType, err := utils.ParseHostType(cfg.Host)
	if err != nil {
		return nil, fmt.Errorf("failed to classify API host: %w", err)
	}

	clients, err := createGitHubClients(cfg, apiHost)
	if err != nil {
		return nil, fmt.Errorf("failed to create GitHub clients: %w", err)
	}

	// Create feature checker — resolves explicit features + insiders expansion
	featureChecker := createFeatureChecker(cfg.EnabledFeatures, cfg.InsidersMode)

	// Create dependencies for tool handlers
	obs, err := observability.NewExporters(cfg.Logger, metrics.NewNoopMetrics())
	if err != nil {
		return nil, fmt.Errorf("failed to create observability exporters: %w", err)
	}
	deps := github.NewBaseDeps(
		clients.rest,
		clients.gql,
		clients.raw,
		clients.repoAccess,
		cfg.Translator,
		github.FeatureFlags{
			LockdownMode: cfg.LockdownMode,
		},
		cfg.ContentWindowSize,
		featureChecker,
		obs,
	)
	deps.StateSealer, err = requeststate.NewRandom()
	if err != nil {
		return nil, fmt.Errorf("failed to configure request-state protection: %w", err)
	}
	// Build and register the tool/resource/prompt inventory
	inventoryBuilder := github.NewInventory(cfg.Translator, github.WithHost(hostType)).
		WithDeprecatedAliases(github.DeprecatedToolAliases).
		WithReadOnly(cfg.ReadOnly).
		WithToolsets(github.ResolvedEnabledToolsets(cfg.EnabledToolsets, cfg.EnabledTools)).
		WithTools(github.CleanTools(cfg.EnabledTools)).
		WithExcludeTools(cfg.ExcludeTools).
		WithServerInstructions().
		WithFeatureChecker(featureChecker)

	// Apply token scope filtering if scopes are known (for PAT filtering)
	if cfg.TokenScopes != nil {
		inventoryBuilder = inventoryBuilder.WithFilter(github.CreateToolScopeFilter(cfg.TokenScopes))
	}

	inventory, err := inventoryBuilder.Build()
	if err != nil {
		return nil, fmt.Errorf("failed to build inventory: %w", err)
	}

	ghServer, err := github.NewMCPServer(ctx, &cfg, deps, inventory)
	if err != nil {
		return nil, fmt.Errorf("failed to create GitHub MCP server: %w", err)
	}

	ghServer.AddReceivingMiddleware(addUserAgentsMiddleware(cfg))

	return ghServer, nil
}

type StdioServerConfig struct {
	// Version of the server
	Version string

	// GitHub Host to target for API requests (e.g. github.com or github.enterprise.com)
	Host string

	// GitHub Token to authenticate with the GitHub API
	Token string

	// EnabledToolsets is a list of toolsets to enable
	// See: https://github.com/github/github-mcp-server?tab=readme-ov-file#tool-configuration
	EnabledToolsets []string

	// EnabledTools is a list of specific tools to enable (additive to toolsets)
	// When specified, these tools are registered in addition to any specified toolset tools
	EnabledTools []string

	// EnabledFeatures is a list of feature flags that are enabled
	// Tool feature rules evaluate entries in this list.
	EnabledFeatures []string

	// ReadOnly indicates if we should only register read-only tools
	ReadOnly bool

	// ExportTranslations indicates if we should export translations
	// See: https://github.com/github/github-mcp-server?tab=readme-ov-file#i18n--overriding-descriptions
	ExportTranslations bool

	// EnableCommandLogging indicates if we should log commands
	EnableCommandLogging bool

	// Path to the log file if not stderr
	LogFilePath string

	// Content window size
	ContentWindowSize int

	// LockdownMode indicates if we should enable lockdown mode
	LockdownMode bool

	// InsidersMode expands to the curated set of feature flags enabled for insiders.
	InsidersMode bool

	// ExcludeTools is a list of tool names to disable regardless of other settings.
	// These tools will be excluded even if their toolset is enabled or they are
	// explicitly listed in EnabledTools.
	ExcludeTools []string

	// RepoAccessCacheTTL overrides the default TTL for repository access cache entries.
	RepoAccessCacheTTL *time.Duration

	// OAuthManager, when non-nil, enables OAuth 2.1 login for stdio mode. The
	// server starts without a token and runs the authorization flow on the
	// first tool call (see createOAuthMiddleware). It is mutually exclusive with
	// a static Token.
	OAuthManager *oauth.Manager

	// OAuthScopes are the scopes requested during OAuth login. They double as
	// the scope set for tool filtering: tools requiring a scope outside this set
	// are hidden. The default set is the full supported list, which hides
	// nothing; an explicit, narrower list filters accordingly.
	OAuthScopes []string

	// TokenProvider supplies a token for each GitHub API request.
	TokenProvider func() string
}

// RunStdioServer is not concurrent safe.
func RunStdioServer(cfg StdioServerConfig) error {
	authModes := 0
	for _, on := range []bool{cfg.Token != "", cfg.OAuthManager != nil, cfg.TokenProvider != nil} {
		if on {
			authModes++
		}
	}
	if authModes > 1 {
		return fmt.Errorf("choose exactly one authentication mode: a static Token, OAuthManager, or TokenProvider")
	}

	// Create app context
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	t, dumpTranslations := translations.TranslationHelper()

	var slogHandler slog.Handler
	var logOutput io.Writer
	if cfg.LogFilePath != "" {
		file, err := os.OpenFile(cfg.LogFilePath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
		if err != nil {
			return fmt.Errorf("failed to open log file: %w", err)
		}
		logOutput = file
		slogHandler = slog.NewTextHandler(logOutput, &slog.HandlerOptions{Level: slog.LevelDebug})
	} else {
		logOutput = os.Stderr
		slogHandler = slog.NewTextHandler(logOutput, &slog.HandlerOptions{Level: slog.LevelInfo})
	}
	logger := slog.New(slogHandler)
	logger.Info("starting server", "version", cfg.Version, "host", cfg.Host, "readOnly", cfg.ReadOnly, "lockdownEnabled", cfg.LockdownMode)

	// Determine the scope set used to filter tools. Classic PATs expose their
	// granted scopes via the API; OAuth uses the requested scopes (the default
	// set hides nothing, a narrower explicit set filters accordingly). Other
	// token types don't advertise scopes, so filtering is skipped.
	var tokenScopes []string
	switch {
	case strings.HasPrefix(cfg.Token, "ghp_"):
		fetchedScopes, err := fetchTokenScopesForHost(ctx, cfg.Token, cfg.Host)
		if err != nil {
			logger.Warn("failed to fetch token scopes, continuing without scope filtering", "error", err)
		} else {
			tokenScopes = fetchedScopes
			logger.Info("token scopes fetched for filtering", "scopes", tokenScopes)
		}
	case cfg.OAuthManager != nil:
		tokenScopes = cfg.OAuthScopes
		logger.Info("using requested OAuth scopes for tool filtering", "scopes", tokenScopes)
	default:
		logger.Debug("skipping scope filtering for non-PAT token")
	}

	tokenProvider := cfg.TokenProvider
	var toolHandlerMiddleware []inventory.ToolHandlerMiddleware
	if cfg.OAuthManager != nil {
		tokenProvider = cfg.OAuthManager.AccessToken
		toolHandlerMiddleware = append(toolHandlerMiddleware, createOAuthToolMiddleware(cfg.OAuthManager, logger))
	}

	ghServer, err := NewStdioMCPServer(ctx, github.MCPServerConfig{
		Version:               cfg.Version,
		Host:                  cfg.Host,
		Token:                 cfg.Token,
		EnabledToolsets:       cfg.EnabledToolsets,
		EnabledTools:          cfg.EnabledTools,
		EnabledFeatures:       cfg.EnabledFeatures,
		ReadOnly:              cfg.ReadOnly,
		Translator:            t,
		ContentWindowSize:     cfg.ContentWindowSize,
		LockdownMode:          cfg.LockdownMode,
		InsidersMode:          cfg.InsidersMode,
		ExcludeTools:          cfg.ExcludeTools,
		Logger:                logger,
		RepoAccessTTL:         cfg.RepoAccessCacheTTL,
		TokenScopes:           tokenScopes,
		TokenProvider:         tokenProvider,
		ToolHandlerMiddleware: toolHandlerMiddleware,
	})
	if err != nil {
		return fmt.Errorf("failed to create MCP server: %w", err)
	}

	if cfg.ExportTranslations {
		// Once server is initialized, all translations are loaded
		dumpTranslations()
	}

	// Start listening for messages
	errC := make(chan error, 1)
	go func() {
		var in io.ReadCloser
		var out io.WriteCloser

		in = os.Stdin
		out = os.Stdout

		if cfg.EnableCommandLogging {
			loggedIO := mcplog.NewIOLogger(in, out, logger)
			in, out = loggedIO, loggedIO
		}

		// enable GitHub errors in the context
		ctx := errors.ContextWithGitHubErrors(ctx)
		errC <- ghServer.Run(ctx, &mcp.IOTransport{Reader: in, Writer: out})
	}()

	// Output github-mcp-server string
	_, _ = fmt.Fprintf(os.Stderr, "GitHub MCP Server running on stdio\n")

	// Wait for shutdown signal
	select {
	case <-ctx.Done():
		logger.Info("shutting down server", "signal", "context done")
	case err := <-errC:
		if err != nil {
			logger.Error("error running server", "error", err)
			return fmt.Errorf("error running server: %w", err)
		}
	}

	return nil
}

// createFeatureChecker returns a FeatureFlagChecker that resolves features
// using the centralized ResolveFeatureFlags function. For the local server,
// features are resolved once at startup from --features CLI flag and insiders mode.
func createFeatureChecker(enabledFeatures []string, insidersMode bool) inventory.FeatureFlagChecker {
	featureSet := github.ResolveFeatureFlags(enabledFeatures, insidersMode)
	return func(_ context.Context, flagName string) (bool, error) {
		return featureSet[flagName], nil
	}
}

func stdioUserAgent(cfg github.MCPServerConfig, client *mcp.Implementation) string {
	agent := fmt.Sprintf("github-mcp-server/%s", cfg.Version)
	if client != nil {
		comment := strconv.Quote(client.Name + "/" + client.Version)
		comment = comment[1 : len(comment)-1]
		comment = strings.NewReplacer("(", `\(`, ")", `\)`).Replace(comment)
		agent += " (" + comment + ")"
	}
	if cfg.InsidersMode {
		agent += " (insiders)"
	}
	return agent
}

func addUserAgentsMiddleware(cfg github.MCPServerConfig) func(next mcp.MethodHandler) mcp.MethodHandler {
	return func(next mcp.MethodHandler) mcp.MethodHandler {
		return func(ctx context.Context, method string, request mcp.Request) (result mcp.Result, err error) {
			var client *mcp.Implementation
			if info, ok := request.(interface{ ClientInfo() *mcp.Implementation }); ok {
				client = info.ClientInfo()
			}
			ctx = transport.WithUserAgent(ctx, stdioUserAgent(cfg, client))
			return next(ctx, method, request)
		}
	}
}

// fetchTokenScopesForHost fetches the OAuth scopes for a token from the GitHub API.
// It constructs the appropriate API host URL based on the configured host.
func fetchTokenScopesForHost(ctx context.Context, token, host string) ([]string, error) {
	apiHost, err := utils.NewAPIHost(host)
	if err != nil {
		return nil, fmt.Errorf("failed to parse API host: %w", err)
	}

	fetcher := scopes.NewFetcher(apiHost, scopes.FetcherOptions{})

	return fetcher.FetchTokenScopes(ctx, token)
}
