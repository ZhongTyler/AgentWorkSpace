package middleware

import (
	"net/http"
	"slices"
	"strings"

	ghcontext "github.com/github/github-mcp-server/v2/pkg/context"
	"github.com/github/github-mcp-server/v2/pkg/http/headers"
)

const queryParamFeatures = "features"

// WithRequestConfig is a middleware that extracts MCP-related headers and sets them in the request context.
// This includes readonly mode, toolsets, tools, lockdown mode, insiders mode, and feature flags.
func WithRequestConfig(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Header-selected features can change the response for the same URL.
		w.Header().Add(headers.VaryHeader, headers.MCPFeaturesHeader)

		ctx := r.Context()

		// Readonly mode
		if relaxedParseBool(r.Header.Get(headers.MCPReadOnlyHeader)) {
			ctx = ghcontext.WithReadonly(ctx, true)
		}

		// Toolsets
		if toolsets := headers.ParseCommaSeparated(r.Header.Get(headers.MCPToolsetsHeader)); len(toolsets) > 0 {
			ctx = ghcontext.WithToolsets(ctx, toolsets)
		}

		// Tools
		if tools := headers.ParseCommaSeparated(r.Header.Get(headers.MCPToolsHeader)); len(tools) > 0 {
			ctx = ghcontext.WithTools(ctx, tools)
		}

		// Lockdown mode
		if relaxedParseBool(r.Header.Get(headers.MCPLockdownHeader)) {
			ctx = ghcontext.WithLockdownMode(ctx, true)
		}

		// Excluded tools
		if excludeTools := headers.ParseCommaSeparated(r.Header.Get(headers.MCPExcludeToolsHeader)); len(excludeTools) > 0 {
			ctx = ghcontext.WithExcludeTools(ctx, excludeTools)
		}

		// Insiders mode
		if relaxedParseBool(r.Header.Get(headers.MCPInsidersHeader)) {
			ctx = ghcontext.WithInsidersMode(ctx, true)
		}

		query := r.URL.Query()
		_, hasHeaderFeatures := r.Header[http.CanonicalHeaderKey(headers.MCPFeaturesHeader)]
		_, hasQueryFeatures := query[queryParamFeatures]
		if hasHeaderFeatures {
			ctx = ghcontext.WithHeaderFeatures(ctx, headers.ParseCommaSeparated(r.Header.Get(headers.MCPFeaturesHeader)))
		} else if hasQueryFeatures {
			ctx = ghcontext.WithHeaderFeatures(ctx, headers.ParseCommaSeparated(query.Get(queryParamFeatures)))
		}

		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// relaxedParseBool parses a string into a boolean value, treating various
// common false values or empty strings as false, and everything else as true.
// It is case-insensitive and trims whitespace.
func relaxedParseBool(s string) bool {
	s = strings.TrimSpace(strings.ToLower(s))
	falseValues := []string{"", "false", "0", "no", "off", "n", "f"}
	return !slices.Contains(falseValues, s)
}
