package github

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"slices"
	"strconv"
	"strings"
	"time"

	ghcontext "github.com/github/github-mcp-server/v2/pkg/context"
	ghErrors "github.com/github/github-mcp-server/v2/pkg/errors"
	"github.com/github/github-mcp-server/v2/pkg/ifc"
	"github.com/github/github-mcp-server/v2/pkg/inventory"
	"github.com/github/github-mcp-server/v2/pkg/lockdown"
	"github.com/github/github-mcp-server/v2/pkg/sanitize"
	"github.com/github/github-mcp-server/v2/pkg/scopes"
	"github.com/github/github-mcp-server/v2/pkg/translations"
	"github.com/github/github-mcp-server/v2/pkg/utils"
	"github.com/google/go-github/v92/github"
	"github.com/google/jsonschema-go/jsonschema"
	"github.com/modelcontextprotocol/go-sdk/mcp"
	"github.com/shurcooL/githubv4"
)

// CloseIssueInput represents the input for closing an issue via the GraphQL API.
// Used to extend the functionality of the githubv4 library to support closing issues as duplicates.
type CloseIssueInput struct {
	IssueID          githubv4.ID             `json:"issueId"`
	ClientMutationID *githubv4.String        `json:"clientMutationId,omitempty"`
	StateReason      *IssueClosedStateReason `json:"stateReason,omitempty"`
	DuplicateIssueID *githubv4.ID            `json:"duplicateIssueId,omitempty"`
}

// IssueClosedStateReason represents the reason an issue was closed.
// Used to extend the functionality of the githubv4 library to support closing issues as duplicates.
type IssueClosedStateReason string

// issueWriteFieldInput is a user-friendly issue field input for issue_write.
// Field IDs and option IDs are resolved internally before calling the REST API.
type issueWriteFieldInput struct {
	FieldName       string
	Value           any
	FieldOptionName string
	Delete          bool
}

const (
	IssueClosedStateReasonCompleted  IssueClosedStateReason = "COMPLETED"
	IssueClosedStateReasonDuplicate  IssueClosedStateReason = "DUPLICATE"
	IssueClosedStateReasonNotPlanned IssueClosedStateReason = "NOT_PLANNED"
)

// fetchIssueIDs retrieves issue IDs via the GraphQL API.
// When duplicateOf is 0, it fetches only the main issue ID.
// When duplicateOf is non-zero, it fetches both the main issue and duplicate issue IDs in a single query.
func fetchIssueIDs(ctx context.Context, gqlClient *githubv4.Client, owner, repo string, issueNumber int, duplicateOf int) (githubv4.ID, githubv4.ID, error) {
	// Build query variables common to both cases
	vars := map[string]any{
		"owner":       githubv4.String(owner),
		"repo":        githubv4.String(repo),
		"issueNumber": githubv4.Int(issueNumber), // #nosec G115 - issue numbers are always small positive integers
	}

	if duplicateOf == 0 {
		// Only fetch the main issue ID
		var query struct {
			Repository struct {
				Issue struct {
					ID githubv4.ID
				} `graphql:"issue(number: $issueNumber)"`
			} `graphql:"repository(owner: $owner, name: $repo)"`
		}

		if err := gqlClient.Query(ctx, &query, vars); err != nil {
			return "", "", fmt.Errorf("failed to get issue ID: %w", err)
		}

		return query.Repository.Issue.ID, "", nil
	}

	// Fetch both issue IDs in a single query
	var query struct {
		Repository struct {
			Issue struct {
				ID githubv4.ID
			} `graphql:"issue(number: $issueNumber)"`
			DuplicateIssue struct {
				ID githubv4.ID
			} `graphql:"duplicateIssue: issue(number: $duplicateOf)"`
		} `graphql:"repository(owner: $owner, name: $repo)"`
	}

	// Add duplicate issue number to variables
	vars["duplicateOf"] = githubv4.Int(duplicateOf) // #nosec G115 - issue numbers are always small positive integers

	if err := gqlClient.Query(ctx, &query, vars); err != nil {
		return "", "", fmt.Errorf("failed to get issue ID: %w", err)
	}

	return query.Repository.Issue.ID, query.Repository.DuplicateIssue.ID, nil
}

// getCloseStateReason converts a string state reason to the appropriate enum value
func getCloseStateReason(stateReason string) IssueClosedStateReason {
	switch stateReason {
	case "not_planned":
		return IssueClosedStateReasonNotPlanned
	case "duplicate":
		return IssueClosedStateReasonDuplicate
	default: // Default to "completed" for empty or "completed" values
		return IssueClosedStateReasonCompleted
	}
}

// issueFieldWriteMetadataNode queries only the fields needed to resolve a write: the field's
// fullDatabaseId (BigInt scalar, returned as string) plus its name and data type for validation.
// shurcooL/githubv4 cannot use interface-level fragments at union top-level, so we repeat
// fullDatabaseId on each concrete type; all four implement IssueFieldCommon.
type issueFieldWriteMetadataNode struct {
	TypeName       githubv4.String `graphql:"__typename"`
	IssueFieldText struct {
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
		Name           githubv4.String
		DataType       githubv4.String
	} `graphql:"... on IssueFieldText"`
	IssueFieldNumber struct {
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
		Name           githubv4.String
		DataType       githubv4.String
	} `graphql:"... on IssueFieldNumber"`
	IssueFieldDate struct {
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
		Name           githubv4.String
		DataType       githubv4.String
	} `graphql:"... on IssueFieldDate"`
	IssueFieldSingleSelect struct {
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
		Name           githubv4.String
		DataType       githubv4.String
		Options        []struct {
			FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
			Name           githubv4.String
		}
	} `graphql:"... on IssueFieldSingleSelect"`
}

type issueFieldWriteMetadataQuery struct {
	Repository struct {
		IssueFields struct {
			Nodes []issueFieldWriteMetadataNode
		} `graphql:"issueFields(first: 100)"`
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

// IssueFieldRef resolves the name of an issue field across its concrete types.
// IssueFields is a union of IssueFieldDate, IssueFieldNumber, IssueFieldSingleSelect, IssueFieldText,
// so we have to ask for `name` on each member.
type IssueFieldRef struct {
	Date struct {
		Name           githubv4.String
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
	} `graphql:"... on IssueFieldDate"`
	Number struct {
		Name           githubv4.String
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
	} `graphql:"... on IssueFieldNumber"`
	SingleSelect struct {
		Name           githubv4.String
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
	} `graphql:"... on IssueFieldSingleSelect"`
	Text struct {
		Name           githubv4.String
		FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
	} `graphql:"... on IssueFieldText"`
}

// Name returns the populated name from whichever IssueFields union variant the field resolved to.
func (r IssueFieldRef) Name() string {
	switch {
	case r.Date.Name != "":
		return string(r.Date.Name)
	case r.Number.Name != "":
		return string(r.Number.Name)
	case r.SingleSelect.Name != "":
		return string(r.SingleSelect.Name)
	case r.Text.Name != "":
		return string(r.Text.Name)
	}
	return ""
}

// FullDatabaseIDStr returns the fullDatabaseId string from whichever IssueFields union variant
// the field resolved to.
func (r IssueFieldRef) FullDatabaseIDStr() string {
	switch {
	case r.Date.FullDatabaseID != "":
		return string(r.Date.FullDatabaseID)
	case r.Number.FullDatabaseID != "":
		return string(r.Number.FullDatabaseID)
	case r.SingleSelect.FullDatabaseID != "":
		return string(r.SingleSelect.FullDatabaseID)
	case r.Text.FullDatabaseID != "":
		return string(r.Text.FullDatabaseID)
	}
	return ""
}

// IssueFieldValueFragment captures the value of a custom issue field. IssueFieldValue is a union
// of 4 concrete value types; each carries its own value scalar and a reference to its parent field.
// The Number variant's `value` is aliased to `valueNumber` to avoid a Float vs String type clash on decode.
type IssueFieldValueFragment struct {
	TypeName  string `graphql:"__typename"`
	DateValue struct {
		Field IssueFieldRef
		Value githubv4.String
	} `graphql:"... on IssueFieldDateValue"`
	NumberValue struct {
		Field IssueFieldRef
		Value githubv4.Float `graphql:"valueNumber: value"`
	} `graphql:"... on IssueFieldNumberValue"`
	SingleSelectValue struct {
		Field IssueFieldRef
		Value githubv4.String
	} `graphql:"... on IssueFieldSingleSelectValue"`
	TextValue struct {
		Field IssueFieldRef
		Value githubv4.String
	} `graphql:"... on IssueFieldTextValue"`
}

func optionalIssueWriteFields(args map[string]any) ([]issueWriteFieldInput, error) {
	issueFieldsRaw, exists := args["issue_fields"]
	if !exists {
		return nil, nil
	}

	var inputMaps []map[string]any
	switch v := issueFieldsRaw.(type) {
	case []any:
		for _, item := range v {
			itemMap, ok := item.(map[string]any)
			if !ok {
				return nil, fmt.Errorf("each issue_fields item must be an object")
			}
			inputMaps = append(inputMaps, itemMap)
		}
	case []map[string]any:
		inputMaps = v
	default:
		return nil, fmt.Errorf("issue_fields must be an array")
	}

	issueFields := make([]issueWriteFieldInput, 0, len(inputMaps))
	for _, itemMap := range inputMaps {
		fieldName, err := RequiredParam[string](itemMap, "field_name")
		if err != nil || strings.TrimSpace(fieldName) == "" {
			return nil, fmt.Errorf("field_name is required for each issue_fields item")
		}

		fieldOptionName, err := OptionalParam[string](itemMap, "field_option_name")
		if err != nil {
			return nil, err
		}

		deleteField, err := OptionalParam[bool](itemMap, "delete")
		if err != nil {
			return nil, err
		}
		value, hasValue := itemMap["value"]
		if hasValue && value == nil {
			return nil, fmt.Errorf("value cannot be null for field %q", fieldName)
		}

		if deleteField {
			if hasValue || fieldOptionName != "" {
				return nil, fmt.Errorf("issue field %q cannot specify 'delete' together with 'value' or 'field_option_name'", fieldName)
			}
			issueFields = append(issueFields, issueWriteFieldInput{
				FieldName: fieldName,
				Delete:    true,
			})
			continue
		}

		if hasValue && fieldOptionName != "" {
			return nil, fmt.Errorf("issue field %q cannot specify both value and field_option_name", fieldName)
		}

		if !hasValue && fieldOptionName == "" {
			return nil, fmt.Errorf("issue field %q must specify either value or field_option_name", fieldName)
		}

		issueFields = append(issueFields, issueWriteFieldInput{
			FieldName:       fieldName,
			Value:           value,
			FieldOptionName: fieldOptionName,
		})
	}

	return issueFields, nil
}

func resolveIssueRequestFieldValues(ctx context.Context, gqlClient *githubv4.Client, owner, repo string, issueFields []issueWriteFieldInput) ([]*github.IssueRequestFieldValue, []int64, error) {
	if len(issueFields) == 0 {
		return nil, nil, nil
	}

	ctxWithFeatures := ghcontext.WithGraphQLFeatures(ctx, "issue_fields", "repo_issue_fields")
	var query issueFieldWriteMetadataQuery
	vars := map[string]any{
		"owner": githubv4.String(owner),
		"repo":  githubv4.String(repo),
	}
	if err := gqlClient.Query(ctxWithFeatures, &query, vars); err != nil {
		return nil, nil, fmt.Errorf("failed to query issue fields metadata: %w", err)
	}

	// Build name → node map, dispatching on concrete type to extract name.
	fieldByName := make(map[string]issueFieldWriteMetadataNode, len(query.Repository.IssueFields.Nodes))
	for _, node := range query.Repository.IssueFields.Nodes {
		var name string
		switch string(node.TypeName) {
		case "IssueFieldText":
			name = string(node.IssueFieldText.Name)
		case "IssueFieldNumber":
			name = string(node.IssueFieldNumber.Name)
		case "IssueFieldDate":
			name = string(node.IssueFieldDate.Name)
		case "IssueFieldSingleSelect":
			name = string(node.IssueFieldSingleSelect.Name)
		default:
			continue
		}
		fieldByName[strings.ToLower(strings.TrimSpace(name))] = node
	}

	resolved := make([]*github.IssueRequestFieldValue, 0, len(issueFields))
	var fieldIDsToDelete []int64
	for _, fieldInput := range issueFields {
		node, ok := fieldByName[strings.ToLower(strings.TrimSpace(fieldInput.FieldName))]
		if !ok {
			return nil, nil, fmt.Errorf("issue field %q was not found in %s/%s", fieldInput.FieldName, owner, repo)
		}

		var fullDatabaseIDStr, dataType string
		switch string(node.TypeName) {
		case "IssueFieldText":
			fullDatabaseIDStr = string(node.IssueFieldText.FullDatabaseID)
			dataType = string(node.IssueFieldText.DataType)
		case "IssueFieldNumber":
			fullDatabaseIDStr = string(node.IssueFieldNumber.FullDatabaseID)
			dataType = string(node.IssueFieldNumber.DataType)
		case "IssueFieldDate":
			fullDatabaseIDStr = string(node.IssueFieldDate.FullDatabaseID)
			dataType = string(node.IssueFieldDate.DataType)
		case "IssueFieldSingleSelect":
			fullDatabaseIDStr = string(node.IssueFieldSingleSelect.FullDatabaseID)
			dataType = string(node.IssueFieldSingleSelect.DataType)
		}

		fieldID := parseFullDatabaseID(fullDatabaseIDStr)
		if fieldID == 0 {
			return nil, nil, fmt.Errorf("issue field %q is missing fullDatabaseId", fieldInput.FieldName)
		}

		if fieldInput.Delete {
			fieldIDsToDelete = append(fieldIDsToDelete, fieldID)
			continue
		}

		resolvedValue := fieldInput.Value
		if fieldInput.FieldOptionName != "" {
			if !strings.EqualFold(dataType, "single_select") {
				return nil, nil, fmt.Errorf("issue field %q is %q, so field_option_name cannot be used", fieldInput.FieldName, dataType)
			}

			optionFound := false
			for _, option := range node.IssueFieldSingleSelect.Options {
				if strings.EqualFold(strings.TrimSpace(string(option.Name)), strings.TrimSpace(fieldInput.FieldOptionName)) {
					// REST API expects the option name, not the ID
					resolvedValue = string(option.Name)
					optionFound = true
					break
				}
			}

			if !optionFound {
				return nil, nil, fmt.Errorf("issue field option %q was not found for field %q", fieldInput.FieldOptionName, fieldInput.FieldName)
			}
		}

		resolved = append(resolved, &github.IssueRequestFieldValue{
			FieldID: fieldID,
			Value:   resolvedValue,
		})
	}

	return resolved, fieldIDsToDelete, nil
}

// fetchExistingIssueFieldValues retrieves the current field values for an issue
// as IssueRequestFieldValue entries, ready to be merged before an update.
func fetchExistingIssueFieldValues(ctx context.Context, gqlClient *githubv4.Client, owner, repo string, issueNumber int) ([]*github.IssueRequestFieldValue, error) {
	ctxWithFeatures := ghcontext.WithGraphQLFeatures(ctx, "issue_fields", "repo_issue_fields")

	var query struct {
		Repository struct {
			Issue struct {
				IssueFieldValues struct {
					Nodes []IssueFieldValueFragment
				} `graphql:"issueFieldValues(first: 25)"`
			} `graphql:"issue(number: $number)"`
		} `graphql:"repository(owner: $owner, name: $repo)"`
	}

	vars := map[string]any{
		"owner":  githubv4.String(owner),
		"repo":   githubv4.String(repo),
		"number": githubv4.Int(issueNumber), // #nosec G115 - issue numbers are always small positive integers
	}

	if err := gqlClient.Query(ctxWithFeatures, &query, vars); err != nil {
		return nil, fmt.Errorf("failed to fetch existing issue field values: %w", err)
	}

	var result []*github.IssueRequestFieldValue
	for _, node := range query.Repository.Issue.IssueFieldValues.Nodes {
		var fieldIDStr string
		var value any

		switch node.TypeName {
		case "IssueFieldDateValue":
			fieldIDStr = node.DateValue.Field.FullDatabaseIDStr()
			value = string(node.DateValue.Value)
		case "IssueFieldNumberValue":
			fieldIDStr = node.NumberValue.Field.FullDatabaseIDStr()
			value = float64(node.NumberValue.Value)
		case "IssueFieldSingleSelectValue":
			fieldIDStr = node.SingleSelectValue.Field.FullDatabaseIDStr()
			value = string(node.SingleSelectValue.Value)
		case "IssueFieldTextValue":
			fieldIDStr = node.TextValue.Field.FullDatabaseIDStr()
			value = string(node.TextValue.Value)
		default:
			continue
		}

		fieldID := parseFullDatabaseID(fieldIDStr)
		if fieldID == 0 {
			continue
		}

		result = append(result, &github.IssueRequestFieldValue{
			FieldID: fieldID,
			Value:   value,
		})
	}

	return result, nil
}

// mergeIssueFieldValues returns a merged slice where incoming values override existing ones
// for the same field ID, and existing fields not present in incoming are preserved.
// Ordering is deterministic: incoming entries first in their original order, followed by any
// existing entries (in their original order) whose field IDs weren't seen in incoming.
func mergeIssueFieldValues(existing, incoming []*github.IssueRequestFieldValue) []*github.IssueRequestFieldValue {
	seen := make(map[int64]struct{}, len(incoming))
	result := make([]*github.IssueRequestFieldValue, 0, len(existing)+len(incoming))
	for _, v := range incoming {
		seen[v.FieldID] = struct{}{}
		result = append(result, v)
	}
	for _, v := range existing {
		if _, ok := seen[v.FieldID]; ok {
			continue
		}
		result = append(result, v)
	}
	return result
}

// IssueFragment represents a fragment of an issue node in the GraphQL API.
type IssueFragment struct {
	Number     githubv4.Int
	Title      githubv4.String
	Body       githubv4.String
	State      githubv4.String
	DatabaseID int64

	Author struct {
		Login githubv4.String
	}
	CreatedAt githubv4.DateTime
	UpdatedAt githubv4.DateTime
	Labels    struct {
		Nodes []struct {
			Name        githubv4.String
			ID          githubv4.String
			Description githubv4.String
		}
	} `graphql:"labels(first: 100)"`
	// GitHub caps issue assignees at 10, so first: 100 cannot truncate.
	Assignees struct {
		Nodes []struct {
			Login githubv4.String
		}
	} `graphql:"assignees(first: 100)"`
	Comments struct {
		TotalCount githubv4.Int
	} `graphql:"comments"`
	IssueFieldValues struct {
		Nodes []IssueFieldValueFragment
	} `graphql:"issueFieldValues(first: 25)"`
}

type issueFragmentWithoutFieldValues struct {
	Number     githubv4.Int
	Title      githubv4.String
	Body       githubv4.String
	State      githubv4.String
	DatabaseID int64

	Author struct {
		Login githubv4.String
	}
	CreatedAt githubv4.DateTime
	UpdatedAt githubv4.DateTime
	Labels    struct {
		Nodes []struct {
			Name        githubv4.String
			ID          githubv4.String
			Description githubv4.String
		}
	} `graphql:"labels(first: 100)"`
	Assignees struct {
		Nodes []struct {
			Login githubv4.String
		}
	} `graphql:"assignees(first: 100)"`
	Comments struct {
		TotalCount githubv4.Int
	} `graphql:"comments"`
}

// Common interface for all issue query types
type IssueQueryResult interface {
	GetIssueFragment() IssueQueryFragment
	GetIsPrivate() bool
}

type issueQueryResultWithoutFieldValues interface {
	getIssueFragmentWithoutFieldValues() issueQueryFragmentWithoutFieldValues
	GetIsPrivate() bool
}

type IssueQueryFragment struct {
	Nodes    []IssueFragment `graphql:"nodes"`
	PageInfo struct {
		HasNextPage     githubv4.Boolean
		HasPreviousPage githubv4.Boolean
		StartCursor     githubv4.String
		EndCursor       githubv4.String
	}
	TotalCount int
}

type issueQueryFragmentWithoutFieldValues struct {
	Nodes    []issueFragmentWithoutFieldValues `graphql:"nodes"`
	PageInfo struct {
		HasNextPage     githubv4.Boolean
		HasPreviousPage githubv4.Boolean
		StartCursor     githubv4.String
		EndCursor       githubv4.String
	}
	TotalCount int
}

// ListIssuesQuery is the root query structure for fetching issues with optional label filtering.
type ListIssuesQuery struct {
	Repository struct {
		Issues    IssueQueryFragment `graphql:"issues(first: $first, after: $after, states: $states, orderBy: {field: $orderBy, direction: $direction}, filterBy: {issueFieldValues: $issueFieldValues})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

// ListIssuesQueryTypeWithLabels is the query structure for fetching issues with optional label filtering.
type ListIssuesQueryTypeWithLabels struct {
	Repository struct {
		Issues    IssueQueryFragment `graphql:"issues(first: $first, after: $after, labels: $labels, states: $states, orderBy: {field: $orderBy, direction: $direction}, filterBy: {issueFieldValues: $issueFieldValues})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

// ListIssuesQueryWithSince is the query structure for fetching issues without label filtering but with since filtering.
type ListIssuesQueryWithSince struct {
	Repository struct {
		Issues    IssueQueryFragment `graphql:"issues(first: $first, after: $after, states: $states, orderBy: {field: $orderBy, direction: $direction}, filterBy: {since: $since, issueFieldValues: $issueFieldValues})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

// ListIssuesQueryTypeWithLabelsWithSince is the query structure for fetching issues with both label and since filtering.
type ListIssuesQueryTypeWithLabelsWithSince struct {
	Repository struct {
		Issues    IssueQueryFragment `graphql:"issues(first: $first, after: $after, labels: $labels, states: $states, orderBy: {field: $orderBy, direction: $direction}, filterBy: {since: $since, issueFieldValues: $issueFieldValues})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

type listIssuesQueryWithoutFieldValues struct {
	Repository struct {
		Issues    issueQueryFragmentWithoutFieldValues `graphql:"issues(first: $first, after: $after, states: $states, orderBy: {field: $orderBy, direction: $direction})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

type listIssuesQueryWithLabelsWithoutFieldValues struct {
	Repository struct {
		Issues    issueQueryFragmentWithoutFieldValues `graphql:"issues(first: $first, after: $after, labels: $labels, states: $states, orderBy: {field: $orderBy, direction: $direction})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

type listIssuesQueryWithSinceWithoutFieldValues struct {
	Repository struct {
		Issues    issueQueryFragmentWithoutFieldValues `graphql:"issues(first: $first, after: $after, states: $states, orderBy: {field: $orderBy, direction: $direction}, filterBy: {since: $since})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

type listIssuesQueryWithLabelsAndSinceWithoutFieldValues struct {
	Repository struct {
		Issues    issueQueryFragmentWithoutFieldValues `graphql:"issues(first: $first, after: $after, labels: $labels, states: $states, orderBy: {field: $orderBy, direction: $direction}, filterBy: {since: $since})"`
		IsPrivate githubv4.Boolean
	} `graphql:"repository(owner: $owner, name: $repo)"`
}

// IssueFieldValueFilter mirrors the GraphQL IssueFieldValueFilter input. Exactly one typed value
// field should be set per filter (the monolith resolver rejects multiple).
type IssueFieldValueFilter struct {
	FieldName               githubv4.String  `json:"fieldName"`
	TextValue               *githubv4.String `json:"textValue,omitempty"`
	DateValue               *githubv4.String `json:"dateValue,omitempty"`
	NumberValue             *githubv4.Float  `json:"numberValue,omitempty"`
	SingleSelectOptionValue *githubv4.String `json:"singleSelectOptionValue,omitempty"`
}

// Implement the interface for all query types
func (q *ListIssuesQueryTypeWithLabels) GetIssueFragment() IssueQueryFragment {
	return q.Repository.Issues
}

func (q *ListIssuesQueryTypeWithLabels) GetIsPrivate() bool { return bool(q.Repository.IsPrivate) }

func (q *ListIssuesQuery) GetIssueFragment() IssueQueryFragment {
	return q.Repository.Issues
}

func (q *ListIssuesQuery) GetIsPrivate() bool { return bool(q.Repository.IsPrivate) }

func (q *ListIssuesQueryWithSince) GetIssueFragment() IssueQueryFragment {
	return q.Repository.Issues
}

func (q *ListIssuesQueryWithSince) GetIsPrivate() bool { return bool(q.Repository.IsPrivate) }

func (q *ListIssuesQueryTypeWithLabelsWithSince) GetIssueFragment() IssueQueryFragment {
	return q.Repository.Issues
}

func (q *ListIssuesQueryTypeWithLabelsWithSince) GetIsPrivate() bool {
	return bool(q.Repository.IsPrivate)
}

func (q *listIssuesQueryWithoutFieldValues) getIssueFragmentWithoutFieldValues() issueQueryFragmentWithoutFieldValues {
	return q.Repository.Issues
}

func (q *listIssuesQueryWithoutFieldValues) GetIsPrivate() bool {
	return bool(q.Repository.IsPrivate)
}

func (q *listIssuesQueryWithLabelsWithoutFieldValues) getIssueFragmentWithoutFieldValues() issueQueryFragmentWithoutFieldValues {
	return q.Repository.Issues
}

func (q *listIssuesQueryWithLabelsWithoutFieldValues) GetIsPrivate() bool {
	return bool(q.Repository.IsPrivate)
}

func (q *listIssuesQueryWithSinceWithoutFieldValues) getIssueFragmentWithoutFieldValues() issueQueryFragmentWithoutFieldValues {
	return q.Repository.Issues
}

func (q *listIssuesQueryWithSinceWithoutFieldValues) GetIsPrivate() bool {
	return bool(q.Repository.IsPrivate)
}

func (q *listIssuesQueryWithLabelsAndSinceWithoutFieldValues) getIssueFragmentWithoutFieldValues() issueQueryFragmentWithoutFieldValues {
	return q.Repository.Issues
}

func (q *listIssuesQueryWithLabelsAndSinceWithoutFieldValues) GetIsPrivate() bool {
	return bool(q.Repository.IsPrivate)
}

func getIssueQueryType(hasLabels bool, hasSince bool) IssueQueryResult {
	switch {
	case hasLabels && hasSince:
		return &ListIssuesQueryTypeWithLabelsWithSince{}
	case hasLabels:
		return &ListIssuesQueryTypeWithLabels{}
	case hasSince:
		return &ListIssuesQueryWithSince{}
	default:
		return &ListIssuesQuery{}
	}
}

func getIssueQueryTypeWithoutFieldValues(hasLabels bool, hasSince bool) issueQueryResultWithoutFieldValues {
	switch {
	case hasLabels && hasSince:
		return &listIssuesQueryWithLabelsAndSinceWithoutFieldValues{}
	case hasLabels:
		return &listIssuesQueryWithLabelsWithoutFieldValues{}
	case hasSince:
		return &listIssuesQueryWithSinceWithoutFieldValues{}
	default:
		return &listIssuesQueryWithoutFieldValues{}
	}
}

func isUnsupportedIssueFieldValuesSchemaError(err error) bool {
	if err == nil {
		return false
	}

	message := strings.ToLower(err.Error())
	mentionsIssueType := strings.Contains(message, "on type 'issue'") ||
		strings.Contains(message, `on type "issue"`) ||
		strings.Contains(message, "on type issue")
	if strings.Contains(message, "issuefieldvalues") &&
		mentionsIssueType &&
		(strings.Contains(message, "doesn't exist on type") ||
			strings.Contains(message, "does not exist on type") ||
			strings.Contains(message, "cannot query field") ||
			strings.Contains(message, "is not defined on type")) {
		return true
	}

	issueFieldTypes := [...]string{
		"issuefielddate",
		"issuefieldnumber",
		"issuefieldsingleselect",
		"issuefieldtext",
	}
	for _, issueFieldType := range issueFieldTypes {
		if !strings.Contains(message, issueFieldType) {
			continue
		}
		return strings.Contains(message, "unknown type") ||
			strings.Contains(message, "isn't a defined type") ||
			strings.Contains(message, "is not a defined type") ||
			strings.Contains(message, "fragment cannot be spread") ||
			strings.Contains(message, "can never be of type")
	}
	return false
}

func isUnsupportedListIssuesIssueFieldsError(err error) bool {
	if isUnsupportedIssueFieldValuesSchemaError(err) {
		return true
	}

	message := err.Error()
	if strings.Contains(message, "IssueFieldValueFilter") {
		return true
	}
	if !strings.Contains(message, "issueFieldValues") {
		return false
	}
	return strings.Contains(message, "doesn't exist on type") ||
		strings.Contains(message, "doesn't accept argument") ||
		(strings.Contains(message, "Argument 'filterBy'") && strings.Contains(message, "invalid value"))
}

// IssueRead creates a tool to get details of a specific issue in a GitHub repository.
func IssueRead(t translations.TranslationHelperFunc) inventory.ServerTool {
	schema := &jsonschema.Schema{
		Type: "object",
		Properties: map[string]*jsonschema.Schema{
			"method": {
				Type: "string",
				Description: "The read operation to perform on a single issue.\n" +
					"Options are:\n" +
					"1. get - Get issue details. Also returns best-effort hierarchy flags (`has_parent`, `has_children`); `parent` and `sub_issues_summary` are optional relationship summaries, and `closed_by_pull_requests` summarizes the pull requests configured to close the issue as `total_count` plus up to 5 `references`.\n" +
					"2. get_comments - Get issue comments.\n" +
					"3. get_sub_issues - Get sub-issues (children) of the issue.\n" +
					"4. get_parent - Get the parent issue, if this issue is a sub-issue of another.\n" +
					"5. get_labels - Get labels assigned to the issue.\n",
				Enum: []any{"get", "get_comments", "get_sub_issues", "get_parent", "get_labels"},
			},
			"owner": {
				Type:        "string",
				Description: "The owner of the repository",
			},
			"repo": {
				Type:        "string",
				Description: "The name of the repository",
			},
			"issue_number": {
				Type:        "number",
				Description: "The number of the issue",
			},
		},
		Required: []string{"method", "owner", "repo", "issue_number"},
	}
	WithPagination(schema)

	return NewTool[IssueReadInput, *IssueReadOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:         "issue_read",
			OutputSchema: issueReadOutputSchema(),
			Description:  t("TOOL_ISSUE_READ_DESCRIPTION", "Get information about a specific issue in a GitHub repository."),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_ISSUE_READ_USER_TITLE", "Get issue details"),
				ReadOnlyHint: true,
			},
			InputSchema: schema,
		},
		scopes.PublicRead(scopes.Repo),
		func(ctx context.Context, deps ToolDependencies, _ *mcp.CallToolRequest, input IssueReadInput) (*mcp.CallToolResult, *IssueReadOutput, error) {
			args, err := discussionNotificationArguments(input)
			if err != nil {
				return nil, nil, err
			}
			method, err := RequiredParam[string](args, "method")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			owner, err := RequiredParam[string](args, "owner")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			repo, err := RequiredParam[string](args, "repo")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			issueNumber, err := RequiredInt(args, "issue_number")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			pagination, err := OptionalPaginationParams(args)
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			client, err := deps.GetClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GitHub client", err), nil, nil
			}

			gqlClient, err := deps.GetGQLClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GitHub graphql client", err), nil, nil
			}

			// attachIFC adds the IFC label to a successful tool result when
			// IFC labels are enabled. If the visibility lookup fails the
			// label is omitted rather than misclassifying the result.
			attachIFC := newRepoVisibilityIFCLabeler(ctx, deps, client, owner, repo, ifc.LabelRepoUserContent)

			switch method {
			case "get":
				result, output, err := getIssue(ctx, client, deps, owner, repo, issueNumber)
				return attachIFC(result), output, err
			case "get_comments":
				result, output, err := getIssueComments(ctx, client, deps, owner, repo, issueNumber, pagination)
				return attachIFC(result), output, err
			case "get_sub_issues":
				result, output, err := getSubIssues(ctx, client, deps, owner, repo, issueNumber, pagination)
				return attachIFC(result), output, err
			case "get_parent":
				result, output, err := getIssueParent(ctx, gqlClient, deps, owner, repo, issueNumber)
				return attachIFC(result), output, err
			case "get_labels":
				result, output, err := getIssueLabels(ctx, gqlClient, owner, repo, issueNumber)
				return attachIFC(result), output, err
			default:
				return utils.NewToolResultError(fmt.Sprintf("unknown method: %s", method)), nil, nil
			}
		}, normalizeConsolidatedIssueArguments("read"))
}

func GetIssue(ctx context.Context, client *github.Client, deps ToolDependencies, owner string, repo string, issueNumber int) (*mcp.CallToolResult, error) {
	result, _, err := getIssue(ctx, client, deps, owner, repo, issueNumber)
	return result, err
}

func getIssue(ctx context.Context, client *github.Client, deps ToolDependencies, owner string, repo string, issueNumber int) (*mcp.CallToolResult, *IssueReadOutput, error) {
	cache, err := deps.GetRepoAccessCache(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get repo access cache: %w", err)
	}
	flags := deps.GetFlags(ctx)

	issue, resp, err := client.Issues.Get(ctx, owner, repo, issueNumber)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get issue: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to get issue", resp, body), nil, nil
	}

	if flags.LockdownMode {
		if restricted, err := authorLockdownResult(ctx, cache, owner, repo, issue.GetUser().GetLogin(), lockdownIssueRestrictedMessage); restricted != nil || err != nil {
			return restricted, nil, err
		}
	}

	minimalIssue := convertToMinimalIssue(issue)

	// Always drop the verbose REST IssueFieldValues; enrich with the GraphQL
	// field_values view and the hierarchy relationship signals instead. The
	// enrichment is best-effort: a failure here must never fail `get`.
	minimalIssue.IssueFieldValues = nil
	if issue != nil && issue.NodeID != nil && *issue.NodeID != "" {
		gqlClient, err := deps.GetGQLClient(ctx)
		if err == nil {
			if enrichment, err := fetchIssueReadEnrichment(ctx, gqlClient, *issue.NodeID); err == nil {
				applyIssueReadEnrichment(ctx, &minimalIssue, enrichment, cache, flags.LockdownMode)
			}
		}
	}

	return MarshalledTextResult(minimalIssue), &IssueReadOutput{Method: "get", Issue: issueDetailsOutput(minimalIssue)}, nil
}

// applyIssueReadEnrichment populates the hierarchy relationship signals (has_parent/has_children,
// parent, sub_issues_summary), the closing pull request references, and field_values onto the
// minimal issue. In lockdown mode references whose content cannot be verified as safe are omitted;
// has_parent and the numeric counts are structural routing signals and are always safe to surface.
func applyIssueReadEnrichment(ctx context.Context, minimalIssue *MinimalIssue, enrichment *issueReadEnrichment, cache *lockdown.RepoAccessCache, lockdownMode bool) {
	if enrichment == nil {
		return
	}

	minimalIssue.FieldValues = enrichment.FieldValues
	minimalIssue.HasParent = ToBoolPtr(enrichment.Parent != nil)
	minimalIssue.HasChildren = ToBoolPtr(enrichment.SubIssuesSummary.Total > 0)

	if parent := enrichment.Parent; parent != nil {
		// Surface the parent reference only when it is safe to expose. Under lockdown an
		// unverified (possibly cross-repo) parent is omitted entirely, mirroring how unsafe
		// comments and sub-issues are filtered out. has_parent still routes an agent to
		// get_parent if it needs to follow up.
		if !lockdownMode || isSafeRefContent(ctx, cache, parent.Ref.Repository, parent.AuthorLogin) {
			ref := parent.Ref
			minimalIssue.Parent = &ref
		}
	}

	// A zero total is meaningful here: it tells an agent that nothing is currently set up to close
	// the issue, so it does not need to fall back to scanning pull requests. Only a few references
	// are embedded, so total_count is what distinguishes a complete list from a truncated one.
	closing := MinimalClosingPullRequests{
		TotalCount: enrichment.ClosedByPullRequestsTotal,
		References: make([]MinimalPullRequestRef, 0, len(enrichment.ClosedByPullRequests)),
	}
	for _, pr := range enrichment.ClosedByPullRequests {
		if lockdownMode && !isSafeRefContent(ctx, cache, pr.Ref.Repository, pr.AuthorLogin) {
			continue
		}
		closing.References = append(closing.References, pr.Ref)
	}
	minimalIssue.ClosedByPullRequests = &closing

	if enrichment.SubIssuesSummary.Total > 0 {
		summary := enrichment.SubIssuesSummary
		minimalIssue.SubIssuesSummary = &summary
	}
}

// isSafeRefContent reports whether a related issue or pull request reference can be exposed under
// lockdown mode. It fails closed: any inability to positively verify safe content (missing cache,
// missing author, unparseable repository, or a lookup error) results in the reference being omitted.
func isSafeRefContent(ctx context.Context, cache *lockdown.RepoAccessCache, repository, authorLogin string) bool {
	if cache == nil || authorLogin == "" {
		return false
	}
	owner, repo, ok := strings.Cut(repository, "/")
	if !ok || owner == "" || repo == "" {
		return false
	}
	safe, err := cache.IsSafeContent(ctx, authorLogin, owner, repo)
	if err != nil {
		return false
	}
	return safe
}

func GetIssueComments(ctx context.Context, client *github.Client, deps ToolDependencies, owner string, repo string, issueNumber int, pagination PaginationParams) (*mcp.CallToolResult, error) {
	result, _, err := getIssueComments(ctx, client, deps, owner, repo, issueNumber, pagination)
	return result, err
}

func getIssueComments(ctx context.Context, client *github.Client, deps ToolDependencies, owner string, repo string, issueNumber int, pagination PaginationParams) (*mcp.CallToolResult, *IssueReadOutput, error) {
	cache, err := deps.GetRepoAccessCache(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get repo access cache: %w", err)
	}
	flags := deps.GetFlags(ctx)

	opts := &github.IssueListCommentsOptions{
		ListOptions: github.ListOptions{
			Page:    pagination.Page,
			PerPage: pagination.PerPage,
		},
	}

	comments, resp, err := client.Issues.ListComments(ctx, owner, repo, issueNumber, opts)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get issue comments: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to get issue comments", resp, body), nil, nil
	}
	if flags.LockdownMode {
		if cache == nil {
			return nil, nil, fmt.Errorf("lockdown cache is not configured")
		}
		filteredComments := make([]*github.IssueComment, 0, len(comments))
		for _, comment := range comments {
			user := comment.User
			if user == nil {
				continue
			}
			login := user.GetLogin()
			if login == "" {
				continue
			}
			isSafeContent, err := cache.IsSafeContent(ctx, login, owner, repo)
			if err != nil {
				return utils.NewToolResultError(fmt.Sprintf("failed to check lockdown mode: %v", err)), nil, nil
			}
			if isSafeContent {
				filteredComments = append(filteredComments, comment)
			}
		}
		comments = filteredComments
	}

	minimalComments := make([]MinimalIssueComment, 0, len(comments))
	for _, comment := range comments {
		minimalComments = append(minimalComments, convertToMinimalIssueComment(comment))
	}

	output := issueCommentOutputs(minimalComments)
	return MarshalledTextResult(minimalComments), &IssueReadOutput{Method: "get_comments", Comments: &output}, nil
}

func GetSubIssues(ctx context.Context, client *github.Client, deps ToolDependencies, owner string, repo string, issueNumber int, pagination PaginationParams) (*mcp.CallToolResult, error) {
	result, _, err := getSubIssues(ctx, client, deps, owner, repo, issueNumber, pagination)
	return result, err
}

func getSubIssues(ctx context.Context, client *github.Client, deps ToolDependencies, owner string, repo string, issueNumber int, pagination PaginationParams) (*mcp.CallToolResult, *IssueReadOutput, error) {
	cache, err := deps.GetRepoAccessCache(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get repo access cache: %w", err)
	}
	featureFlags := deps.GetFlags(ctx)

	opts := &github.ListOptions{
		Page:    pagination.Page,
		PerPage: pagination.PerPage,
	}

	subIssues, resp, err := client.SubIssue.ListByIssue(ctx, owner, repo, int64(issueNumber), opts)
	if err != nil {
		return ghErrors.NewGitHubAPIErrorResponse(ctx,
			"failed to list sub-issues",
			resp,
			err,
		), nil, nil
	}

	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to list sub-issues", resp, body), nil, nil
	}

	if featureFlags.LockdownMode {
		if cache == nil {
			return nil, nil, fmt.Errorf("lockdown cache is not configured")
		}
		filteredSubIssues := make([]*github.SubIssue, 0, len(subIssues))
		for _, subIssue := range subIssues {
			user := subIssue.User
			if user == nil {
				continue
			}
			login := user.GetLogin()
			if login == "" {
				continue
			}
			isSafeContent, err := cache.IsSafeContent(ctx, login, owner, repo)
			if err != nil {
				return utils.NewToolResultError(fmt.Sprintf("failed to check lockdown mode: %v", err)), nil, nil
			}
			if isSafeContent {
				filteredSubIssues = append(filteredSubIssues, subIssue)
			}
		}
		subIssues = filteredSubIssues
	}

	for _, subIssue := range subIssues {
		sanitizeSubIssueTitleAndBody(subIssue)
	}
	r, err := json.Marshal(subIssues)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to marshal response: %w", err)
	}

	var output []*SubIssueOutput
	if subIssues != nil {
		output = make([]*SubIssueOutput, 0, len(subIssues))
	}
	for _, issue := range subIssues {
		item, err := subIssueOutput(issue)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to build sub-issue output: %w", err)
		}
		output = append(output, item)
	}
	return utils.NewToolResultText(string(r)), &IssueReadOutput{Method: "get_sub_issues", SubIssues: &output}, nil
}

// GetIssueParent returns the parent issue of the given issue, or a null
// parent when the issue is not a sub-issue. It reads the GraphQL
// Issue.parent field, the upward counterpart to get_sub_issues.
//
// The parent title is always sanitized (it may be cross-repo). Under
// lockdown mode the parent is only returned when its author has push
// access to the parent repo (mirroring GetIssue); otherwise it is omitted.
func GetIssueParent(ctx context.Context, client *githubv4.Client, deps ToolDependencies, owner string, repo string, issueNumber int) (*mcp.CallToolResult, error) {
	result, _, err := getIssueParent(ctx, client, deps, owner, repo, issueNumber)
	return result, err
}

func getIssueParent(ctx context.Context, client *githubv4.Client, deps ToolDependencies, owner string, repo string, issueNumber int) (*mcp.CallToolResult, *IssueReadOutput, error) {
	cache, err := deps.GetRepoAccessCache(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get repo access cache: %w", err)
	}
	flags := deps.GetFlags(ctx)

	var query struct {
		Repository struct {
			Issue struct {
				Parent *struct {
					Number githubv4.Int
					Title  githubv4.String
					State  githubv4.String
					URL    githubv4.String
					Author struct {
						Login githubv4.String
					}
					Repository struct {
						NameWithOwner githubv4.String
					}
				}
			} `graphql:"issue(number: $issueNumber)"`
		} `graphql:"repository(owner: $owner, name: $repo)"`
	}

	vars := map[string]any{
		"owner":       githubv4.String(owner),
		"repo":        githubv4.String(repo),
		"issueNumber": githubv4.Int(issueNumber), // #nosec G115 - issue numbers are always small positive integers
	}

	if err := client.Query(ctx, &query, vars); err != nil {
		return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "failed to get issue parent", err), nil, nil
	}

	parent := query.Repository.Issue.Parent
	if parent == nil {
		output := &IssueParentOutput{}
		return MarshalledTextResult(output), &IssueReadOutput{Method: "get_parent", Parent: output.Parent}, nil
	}

	if flags.LockdownMode {
		if cache == nil {
			return nil, nil, fmt.Errorf("lockdown cache is not configured")
		}
		// Fail closed: omit the parent if anything needed for the safe-content
		// check is missing or unverifiable.
		parentAuthorLogin := string(parent.Author.Login)
		parentOwner, parentRepo, ok := strings.Cut(string(parent.Repository.NameWithOwner), "/")
		if parentAuthorLogin == "" || !ok || parentOwner == "" || parentRepo == "" {
			output := &IssueParentOutput{}
			return MarshalledTextResult(output), &IssueReadOutput{Method: "get_parent", Parent: output.Parent}, nil
		}
		isSafeContent, err := cache.IsSafeContent(ctx, parentAuthorLogin, parentOwner, parentRepo)
		if err != nil || !isSafeContent {
			output := &IssueParentOutput{}
			return MarshalledTextResult(output), &IssueReadOutput{Method: "get_parent", Parent: output.Parent}, nil
		}
	}

	output := &IssueParentOutput{Parent: &IssueParentRef{
		Number: int(parent.Number), Title: sanitize.PlainText(string(parent.Title)),
		State: string(parent.State), URL: string(parent.URL),
		Repository: string(parent.Repository.NameWithOwner),
	}}
	return MarshalledTextResult(output), &IssueReadOutput{Method: "get_parent", Parent: output.Parent}, nil
}

func GetIssueLabels(ctx context.Context, client *githubv4.Client, owner string, repo string, issueNumber int) (*mcp.CallToolResult, error) {
	result, _, err := getIssueLabels(ctx, client, owner, repo, issueNumber)
	return result, err
}

func getIssueLabels(ctx context.Context, client *githubv4.Client, owner string, repo string, issueNumber int) (*mcp.CallToolResult, *IssueReadOutput, error) {
	// Get current labels on the issue using GraphQL
	var query struct {
		Repository struct {
			Issue struct {
				Labels struct {
					Nodes []struct {
						ID          githubv4.ID
						Name        githubv4.String
						Color       githubv4.String
						Description githubv4.String
					}
					TotalCount githubv4.Int
				} `graphql:"labels(first: 100)"`
			} `graphql:"issue(number: $issueNumber)"`
		} `graphql:"repository(owner: $owner, name: $repo)"`
	}

	vars := map[string]any{
		"owner":       githubv4.String(owner),
		"repo":        githubv4.String(repo),
		"issueNumber": githubv4.Int(issueNumber), // #nosec G115 - issue numbers are always small positive integers
	}

	if err := client.Query(ctx, &query, vars); err != nil {
		return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "Failed to get issue labels", err), nil, nil
	}

	// Extract label information
	issueLabels := make([]IssueLabelOutput, len(query.Repository.Issue.Labels.Nodes))
	for i, label := range query.Repository.Issue.Labels.Nodes {
		issueLabels[i] = IssueLabelOutput{
			ID: fmt.Sprintf("%v", label.ID), Name: string(label.Name),
			Color: string(label.Color), Description: string(label.Description),
		}
	}

	response := &IssueLabelsOutput{
		Labels: issueLabels, TotalCount: int(query.Repository.Issue.Labels.TotalCount),
	}

	out, err := json.Marshal(response)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to marshal response: %w", err)
	}

	return utils.NewToolResultText(string(out)), &IssueReadOutput{Method: "get_labels", Labels: &response.Labels, TotalCount: &response.TotalCount}, nil
}

// ListIssueTypes creates a tool to list defined issue types for an organization or repository.
// This can be used to understand supported issue type values for creating or updating issues.
func ListIssueTypes(t translations.TranslationHelperFunc) inventory.ServerTool {
	st := NewTool[IssueMetadataInput, []*IssueTypeOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:        "list_issue_types",
			Description: t("TOOL_LIST_ISSUE_TYPES_FOR_ORG", "List supported issue types for a repository or its owner organization. When repo is omitted, returns org-level issue types directly."),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_LIST_ISSUE_TYPES_USER_TITLE", "List available issue types"),
				ReadOnlyHint: true,
			},
			InputSchema: &jsonschema.Schema{
				Type: "object",
				Properties: map[string]*jsonschema.Schema{
					"owner": {
						Type:        "string",
						Description: "The account owner of the repository or organization.",
					},
					"repo": {
						Type:        "string",
						Description: "The name of the repository. When provided, returns issue types for this specific repository. When omitted, returns org-level issue types directly.",
					},
				},
				Required: []string{"owner"},
			},
			OutputSchema: issueTypeOutputSchema(),
		},
		repositoryOrOrganizationScopeAccess(),
		func(ctx context.Context, deps ToolDependencies, _ *mcp.CallToolRequest, input IssueMetadataInput) (*mcp.CallToolResult, []*IssueTypeOutput, error) {
			owner, repo := input.Owner, input.Repo
			if owner == "" {
				return utils.NewToolResultError("missing required parameter: owner"), nil, nil
			}

			client, err := deps.GetClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GitHub client", err), nil, nil
			}

			if repo != "" {
				apiURL := fmt.Sprintf("repos/%s/%s/issue-types", owner, repo)
				req, err := client.NewRequest(ctx, "GET", apiURL, nil)
				if err != nil {
					return utils.NewToolResultErrorFromErr("failed to create request", err), nil, nil
				}
				var issueTypes []*github.IssueType
				resp, err := client.Do(req, &issueTypes)
				if err != nil {
					return ghErrors.NewGitHubAPIErrorResponse(ctx, "failed to list issue types", resp, err), nil, nil
				}
				defer func() { _ = resp.Body.Close() }()

				if resp.StatusCode != http.StatusOK {
					body, err := io.ReadAll(resp.Body)
					if err != nil {
						return utils.NewToolResultErrorFromErr("failed to read response body", err), nil, nil
					}
					return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to list issue types", resp, body), nil, nil
				}

				r, err := json.Marshal(issueTypes)
				if err != nil {
					return utils.NewToolResultErrorFromErr("failed to marshal issue types", err), nil, nil
				}

				result := utils.NewToolResultText(string(r))
				result = attachRepoVisibilityIFCLabelLazy(ctx, deps, owner, repo, result, ifc.LabelRepoMetadata)
				return result, issueTypeOutputs(issueTypes), nil
			}

			issueTypes, resp, err := client.Organizations.ListIssueTypes(ctx, owner)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to list issue types", err), nil, nil
			}
			defer func() { _ = resp.Body.Close() }()

			if resp.StatusCode != http.StatusOK {
				body, err := io.ReadAll(resp.Body)
				if err != nil {
					return utils.NewToolResultErrorFromErr("failed to read response body", err), nil, nil
				}
				return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to list issue types", resp, body), nil, nil
			}

			r, err := json.Marshal(issueTypes)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to marshal issue types", err), nil, nil
			}

			result := utils.NewToolResultText(string(r))
			// Issue types are org-defined structural metadata (trusted, not
			// attacker-authored). They are scoped to an organization rather
			// than a single repo, so confidentiality is conservatively treated
			// as private (restricted to org members).
			result = attachStaticIFCLabel(ctx, deps, result, ifc.LabelRepoMetadata(true))
			return result, issueTypeOutputs(issueTypes), nil
		}, normalizeIssueStrings([]string{"owner"}, []string{"repo"}))
	return st
}

// AddIssueComment creates a tool to add a comment or reaction to an issue.
func AddIssueComment(t translations.TranslationHelperFunc) inventory.ServerTool {
	return NewTool[AddIssueCommentInput, *AddIssueCommentOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:        "add_issue_comment",
			Description: t("TOOL_ADD_ISSUE_COMMENT_DESCRIPTION", "Add a comment and/or reaction to a specific issue or issue comment in a GitHub repository. Use this tool with pull requests as well (in this case pass pull request number as issue_number), but only if user is not asking specifically to add or react to review comments. At least one of body or reaction is required."),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_ADD_ISSUE_COMMENT_USER_TITLE", "Add comment to issue or pull request"),
				ReadOnlyHint: false,
			},
			InputSchema: &jsonschema.Schema{
				Type: "object",
				Properties: map[string]*jsonschema.Schema{
					"owner": {
						Type:        "string",
						Description: "Repository owner",
					},
					"repo": {
						Type:        "string",
						Description: "Repository name",
					},
					"issue_number": {
						Type:        "number",
						Description: "Issue or pull request number to comment on or react to.",
					},
					"comment_id": {
						Type:        "integer",
						Description: "The numeric ID of the issue or pull request comment to react to. Use this for reactions to comments; omit it to react to the issue or pull request itself. Cannot be combined with body.",
						Minimum:     new(1.0),
					},
					"body": {
						Type:        "string",
						Description: "Comment content. Required unless reaction is provided.",
						MinLength:   new(1),
					},
					"reaction": {
						Type:        "string",
						Description: "Emoji reaction to add. Required unless body is provided.",
						Enum:        []any{"+1", "-1", "laugh", "confused", "heart", "hooray", "rocket", "eyes"},
					},
				},
				Required: []string{"owner", "repo", "issue_number"},
			},
			OutputSchema: addIssueCommentOutputSchema(),
		},
		publicRepositoryWriteScopeAccess(),
		func(ctx context.Context, deps ToolDependencies, _ *mcp.CallToolRequest, input AddIssueCommentInput) (*mcp.CallToolResult, *AddIssueCommentOutput, error) {
			owner, repo, issueNumber := input.Owner, input.Repo, input.IssueNumber
			if err := validateIssueCoordinate(owner, repo, issueNumber); err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			var commentID int64
			hasCommentID := input.CommentID != nil
			if hasCommentID {
				commentID = *input.CommentID
				if commentID < 1 {
					return utils.NewToolResultError("comment_id must be greater than 0"), nil, nil
				}
			}
			hasBody, hasReaction := input.Body != nil, input.Reaction != nil
			var body, reactionContent string
			if hasBody {
				body = *input.Body
			}
			if hasReaction {
				reactionContent = *input.Reaction
			}
			if hasCommentID && hasBody {
				return utils.NewToolResultError("comment_id cannot be combined with body"), nil, nil
			}
			if hasCommentID && !hasReaction {
				return utils.NewToolResultError("comment_id can only be provided when reaction is provided"), nil, nil
			}
			if !hasBody && !hasReaction {
				return utils.NewToolResultError("at least one of body or reaction is required"), nil, nil
			}
			if hasBody && body == "" {
				return utils.NewToolResultError("body cannot be empty when provided"), nil, nil
			}
			if hasReaction && reactionContent == "" {
				return utils.NewToolResultError("reaction cannot be empty when provided"), nil, nil
			}
			if hasReaction && !isValidIssueReaction(reactionContent) {
				return utils.NewToolResultError("reaction must be one of +1, -1, laugh, confused, heart, hooray, rocket, eyes"), nil, nil
			}

			client, err := deps.GetClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GitHub client", err), nil, nil
			}

			var reactionResponse *MinimalResponse
			if hasReaction {
				if hasCommentID {
					comment, resp, err := client.Issues.GetComment(ctx, owner, repo, commentID)
					if err != nil {
						return ghErrors.NewGitHubAPIErrorResponse(ctx, "failed to get issue comment", resp, err), nil, nil
					}
					defer func() { _ = resp.Body.Close() }()

					commentIssueNumber, err := issueNumberFromIssueURL(comment.GetIssueURL())
					if err != nil {
						return utils.NewToolResultErrorFromErr("failed to determine issue number for comment", err), nil, nil
					}
					if commentIssueNumber != issueNumber {
						return utils.NewToolResultError(fmt.Sprintf("comment_id does not belong to issue_number %d", issueNumber)), nil, nil
					}

					reaction, resp, err := client.Reactions.CreateIssueCommentReaction(ctx, owner, repo, commentID, reactionContent)
					if err != nil {
						return ghErrors.NewGitHubAPIErrorResponse(ctx, "failed to add reaction to issue comment", resp, err), nil, nil
					}
					defer func() { _ = resp.Body.Close() }()

					reactionResponse = &MinimalResponse{
						ID:  fmt.Sprintf("%d", reaction.GetID()),
						URL: fmt.Sprintf("%srepos/%s/%s/issues/comments/%d/reactions/%d", client.BaseURL(), owner, repo, commentID, reaction.GetID()),
					}
				} else {
					reaction, resp, err := client.Reactions.CreateIssueReaction(ctx, owner, repo, issueNumber, reactionContent)
					if err != nil {
						return ghErrors.NewGitHubAPIErrorResponse(ctx, "failed to add reaction to issue", resp, err), nil, nil
					}
					defer func() { _ = resp.Body.Close() }()

					reactionResponse = &MinimalResponse{
						ID:  fmt.Sprintf("%d", reaction.GetID()),
						URL: fmt.Sprintf("%srepos/%s/%s/issues/%d/reactions/%d", client.BaseURL(), owner, repo, issueNumber, reaction.GetID()),
					}
				}
			}

			var commentResponse *MinimalResponse
			if hasBody {
				comment := github.IssueCommentRequest{
					Body: body,
				}
				createdComment, resp, err := client.Issues.CreateComment(ctx, owner, repo, issueNumber, comment)
				if err != nil {
					return ghErrors.NewGitHubAPIErrorResponse(ctx, "failed to create comment", resp, err), nil, nil
				}
				defer func() { _ = resp.Body.Close() }()

				if resp.StatusCode != http.StatusCreated {
					bodyBytes, err := io.ReadAll(resp.Body)
					if err != nil {
						return utils.NewToolResultErrorFromErr("failed to read response body", err), nil, nil
					}
					return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to create comment", resp, bodyBytes), nil, nil
				}

				commentResponse = &MinimalResponse{
					ID:  fmt.Sprintf("%d", createdComment.GetID()),
					URL: createdComment.GetHTMLURL(),
				}
			}

			legacyResult := &AddIssueCommentLegacyOutput{}
			result := &AddIssueCommentOutput{}
			switch {
			case hasBody && hasReaction:
				legacyResult.Combined = &IssueCommentAndReactionLegacyOutput{
					Comment: *commentResponse, Reaction: *reactionResponse,
				}
				result.Combined = &IssueCommentAndReactionOutput{
					Comment:  IssueCommentOutput{ID: commentResponse.ID, HTMLURL: commentResponse.URL},
					Reaction: IssueReactionOutput{ID: reactionResponse.ID},
				}
			case hasReaction:
				legacyResult.Single = reactionResponse
				result.Single = &IssueCommentOutput{ID: reactionResponse.ID}
			default:
				legacyResult.Single = commentResponse
				if commentResponse != nil {
					result.Single = &IssueCommentOutput{ID: commentResponse.ID, HTMLURL: commentResponse.URL}
				}
			}

			r, err := json.Marshal(legacyResult)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to marshal response", err), nil, nil
			}

			return utils.NewToolResultText(string(r)), result, nil
		}, normalizeIssueStrings([]string{"owner", "repo"}, []string{"body", "reaction"}),
		normalizeIssueIntegers([]string{"issue_number"}, nil), normalizeIssueCommentID)
}

// UpdateIssueComment creates a tool to update an issue or pull request conversation comment.
func UpdateIssueComment(t translations.TranslationHelperFunc) inventory.ServerTool {
	return NewToolWithSchemaOptions[UpdateIssueCommentInput, *IssueCommentOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:        "update_issue_comment",
			Description: t("TOOL_UPDATE_ISSUE_COMMENT_DESCRIPTION", "Update the body of an existing issue or pull request conversation comment. This tool cannot update pull request review comments."),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_UPDATE_ISSUE_COMMENT_USER_TITLE", "Update issue comment"),
				ReadOnlyHint: false,
			},
			InputSchema: &jsonschema.Schema{
				Type: "object",
				Properties: map[string]*jsonschema.Schema{
					"owner": {
						Type:        "string",
						Description: "Repository owner",
					},
					"repo": {
						Type:        "string",
						Description: "Repository name",
					},
					"comment_id": {
						Type:        "integer",
						Description: "The numeric ID of the issue or pull request conversation comment to update. Do not use a pull request review comment ID.",
						Minimum:     new(1.0),
					},
					"body": {
						Type:        "string",
						Description: "New comment content",
						MinLength:   new(1),
					},
				},
				Required: []string{"owner", "repo", "comment_id", "body"},
			},
			OutputSchema: issueCommentOutputSchema(),
		},
		publicRepositoryWriteScopeAccess(),
		inventory.TypedSchemaOptions{PreserveHandlerContent: true},
		func(ctx context.Context, deps ToolDependencies, _ *mcp.CallToolRequest, input UpdateIssueCommentInput) (*mcp.CallToolResult, *IssueCommentOutput, error) {
			owner, repo, commentID := input.Owner, input.Repo, input.CommentID
			if owner == "" {
				return utils.NewToolResultError("missing required parameter: owner"), nil, nil
			}
			if repo == "" {
				return utils.NewToolResultError("missing required parameter: repo"), nil, nil
			}
			if commentID == 0 {
				return utils.NewToolResultError("missing required parameter: comment_id"), nil, nil
			}
			if commentID < 1 {
				return utils.NewToolResultError("comment_id must be greater than 0"), nil, nil
			}
			if input.Body == nil {
				return utils.NewToolResultError("missing required parameter: body"), nil, nil
			}
			body := *input.Body
			if body == "" {
				return utils.NewToolResultError("body cannot be empty when provided"), nil, nil
			}

			client, err := deps.GetClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GitHub client", err), nil, nil
			}

			updatedComment, resp, err := client.Issues.UpdateComment(ctx, owner, repo, commentID, github.IssueCommentRequest{
				Body: body,
			})
			if resp != nil && resp.Body != nil {
				defer func() { _ = resp.Body.Close() }()
			}
			if err != nil {
				return ghErrors.NewGitHubAPIErrorResponse(ctx, "failed to update issue comment", resp, err), nil, nil
			}

			legacyOutput := &MinimalResponse{
				ID:  fmt.Sprintf("%d", updatedComment.GetID()),
				URL: updatedComment.GetHTMLURL(),
			}
			output := &IssueCommentOutput{ID: legacyOutput.ID, HTMLURL: legacyOutput.URL}
			r, err := json.Marshal(legacyOutput)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to marshal response", err), nil, nil
			}

			return utils.NewToolResultText(string(r)), output, nil
		}, normalizeIssueStrings([]string{"owner", "repo"}, []string{"body"}), normalizeIssueCommentID)
}

func isValidIssueReaction(reaction string) bool {
	switch reaction {
	case "+1", "-1", "laugh", "confused", "heart", "hooray", "rocket", "eyes":
		return true
	default:
		return false
	}
}

func issueNumberFromIssueURL(issueURL string) (int, error) {
	issueNumberString := issueURL[strings.LastIndex(issueURL, "/")+1:]
	issueNumber, err := strconv.Atoi(issueNumberString)
	if err != nil {
		return 0, fmt.Errorf("invalid issue URL %q: %w", issueURL, err)
	}
	return issueNumber, nil
}

// SubIssueWrite creates a tool to add a sub-issue to a parent issue.
func SubIssueWrite(t translations.TranslationHelperFunc) inventory.ServerTool {
	st := NewTool[SubIssueWriteInput, *SubIssueWriteOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:         "sub_issue_write",
			OutputSchema: subIssueWriteOutputSchema(),
			Description:  t("TOOL_SUB_ISSUE_WRITE_DESCRIPTION", "Add a sub-issue to a parent issue in a GitHub repository."),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_SUB_ISSUE_WRITE_USER_TITLE", "Change sub-issue"),
				ReadOnlyHint: false,
			},
			InputSchema: &jsonschema.Schema{
				Type: "object",
				Properties: map[string]*jsonschema.Schema{
					"method": {
						Type: "string",
						Description: "The action to perform on a single sub-issue\n" +
							"Options are:\n" +
							"- 'add' - add a sub-issue to a parent issue in a GitHub repository.\n" +
							"- 'remove' - remove a sub-issue from a parent issue in a GitHub repository.\n" +
							"- 'reprioritize' - change the order of sub-issues within a parent issue in a GitHub repository. Use either 'after_id' or 'before_id' to specify the new position.\n" +
							"Writes issue hierarchy. To move a sub-issue to a new parent, use `add` with `replace_parent=true`; there is no writable parent field.\n",
					},
					"owner": {
						Type:        "string",
						Description: "Repository owner",
					},
					"repo": {
						Type:        "string",
						Description: "Repository name",
					},
					"issue_number": {
						Type:        "number",
						Description: "The number of the parent issue",
					},
					"sub_issue_id": {
						Type:        "number",
						Description: "The ID of the sub-issue to add. ID is not the same as issue number",
					},
					"replace_parent": {
						Type:        "boolean",
						Description: "When true, replaces the sub-issue's current parent issue. Use with 'add' method only.",
					},
					"after_id": {
						Type:        "number",
						Description: "The ID of the sub-issue to be prioritized after (either after_id OR before_id should be specified)",
					},
					"before_id": {
						Type:        "number",
						Description: "The ID of the sub-issue to be prioritized before (either after_id OR before_id should be specified)",
					},
				},
				Required: []string{"method", "owner", "repo", "issue_number", "sub_issue_id"},
			},
		},
		scopes.RequireAll(scopes.Repo),
		func(ctx context.Context, deps ToolDependencies, _ *mcp.CallToolRequest, input SubIssueWriteInput) (*mcp.CallToolResult, *SubIssueWriteOutput, error) {
			args, err := discussionNotificationArguments(input)
			if err != nil {
				return nil, nil, err
			}
			method, err := RequiredParam[string](args, "method")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			owner, err := RequiredParam[string](args, "owner")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			repo, err := RequiredParam[string](args, "repo")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			issueNumber, err := RequiredInt(args, "issue_number")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			subIssueID, err := RequiredInt(args, "sub_issue_id")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			replaceParent, err := OptionalParam[bool](args, "replace_parent")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			afterID, err := OptionalIntParam(args, "after_id")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			beforeID, err := OptionalIntParam(args, "before_id")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			client, err := deps.GetClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GitHub client", err), nil, nil
			}

			switch strings.ToLower(method) {
			case "add":
				return subIssueWriteResult("add")(addSubIssue(ctx, client, owner, repo, issueNumber, subIssueID, replaceParent))
			case "remove":
				// Call the remove sub-issue function
				return subIssueWriteResult("remove")(removeSubIssue(ctx, client, owner, repo, issueNumber, subIssueID))
			case "reprioritize":
				// Call the reprioritize sub-issue function
				return subIssueWriteResult("reprioritize")(reprioritizeSubIssue(ctx, client, owner, repo, issueNumber, subIssueID, afterID, beforeID))
			default:
				return utils.NewToolResultError(fmt.Sprintf("unknown method: %s", method)), nil, nil
			}
		}, normalizeConsolidatedIssueArguments("sub"))
	st.FeatureRule = issuesConsolidatedFeatureRule
	return st
}

func AddSubIssue(ctx context.Context, client *github.Client, owner string, repo string, issueNumber int, subIssueID int, replaceParent bool) (*mcp.CallToolResult, error) {
	result, _, err := addSubIssue(ctx, client, owner, repo, issueNumber, subIssueID, replaceParent)
	return result, err
}

func addSubIssue(ctx context.Context, client *github.Client, owner string, repo string, issueNumber int, subIssueID int, replaceParent bool) (*mcp.CallToolResult, *SubIssueOutput, error) {
	subIssueRequest := github.SubIssueRequest{
		SubIssueID:    int64(subIssueID),
		ReplaceParent: new(replaceParent),
	}

	subIssue, resp, err := client.SubIssue.Add(ctx, owner, repo, int64(issueNumber), subIssueRequest)
	if err != nil {
		return ghErrors.NewGitHubAPIErrorResponse(ctx,
			"failed to add sub-issue",
			resp,
			err,
		), nil, nil
	}

	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusCreated {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to add sub-issue", resp, body), nil, nil
	}

	sanitizeSubIssueTitleAndBody(subIssue)
	r, err := json.Marshal(subIssue)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to marshal response: %w", err)
	}

	output, err := subIssueOutput(subIssue)
	return utils.NewToolResultText(string(r)), output, err
}

func RemoveSubIssue(ctx context.Context, client *github.Client, owner string, repo string, issueNumber int, subIssueID int) (*mcp.CallToolResult, error) {
	result, _, err := removeSubIssue(ctx, client, owner, repo, issueNumber, subIssueID)
	return result, err
}

func removeSubIssue(ctx context.Context, client *github.Client, owner string, repo string, issueNumber int, subIssueID int) (*mcp.CallToolResult, *SubIssueOutput, error) {
	subIssueRequest := github.SubIssueRequest{
		SubIssueID: int64(subIssueID),
	}

	subIssue, resp, err := client.SubIssue.Remove(ctx, owner, repo, int64(issueNumber), subIssueRequest)
	if err != nil {
		return ghErrors.NewGitHubAPIErrorResponse(ctx,
			"failed to remove sub-issue",
			resp,
			err,
		), nil, nil
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to remove sub-issue", resp, body), nil, nil
	}

	sanitizeSubIssueTitleAndBody(subIssue)
	r, err := json.Marshal(subIssue)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to marshal response: %w", err)
	}

	output, err := subIssueOutput(subIssue)
	return utils.NewToolResultText(string(r)), output, err
}

func ReprioritizeSubIssue(ctx context.Context, client *github.Client, owner string, repo string, issueNumber int, subIssueID int, afterID int, beforeID int) (*mcp.CallToolResult, error) {
	result, _, err := reprioritizeSubIssue(ctx, client, owner, repo, issueNumber, subIssueID, afterID, beforeID)
	return result, err
}

func reprioritizeSubIssue(ctx context.Context, client *github.Client, owner string, repo string, issueNumber int, subIssueID int, afterID int, beforeID int) (*mcp.CallToolResult, *SubIssueOutput, error) {
	// Validate that either after_id or before_id is specified, but not both
	if afterID == 0 && beforeID == 0 {
		return utils.NewToolResultError("either after_id or before_id must be specified"), nil, nil
	}
	if afterID != 0 && beforeID != 0 {
		return utils.NewToolResultError("only one of after_id or before_id should be specified, not both"), nil, nil
	}

	subIssueRequest := github.SubIssueRequest{
		SubIssueID: int64(subIssueID),
	}

	if afterID != 0 {
		afterIDInt64 := int64(afterID)
		subIssueRequest.AfterID = &afterIDInt64
	}
	if beforeID != 0 {
		beforeIDInt64 := int64(beforeID)
		subIssueRequest.BeforeID = &beforeIDInt64
	}

	subIssue, resp, err := client.SubIssue.Reprioritize(ctx, owner, repo, int64(issueNumber), subIssueRequest)
	if err != nil {
		return ghErrors.NewGitHubAPIErrorResponse(ctx,
			"failed to reprioritize sub-issue",
			resp,
			err,
		), nil, nil
	}

	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to reprioritize sub-issue", resp, body), nil, nil
	}

	sanitizeSubIssueTitleAndBody(subIssue)
	r, err := json.Marshal(subIssue)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to marshal response: %w", err)
	}

	output, err := subIssueOutput(subIssue)
	return utils.NewToolResultText(string(r)), output, err
}

// The two search engines want opposite things from a caller, so steering advice
// for one is counterproductive for the other: semantic rewards paraphrased
// natural language and degrades on boolean operators, while lexical needs the
// caller's literal keywords and handles OR fine. The description has to describe
// the engine the host will actually use.
const (
	searchIssuesSemanticDescription = "Search issues using natural-language semantic matching. Best for conceptual or paraphrased queries (e.g. \"login fails after password reset\"). Already scoped to is:issue."
	searchIssuesLexicalDescription  = "Search for issues in GitHub repositories using issues search syntax already scoped to is:issue"

	searchIssuesSemanticQueryDescription = "The search query, as natural language. When the user gives alternative wordings, include them as plain words rather than joining them with OR."
	searchIssuesLexicalQueryDescription  = "Search query using GitHub issues search syntax"
)

// SearchIssues creates a tool to search for issues.
func SearchIssues(t translations.TranslationHelperFunc, opts ...ToolOption) inventory.ServerTool {
	cfg := newToolConfig(opts)

	// Semantic is the default; however as it is not available on GHES, we fall back to
	// lexical search for that host type.
	mode := searchModeSemantic
	if cfg.hostType == utils.HostTypeGHES {
		mode = searchModeLexical
	}

	toolDescription := searchIssuesSemanticDescription
	queryDescription := searchIssuesSemanticQueryDescription
	if mode == searchModeLexical {
		toolDescription = searchIssuesLexicalDescription
		queryDescription = searchIssuesLexicalQueryDescription
	}

	schema := &jsonschema.Schema{
		Type: "object",
		Properties: map[string]*jsonschema.Schema{
			"query": {
				Type:        "string",
				Description: queryDescription,
			},
			"owner": {
				Type:        "string",
				Description: "Optional repository owner. If provided with repo, only issues for this repository are listed.",
			},
			"repo": {
				Type:        "string",
				Description: "Optional repository name. If provided with owner, only issues for this repository are listed.",
			},
			"sort": {
				Type:        "string",
				Description: "Sort field by number of matches of categories, defaults to best match",
				Enum: []any{
					"comments",
					"reactions",
					"reactions-+1",
					"reactions--1",
					"reactions-smile",
					"reactions-thinking_face",
					"reactions-heart",
					"reactions-tada",
					"interactions",
					"created",
					"updated",
				},
			},
			"order": {
				Type:        "string",
				Description: "Sort order",
				Enum:        []any{"asc", "desc"},
			},
		},
		Required: []string{"query"},
	}
	schema.Properties["fields"] = fieldsSchemaProperty(
		"Subset of fields to return for each issue result. If omitted, all fields are returned. Use this to reduce response size when you only need specific fields; omitting 'body', 'reactions', and 'labels' in particular drops the largest per-result data.",
		searchIssuesItemFieldEnum,
	)
	WithPagination(schema)

	return NewTool[SearchIssuesInput, SearchIssuesOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:        "search_issues",
			Description: t("TOOL_SEARCH_ISSUES_DESCRIPTION", toolDescription),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_SEARCH_ISSUES_USER_TITLE", "Search issues"),
				ReadOnlyHint: true,
			},
			InputSchema: schema,
		},
		scopes.PublicRead(scopes.Repo),
		func(ctx context.Context, deps ToolDependencies, _ *mcp.CallToolRequest, input SearchIssuesInput) (*mcp.CallToolResult, SearchIssuesOutput, error) {
			options := []searchOption{ifcSearchPostProcessOption(ctx, deps)}
			options = append(options, withFieldsFiltering(deps, "search_issues", input.Fields))
			result, response, err := searchIssuesHandler(ctx, deps, input, mode, options...)
			return result, structuredSearchIssuesOutput(response, input.Fields), err
		},
		normalizeTypedReadArguments(nil, false),
	)
}

// searchIssuesIFCPostProcess returns a searchPostProcessFn that attaches the
// IFC label for a search_issues result. It looks up the visibility (and, for
// private repos, collaborators) of every repository represented in the search
// payload and joins the labels via ifc.LabelSearchIssues. If any per-repo
// lookup fails the label is omitted to avoid misclassifying the result.
func searchIssuesIFCPostProcess(deps ToolDependencies) searchPostProcessFn {
	return func(ctx context.Context, result *github.IssuesSearchResult, callResult *mcp.CallToolResult) {
		if callResult == nil || callResult.IsError || result == nil {
			return
		}

		client, err := deps.GetClient(ctx)
		if err != nil {
			return
		}

		uniqueRepos := uniqueSearchIssuesRepos(result)
		visibilities := make([]bool, 0, len(uniqueRepos))
		for _, r := range uniqueRepos {
			isPrivate, err := FetchRepoIsPrivate(ctx, client, r.owner, r.repo)
			if err != nil {
				return
			}
			visibilities = append(visibilities, isPrivate)
		}

		if callResult.Meta == nil {
			callResult.Meta = mcp.Meta{}
		}
		callResult.Meta["ifc"] = ifc.LabelSearchIssues(visibilities)
	}
}

type searchIssuesRepoRef struct {
	owner string
	repo  string
}

// uniqueSearchIssuesRepos extracts the owner/repo pairs of every issue in the
// search result, preserving order of first appearance and deduplicating.
func uniqueSearchIssuesRepos(result *github.IssuesSearchResult) []searchIssuesRepoRef {
	if result == nil {
		return nil
	}
	seen := make(map[string]struct{})
	var out []searchIssuesRepoRef
	for _, issue := range result.Issues {
		if issue == nil {
			continue
		}
		owner, repo, ok := parseRepositoryURL(issue.GetRepositoryURL())
		if !ok {
			continue
		}
		key := owner + "/" + repo
		if _, dup := seen[key]; dup {
			continue
		}
		seen[key] = struct{}{}
		out = append(out, searchIssuesRepoRef{owner: owner, repo: repo})
	}
	return out
}

// parseRepositoryURL extracts the owner and repo from a GitHub API repository
// URL of the form https://api.github.com/repos/{owner}/{repo}.
func parseRepositoryURL(repoURL string) (string, string, bool) {
	if repoURL == "" {
		return "", "", false
	}
	const marker = "/repos/"
	idx := strings.LastIndex(repoURL, marker)
	if idx < 0 {
		return "", "", false
	}
	parts := strings.Split(strings.Trim(repoURL[idx+len(marker):], "/"), "/")
	if len(parts) < 2 || parts[0] == "" || parts[1] == "" {
		return "", "", false
	}
	return parts[0], parts[1], true
}

// SearchIssueResult wraps a REST search hit with its custom issue field values, fetched in a follow-up GraphQL nodes() query.
type SearchIssueResult struct {
	*github.Issue
	FieldValues []MinimalFieldValue `json:"field_values,omitempty"`
}

// sanitizeIssueTitleAndBody mutates issue.Title and issue.Body in place, applying the shared
// untrusted-content sanitization policy (pkg/sanitize). It exists for the handful of response
// paths — search_issues and search_pull_requests — that marshal a raw *github.Issue directly
// instead of routing through one of the convertToMinimal* helpers in minimal_types.go, which
// sanitize on their own. It is a no-op for a nil issue or unset fields.
func sanitizeIssueTitleAndBody(issue *github.Issue) {
	if issue == nil {
		return
	}
	if issue.Title != nil {
		issue.Title = new(sanitize.PlainText(*issue.Title))
	}
	if issue.Body != nil {
		issue.Body = new(sanitize.Content(*issue.Body))
	}
}

func sanitizeSubIssueTitleAndBody(issue *github.SubIssue) {
	if issue == nil {
		return
	}
	if issue.Title != nil {
		issue.Title = new(sanitize.PlainText(*issue.Title))
	}
	if issue.Body != nil {
		issue.Body = new(sanitize.Content(*issue.Body))
	}
}

// MarshalJSON serializes SearchIssueResult, suppressing the raw issue_field_values from the
// embedded REST response in favour of the normalized field_values populated via GraphQL enrichment.
// It also sanitizes the embedded issue's Title and Body in place: search_issues is one of the few
// response paths that marshals a raw *github.Issue directly rather than routing through a
// convertToMinimal* helper (see minimal_types.go), so sanitization must happen here instead.
func (r SearchIssueResult) MarshalJSON() ([]byte, error) {
	sanitizeIssueTitleAndBody(r.Issue)

	issueBytes, err := json.Marshal(r.Issue)
	if err != nil {
		return nil, err
	}
	var m map[string]json.RawMessage
	if err := json.Unmarshal(issueBytes, &m); err != nil {
		return nil, err
	}
	delete(m, "issue_field_values")
	if r.FieldValues != nil {
		fv, err := json.Marshal(r.FieldValues)
		if err != nil {
			return nil, err
		}
		m["field_values"] = fv
	}
	return json.Marshal(m)
}

// SearchIssuesResponse mirrors the REST IssuesSearchResult JSON shape and adds field_values
// per item, sourced from a single GraphQL nodes() round-trip.
type SearchIssuesResponse struct {
	Total             *int                `json:"total_count,omitempty"`
	IncompleteResults *bool               `json:"incomplete_results,omitempty"`
	Items             []SearchIssueResult `json:"items"`
}

type SearchIssuesOutput struct {
	Total             *int                    `json:"total_count,omitempty"`
	IncompleteResults *bool                   `json:"incomplete_results,omitempty"`
	Items             []SearchIssueOutputItem `json:"items"`
}

type SearchIssueOutputItem struct {
	Number            *int                    `json:"number,omitempty"`
	Title             *string                 `json:"title,omitempty"`
	Body              *string                 `json:"body,omitempty"`
	State             *string                 `json:"state,omitempty"`
	StateReason       *string                 `json:"state_reason,omitempty"`
	Draft             *bool                   `json:"draft,omitempty"`
	Locked            *bool                   `json:"locked,omitempty"`
	HTMLURL           *string                 `json:"html_url,omitempty"`
	User              *MinimalUser            `json:"user,omitempty"`
	AuthorAssociation *string                 `json:"author_association,omitempty"`
	Labels            []string                `json:"labels,omitempty"`
	Assignee          *string                 `json:"assignee,omitempty"`
	Assignees         []string                `json:"assignees,omitempty"`
	Milestone         *string                 `json:"milestone,omitempty"`
	Comments          *int                    `json:"comments,omitempty"`
	Reactions         *MinimalReactions       `json:"reactions,omitempty"`
	CreatedAt         *string                 `json:"created_at,omitempty"`
	UpdatedAt         *string                 `json:"updated_at,omitempty"`
	ClosedAt          *string                 `json:"closed_at,omitempty"`
	ClosedBy          *string                 `json:"closed_by,omitempty"`
	Type              *string                 `json:"type,omitempty"`
	RepositoryURL     *string                 `json:"repository_url,omitempty"`
	PullRequest       *SearchIssuePullRequest `json:"pull_request,omitempty"`
	FieldValues       *[]MinimalFieldValue    `json:"field_values,omitempty"`
}

type SearchIssuePullRequest struct {
	URL      *string `json:"url,omitempty"`
	HTMLURL  *string `json:"html_url,omitempty"`
	DiffURL  *string `json:"diff_url,omitempty"`
	PatchURL *string `json:"patch_url,omitempty"`
}

func structuredSearchIssuesOutput(response SearchIssuesResponse, fields []string) SearchIssuesOutput {
	output := SearchIssuesOutput{
		Total:             response.Total,
		IncompleteResults: response.IncompleteResults,
		Items:             make([]SearchIssueOutputItem, 0, len(response.Items)),
	}
	for _, item := range response.Items {
		output.Items = append(output.Items, searchIssueOutputItem(item, fields))
	}
	return output
}

func searchIssueOutputItem(result SearchIssueResult, fields []string) SearchIssueOutputItem {
	var output SearchIssueOutputItem
	issue := result.Issue
	if issue == nil {
		return output
	}
	selected := func(field string) bool {
		return len(fields) == 0 || slices.Contains(fields, field)
	}
	minimal := convertToMinimalIssue(issue)
	if selected("number") && issue.Number != nil {
		output.Number = new(minimal.Number)
	}
	if selected("title") && issue.Title != nil {
		output.Title = new(minimal.Title)
	}
	if selected("body") && issue.Body != nil {
		output.Body = new(minimal.Body)
	}
	if selected("state") && issue.State != nil {
		output.State = new(minimal.State)
	}
	if selected("state_reason") && issue.StateReason != nil {
		output.StateReason = new(minimal.StateReason)
	}
	if selected("draft") && issue.Draft != nil {
		output.Draft = new(minimal.Draft)
	}
	if selected("locked") && issue.Locked != nil {
		output.Locked = new(minimal.Locked)
	}
	if selected("html_url") && issue.HTMLURL != nil {
		output.HTMLURL = new(minimal.HTMLURL)
	}
	if selected("user") && issue.User != nil {
		output.User = minimal.User
	}
	if selected("author_association") && issue.AuthorAssociation != nil { //nolint:staticcheck // Keep the legacy search projection available.
		output.AuthorAssociation = new(minimal.AuthorAssociation)
	}
	if selected("labels") && issue.Labels != nil {
		output.Labels = minimal.Labels
	}
	if selected("assignee") && issue.Assignee != nil { //nolint:staticcheck // Keep the legacy search projection available.
		login := issue.Assignee.GetLogin() //nolint:staticcheck // Keep the legacy search projection available.
		output.Assignee = &login
	}
	if selected("assignees") && issue.Assignees != nil {
		output.Assignees = minimal.Assignees
	}
	if selected("milestone") && issue.Milestone != nil {
		output.Milestone = new(minimal.Milestone)
	}
	if selected("comments") && issue.Comments != nil {
		output.Comments = new(minimal.Comments)
	}
	if selected("reactions") && issue.Reactions != nil {
		output.Reactions = minimal.Reactions
	}
	if selected("created_at") && issue.CreatedAt != nil {
		output.CreatedAt = new(minimal.CreatedAt)
	}
	if selected("updated_at") && issue.UpdatedAt != nil {
		output.UpdatedAt = new(minimal.UpdatedAt)
	}
	if selected("closed_at") && issue.ClosedAt != nil {
		output.ClosedAt = new(minimal.ClosedAt)
	}
	if selected("closed_by") && issue.ClosedBy != nil {
		output.ClosedBy = new(minimal.ClosedBy)
	}
	if selected("type") && issue.Type != nil {
		output.Type = new(issue.Type.GetName())
	}
	if selected("repository_url") && issue.RepositoryURL != nil {
		output.RepositoryURL = new(issue.GetRepositoryURL())
	}
	if selected("pull_request") && issue.PullRequestLinks != nil {
		links := issue.PullRequestLinks
		output.PullRequest = &SearchIssuePullRequest{
			URL:      links.URL,
			HTMLURL:  links.HTMLURL,
			DiffURL:  links.DiffURL,
			PatchURL: links.PatchURL,
		}
	}
	if selected("field_values") && result.FieldValues != nil {
		output.FieldValues = &result.FieldValues
	}
	return output
}

// searchIssuesNodesQuery batches a nodes(ids:) lookup over the REST search results to retrieve
// each issue's custom field values in a single GraphQL request.
type searchIssuesNodesQuery struct {
	Nodes []struct {
		Issue struct {
			ID               githubv4.ID
			IssueFieldValues struct {
				Nodes []IssueFieldValueFragment
			} `graphql:"issueFieldValues(first: 25)"`
		} `graphql:"... on Issue"`
	} `graphql:"nodes(ids: $ids)"`
}

// fetchIssueFieldValuesByNodeID runs one GraphQL nodes() query for the given REST issues and
// returns a map of node_id -> flattened field values. Issues without a node_id are skipped, and
// an empty result set short-circuits the round-trip.
func fetchIssueFieldValuesByNodeID(ctx context.Context, gqlClient *githubv4.Client, issues []*github.Issue) (map[string][]MinimalFieldValue, error) {
	ids := make([]githubv4.ID, 0, len(issues))
	for _, iss := range issues {
		if iss == nil || iss.NodeID == nil || *iss.NodeID == "" {
			continue
		}
		ids = append(ids, githubv4.ID(*iss.NodeID))
	}
	if len(ids) == 0 {
		return nil, nil
	}

	var q searchIssuesNodesQuery
	if err := gqlClient.Query(ctx, &q, map[string]any{"ids": ids}); err != nil {
		return nil, err
	}

	result := make(map[string][]MinimalFieldValue, len(q.Nodes))
	for _, n := range q.Nodes {
		idStr, ok := n.Issue.ID.(string)
		if !ok || idStr == "" {
			continue
		}
		vals := make([]MinimalFieldValue, 0, len(n.Issue.IssueFieldValues.Nodes))
		for _, fv := range n.Issue.IssueFieldValues.Nodes {
			if m, ok := fragmentToMinimalFieldValue(fv); ok {
				vals = append(vals, m)
			}
		}
		result[idStr] = vals
	}
	return result, nil
}

// issueReadEnrichmentQuery fetches, in a single GraphQL round-trip, the custom field values,
// parent reference, closing pull request references, and sub-issue summary counts for the issues
// identified by their node IDs. It powers the issue_read `get` relationship signals without adding
// extra round-trips.
//
// closedByPullRequestsReferences needs includeClosedPrs so that a merged or closed pull request
// still explains why an issue was closed, and orderByState so that open pull requests come first.
// Only a handful of references are embedded because this enrichment runs on every issue_read `get`;
// totalCount is selected so that a truncated list is never mistaken for the complete set.
type issueReadEnrichmentQuery struct {
	Nodes []struct {
		Issue struct {
			ID               githubv4.ID
			IssueFieldValues struct {
				Nodes []IssueFieldValueFragment
			} `graphql:"issueFieldValues(first: 25)"`
			Parent *struct {
				Number githubv4.Int
				Title  githubv4.String
				State  githubv4.String
				URL    githubv4.String
				Author struct {
					Login githubv4.String
				}
				Repository struct {
					NameWithOwner githubv4.String
				}
			}
			ClosedByPullRequestsReferences struct {
				TotalCount githubv4.Int
				Nodes      []struct {
					Number githubv4.Int
					Title  githubv4.String
					State  githubv4.String
					URL    githubv4.String
					Author struct {
						Login githubv4.String
					}
					Repository struct {
						NameWithOwner githubv4.String
					}
				}
			} `graphql:"closedByPullRequestsReferences(first: 5, includeClosedPrs: true, orderByState: true)"`
			SubIssuesSummary struct {
				Total            githubv4.Int
				Completed        githubv4.Int
				PercentCompleted githubv4.Int
			}
		} `graphql:"... on Issue"`
	} `graphql:"nodes(ids: $ids)"`
}

// issueReadParent is the parent reference plus the metadata needed to make a lockdown
// safe-content decision about whether the (possibly cross-repo) parent title may be exposed.
type issueReadParent struct {
	Ref         MinimalIssueRef
	AuthorLogin string
}

// issueReadClosingPullRequest is a closing pull request reference plus the metadata needed to make
// a lockdown safe-content decision about it.
type issueReadClosingPullRequest struct {
	Ref         MinimalPullRequestRef
	AuthorLogin string
}

// issueReadEnrichment is the flattened result of the issue_read `get` enrichment query.
type issueReadEnrichment struct {
	FieldValues               []MinimalFieldValue
	Parent                    *issueReadParent
	ClosedByPullRequests      []issueReadClosingPullRequest
	ClosedByPullRequestsTotal int
	SubIssuesSummary          MinimalSubIssuesSummary
}

// fetchIssueReadEnrichment runs one GraphQL nodes() query for the given issue node ID and returns
// its field values, parent reference, closing pull requests, and sub-issue summary counts. Titles
// are sanitized here because they may originate from a different repository.
func fetchIssueReadEnrichment(ctx context.Context, gqlClient *githubv4.Client, nodeID string) (*issueReadEnrichment, error) {
	var q issueReadEnrichmentQuery
	if err := gqlClient.Query(ctx, &q, map[string]any{"ids": []githubv4.ID{githubv4.ID(nodeID)}}); err != nil {
		return nil, err
	}

	enrichment := &issueReadEnrichment{}
	for _, n := range q.Nodes {
		idStr, ok := n.Issue.ID.(string)
		if !ok || idStr != nodeID {
			continue
		}

		vals := make([]MinimalFieldValue, 0, len(n.Issue.IssueFieldValues.Nodes))
		for _, fv := range n.Issue.IssueFieldValues.Nodes {
			if m, ok := fragmentToMinimalFieldValue(fv); ok {
				vals = append(vals, m)
			}
		}
		enrichment.FieldValues = vals

		if p := n.Issue.Parent; p != nil {
			enrichment.Parent = &issueReadParent{
				Ref: newMinimalIssueRef(
					int(p.Number),
					string(p.Title),
					string(p.State),
					string(p.URL),
					string(p.Repository.NameWithOwner),
				),
				AuthorLogin: string(p.Author.Login),
			}
		}

		closing := make([]issueReadClosingPullRequest, 0, len(n.Issue.ClosedByPullRequestsReferences.Nodes))
		for _, pr := range n.Issue.ClosedByPullRequestsReferences.Nodes {
			closing = append(closing, issueReadClosingPullRequest{
				Ref: newMinimalPullRequestRef(
					int(pr.Number),
					string(pr.Title),
					string(pr.State),
					string(pr.URL),
					string(pr.Repository.NameWithOwner),
				),
				AuthorLogin: string(pr.Author.Login),
			})
		}
		enrichment.ClosedByPullRequests = closing
		enrichment.ClosedByPullRequestsTotal = int(n.Issue.ClosedByPullRequestsReferences.TotalCount)

		enrichment.SubIssuesSummary = MinimalSubIssuesSummary{
			Total:            int(n.Issue.SubIssuesSummary.Total),
			Completed:        int(n.Issue.SubIssuesSummary.Completed),
			PercentCompleted: int(n.Issue.SubIssuesSummary.PercentCompleted),
		}
		break
	}
	return enrichment, nil
}

// searchIssuesHandler runs the REST issues search, enriches each hit with custom field values
// fetched via a single follow-up GraphQL nodes() query, and applies any post-process options
// (e.g. IFC labelling).
func searchIssuesHandler(ctx context.Context, deps ToolDependencies, input SearchIssuesInput, mode searchMode, options ...searchOption) (*mcp.CallToolResult, SearchIssuesResponse, error) {
	const errorPrefix = "failed to search issues"

	var output SearchIssuesResponse
	query, opts, err := prepareSearchArgs(input, "issue", mode)
	if err != nil {
		return utils.NewToolResultError(err.Error()), output, nil
	}

	client, err := deps.GetClient(ctx)
	if err != nil {
		return utils.NewToolResultErrorFromErr(errorPrefix+": failed to get GitHub client", err), output, nil
	}
	result, resp, err := client.Search.Issues(ctx, query, opts)
	if err != nil {
		return utils.NewToolResultErrorFromErr(errorPrefix, err), output, nil
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return utils.NewToolResultErrorFromErr(errorPrefix+": failed to read response body", err), output, nil
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, errorPrefix, resp, body), output, nil
	}

	var fieldValuesByID map[string][]MinimalFieldValue
	if len(result.Issues) > 0 {
		gqlClient, err := deps.GetGQLClient(ctx)
		if err != nil {
			return utils.NewToolResultErrorFromErr(errorPrefix+": failed to get GitHub GraphQL client", err), output, nil
		}
		fieldValuesByID, err = fetchIssueFieldValuesByNodeID(ctx, gqlClient, result.Issues)
		if err != nil {
			const enrichmentError = errorPrefix + ": failed to fetch issue field values"
			if !isUnsupportedIssueFieldValuesSchemaError(err) {
				return ghErrors.NewGitHubGraphQLErrorResponse(ctx, enrichmentError, err), output, nil
			}
			// Older GHES schemas can lack this optional enrichment. Preserve the REST
			// search results while retaining the compatibility failure for observability.
			_, _ = ghErrors.NewGitHubGraphQLErrorToCtx(ctx, enrichmentError, err)
		}
	}

	items := make([]SearchIssueResult, 0, len(result.Issues))
	for _, iss := range result.Issues {
		hit := SearchIssueResult{Issue: iss}
		if iss != nil && iss.NodeID != nil {
			hit.FieldValues = fieldValuesByID[*iss.NodeID]
		}
		items = append(items, hit)
	}

	response := SearchIssuesResponse{
		Total:             result.Total,
		IncompleteResults: result.IncompleteResults,
		Items:             items,
	}

	cfg := searchConfig{}
	for _, opt := range options {
		opt(&cfg)
	}

	output = response
	filtered := false
	var payload any = response
	if len(cfg.fields) > 0 {
		filteredItems, err := filterEachField(response.Items, cfg.fields)
		if err != nil {
			return utils.NewToolResultErrorFromErr(errorPrefix+": failed to filter results", err), SearchIssuesResponse{}, nil
		}
		payload = map[string]any{
			"total_count":        response.Total,
			"incomplete_results": response.IncompleteResults,
			"items":              filteredItems,
		}
		filtered = true
	}

	r, err := json.Marshal(payload)
	if err != nil {
		return utils.NewToolResultErrorFromErr(errorPrefix+": failed to marshal response", err), SearchIssuesResponse{}, nil
	}

	if cfg.fieldsTool != "" {
		recordFieldsUsageFor(ctx, cfg.fieldsDeps, cfg.fieldsTool, response, filtered, len(r))
	}

	callResult := utils.NewToolResultText(string(r))
	if cfg.postProcess != nil {
		cfg.postProcess(ctx, result, callResult)
	}
	return callResult, output, nil
}

// IssueWriteUIResourceURI is the URI for the issue_write tool's MCP App UI resource.
const IssueWriteUIResourceURI = "ui://github-mcp-server/issue-write"

// issueWriteFormParams are the parameters the issue_write MCP App form collects
// and re-sends on submit. Any other parameter present on a call cannot be
// represented by the form, so hasNonFormParams bypasses the form rather than
// silently dropping it. Parent issue parameters are intentionally omitted
// because the current form cannot represent them.
var issueWriteFormParams = map[string]struct{}{
	"method":        {},
	"owner":         {},
	"repo":          {},
	"title":         {},
	"body":          {},
	"issue_number":  {},
	"issue_fields":  {},
	"labels":        {},
	"assignees":     {},
	"milestone":     {},
	"type":          {},
	"state":         {},
	"state_reason":  {},
	"duplicate_of":  {},
	"_ui_submitted": {},
}

// issueWriteAwaitingFormResult builds the "awaiting form submission" stub
// returned when issue_write hands off to the MCP App form. The body is shared
// by IssueWrite and LegacyIssueWrite. The result is marked IsError=true so
// agents that bail on error don't claim success or chain dependent tool calls
// while the user is still interacting with the form; the host renders the UI
// regardless because rendering is keyed off the tool's _meta.ui resourceUri.
func issueWriteAwaitingFormResult(method, owner, repo string, issueNumber int) *mcp.CallToolResult {
	var msg string
	if method == "update" {
		msg = fmt.Sprintf(
			"An interactive form has been shown to the user for editing issue #%d in %s/%s. "+
				"STOP — do not call any other tools, do not respond as if the issue was updated, "+
				"and do not claim the operation succeeded. The issue has NOT been updated yet; "+
				"only the form was rendered. Wait silently for the user to review and click Submit. "+
				"When they do, the real result will be delivered to your context automatically.",
			issueNumber, owner, repo,
		)
	} else {
		msg = fmt.Sprintf(
			"An interactive form has been shown to the user for creating a new issue in %s/%s. "+
				"STOP — do not call any other tools, do not respond as if the issue was created, "+
				"and do not claim the operation succeeded. The issue has NOT been created yet; "+
				"only the form was rendered. Wait silently for the user to review and click Submit. "+
				"When they do, the real result will be delivered to your context automatically.",
			owner, repo,
		)
	}
	return utils.NewToolResultAwaitingFormSubmission(msg)
}

// IssueWrite is the FeatureFlagIssueFields-enabled variant of issue_write
// (with the issue_fields parameter). LegacyIssueWrite is served when the flag
// is off. Both register under the tool name "issue_write"; exactly one is
// active at a time via mutually exclusive feature-flag annotations. When the
// flag is removed, delete LegacyIssueWrite outright and drop the feature-flag
// fields on IssueWrite.
func IssueWrite(t translations.TranslationHelperFunc) inventory.ServerTool {
	st := NewTool[IssueWriteInput, *IssueWriteOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:         "issue_write",
			OutputSchema: issueWriteOutputSchema(),
			Description:  t("TOOL_ISSUE_WRITE_DESCRIPTION", "Create a new or update an existing issue in a GitHub repository."),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_ISSUE_WRITE_USER_TITLE", "Create or update issue/pull request"),
				ReadOnlyHint: false,
			},
			Meta: mcp.Meta{
				"ui": map[string]any{
					"resourceUri": IssueWriteUIResourceURI,
					"visibility":  []string{"model", "app"},
				},
			},
			InputSchema: &jsonschema.Schema{
				Type: "object",
				Properties: map[string]*jsonschema.Schema{
					"method": {
						Type: "string",
						Description: `Write operation to perform on a single issue.
Options are:
- 'create' - creates a new issue.
- 'update' - updates an existing issue.
`,
						Enum: []any{"create", "update"},
					},
					"owner": {
						Type:        "string",
						Description: "Repository owner",
					},
					"repo": {
						Type:        "string",
						Description: "Repository name",
					},
					"issue_number": {
						Type:        "number",
						Description: "Issue number to update",
					},
					"parent_issue_number": {
						Type:        "number",
						Description: "Issue number of the parent issue. Only used when method is 'create' and cannot be combined with issue_fields. The new issue is created and attached to this parent in the same operation.",
						Minimum:     new(1.0),
					},
					"parent_owner": {
						Type:        "string",
						Description: "Repository owner of the parent issue. Must be provided with parent_repo. Omit both to use owner and repo. Only used when method is 'create' and parent_issue_number is provided.",
					},
					"parent_repo": {
						Type:        "string",
						Description: "Repository name of the parent issue. Must be provided with parent_owner. Omit both to use owner and repo. Only used when method is 'create' and parent_issue_number is provided.",
					},
					"title": {
						Type:        "string",
						Description: "Issue title",
					},
					"body": {
						Type:        "string",
						Description: "Issue body content",
					},
					"assignees": {
						Type:        "array",
						Description: "Usernames to assign to this issue",
						Items: &jsonschema.Schema{
							Type: "string",
						},
					},
					"labels": {
						Type:        "array",
						Description: "Labels to apply to this issue",
						Items: &jsonschema.Schema{
							Type: "string",
						},
					},
					"milestone": {
						Type:        "number",
						Description: "Milestone number",
					},
					"type": {
						AnyOf: []*jsonschema.Schema{
							{Type: "string", MinLength: new(1)},
							{Type: "null"},
						},
						Description: "Type of this issue. For updates, pass null to remove the current type. Only use if issue types are enabled for this repository. Use list_issue_types to get valid type values for this repository or its owner organization. If the repository doesn't support issue types, omit this parameter.",
					},
					"state": {
						Type:        "string",
						Description: "New state",
						Enum:        []any{"open", "closed"},
					},
					"state_reason": {
						Type:        "string",
						Description: "Reason for the state change. Ignored unless state is changed.",
						Enum:        []any{"completed", "not_planned", "duplicate"},
					},
					"duplicate_of": {
						Type:        "number",
						Description: "Issue number that this issue is a duplicate of. Required when state_reason is 'duplicate'.",
					},
					"issue_fields": {
						Type:        "array",
						Description: "Issue field values to set or clear. Each item requires 'field_name' and exactly one of 'value', 'field_option_name', or 'delete: true'.",
						Items: &jsonschema.Schema{
							Type:                 "object",
							AdditionalProperties: &jsonschema.Schema{Not: &jsonschema.Schema{}},
							Properties: map[string]*jsonschema.Schema{
								"field_name": {
									Type: "string",
									Description: "Issue field name (case-insensitive). Must match a field " +
										"returned by list_issue_fields for this repository or its organization.",
								},
								"value": {
									Types: []string{"string", "number", "boolean"},
									Description: "Value to set. Use for text, number, and date fields " +
										"(date as YYYY-MM-DD). For single-select fields, prefer " +
										"'field_option_name' so the option is validated before the API " +
										"call. Cannot be combined with 'field_option_name' or 'delete: true'.",
								},
								"field_option_name": {
									Type: "string",
									Description: "Option name for single-select fields. Validated against " +
										"the field's options before the API call. Cannot be combined with " +
										"'value' or 'delete: true'.",
								},
								"delete": {
									Type: "boolean",
									Description: "Set to true to clear this field's current value on the " +
										"issue. When false or omitted, this property is ignored. Cannot " +
										"be true when 'value' or 'field_option_name' is provided.",
								},
							},
							Required: []string{"field_name"},
						},
					},
				},
				Required: []string{"method", "owner", "repo"},
			},
		},
		publicRepositoryWriteScopeAccess(),
		func(ctx context.Context, deps ToolDependencies, req *mcp.CallToolRequest, input IssueWriteInput) (*mcp.CallToolResult, *IssueWriteOutput, error) {
			args, err := discussionNotificationArguments(input)
			if err != nil {
				return nil, nil, err
			}
			if input.TypeProvided && input.Type == nil {
				args["type"] = nil
			}
			method, err := RequiredParam[string](args, "method")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			owner, err := RequiredParam[string](args, "owner")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			repo, err := RequiredParam[string](args, "repo")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			// Hand off to the interactive MCP App form unless this call must
			// execute now (see shouldDeferToForm).
			formArgs := args
			if req != nil && req.Params != nil && len(req.Params.Arguments) > 0 {
				if err := json.Unmarshal(req.Params.Arguments, &formArgs); err != nil {
					return nil, nil, err
				}
			}
			if shouldDeferToForm(ctx, deps, req, formArgs, issueWriteFormParams) {
				issueNumber := 0
				if method == "update" {
					n, numErr := RequiredInt(args, "issue_number")
					if numErr != nil {
						return utils.NewToolResultError("issue_number is required for update method"), nil, nil
					}
					issueNumber = n
				}
				result := issueWriteAwaitingFormResult(method, owner, repo, issueNumber)
				output := &IssueWriteAwaitingOutput{
					Status: "awaiting_user_submission",
					Reason: "An interactive form is being shown to the user. The operation has not been performed.",
				}
				result.StructuredContent = output
				return result, &IssueWriteOutput{Method: method, Awaiting: output}, nil
			}

			title, err := OptionalParam[string](args, "title")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			// Optional parameters
			body, err := OptionalParam[string](args, "body")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			// Get assignees
			assignees, err := OptionalStringArrayParam(args, "assignees")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			assigneesValue, assigneesProvided := args["assignees"]
			assigneesProvided = assigneesProvided && assigneesValue != nil

			// Get labels
			labels, err := OptionalStringArrayParam(args, "labels")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			labelsValue, labelsProvided := args["labels"]
			labelsProvided = labelsProvided && labelsValue != nil

			// Get optional milestone
			milestone, err := OptionalIntParam(args, "milestone")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			var milestoneNum int
			if milestone != 0 {
				milestoneNum = milestone
			}

			// Get optional type
			issueTypeParam, issueTypeProvided, err := OptionalNullableStringParam(args, "type")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			issueType := ""
			if issueTypeParam != nil {
				issueType = *issueTypeParam
			}

			// Handle state, state_reason and duplicateOf parameters
			state, err := OptionalParam[string](args, "state")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			stateReason, err := OptionalParam[string](args, "state_reason")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			duplicateOf, err := OptionalIntParam(args, "duplicate_of")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			if duplicateOf != 0 && stateReason != "duplicate" {
				return utils.NewToolResultError("duplicate_of can only be used when state_reason is 'duplicate'"), nil, nil
			}
			if err := validateDuplicateState(state, stateReason, duplicateOf); err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			parentIssueNumber, err := OptionalIntParam(args, "parent_issue_number")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			parentValue, parentProvided := args["parent_issue_number"]
			parentProvided = parentProvided && parentValue != nil
			if parentProvided && parentIssueNumber < 1 {
				return utils.NewToolResultError("parent_issue_number must be greater than 0"), nil, nil
			}
			if parentProvided && method != "create" {
				return utils.NewToolResultError("parent_issue_number can only be used with the create method"), nil, nil
			}
			parentOwner, err := OptionalParam[string](args, "parent_owner")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			parentRepo, err := OptionalParam[string](args, "parent_repo")
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			if err := validateParentRepository(parentProvided, parentOwner, parentRepo); err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}

			var issueFields []issueWriteFieldInput
			issueFields, err = optionalIssueWriteFields(args)
			if err != nil {
				return utils.NewToolResultError(err.Error()), nil, nil
			}
			if parentProvided && len(issueFields) > 0 {
				return utils.NewToolResultError("issue_fields cannot be used with parent_issue_number"), nil, nil
			}

			client, err := deps.GetClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GitHub client", err), nil, nil
			}

			gqlClient, err := deps.GetGQLClient(ctx)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to get GraphQL client", err), nil, nil
			}

			var issueFieldValues []*github.IssueRequestFieldValue
			var fieldIDsToDelete []int64
			if len(issueFields) > 0 {
				issueFieldValues, fieldIDsToDelete, err = resolveIssueRequestFieldValues(ctx, gqlClient, owner, repo, issueFields)
				if err != nil {
					return utils.NewToolResultError(fmt.Sprintf("failed to resolve issue_fields: %v", err)), nil, nil
				}
			}

			switch method {
			case "create":
				if parentProvided {
					return issueWriteResult(method)(createIssueWithParent(ctx, client, gqlClient, owner, repo, title, body, assignees, labels, milestoneNum, issueType, parentIssueNumber, parentOwner, parentRepo))
				}

				return issueWriteResult(method)(createIssue(ctx, client, owner, repo, title, body, assignees, labels, milestoneNum, issueType, issueFieldValues))
			case "update":
				issueNumber, err := RequiredInt(args, "issue_number")
				if err != nil {
					return utils.NewToolResultError(err.Error()), nil, nil
				}
				return issueWriteResult(method)(updateIssue(ctx, client, gqlClient, owner, repo, issueNumber, title, body, assignees, labels, milestoneNum, issueType, issueFieldValues, fieldIDsToDelete, state, stateReason, duplicateOf, UpdateIssueOptions{
					AssigneesProvided: assigneesProvided,
					LabelsProvided:    labelsProvided,
					IssueTypeProvided: issueTypeProvided,
				}))
			default:
				return utils.NewToolResultError("invalid method, must be either 'create' or 'update'"), nil, nil
			}
		}, normalizeConsolidatedIssueArguments("write"))
	st.FeatureRule = issuesConsolidatedFeatureRule
	return st
}

type CreateIssueInput struct {
	RepositoryID githubv4.ID     `json:"repositoryId"`
	Title        githubv4.String `json:"title"`

	Body          *githubv4.String `json:"body,omitempty"`
	AssigneeIDs   *[]githubv4.ID   `json:"assigneeIds,omitempty"`
	MilestoneID   *githubv4.ID     `json:"milestoneId,omitempty"`
	LabelIDs      *[]githubv4.ID   `json:"labelIds,omitempty"`
	IssueTypeID   *githubv4.ID     `json:"issueTypeId,omitempty"`
	ParentIssueID *githubv4.ID     `json:"parentIssueId,omitempty"`
}

type createIssueMutation struct {
	CreateIssue struct {
		Issue struct {
			FullDatabaseID githubv4.String `graphql:"fullDatabaseId"`
			URL            githubv4.URI
		}
	} `graphql:"createIssue(input: $input)"`
}

type createIssueParentMetadataQuery struct {
	ChildRepository struct {
		ID            githubv4.ID
		NameWithOwner githubv4.String
	} `graphql:"childRepository: repository(owner: $owner, name: $repo)"`
	ParentRepository struct {
		Issue struct {
			ID     githubv4.ID
			Number githubv4.Int
		} `graphql:"issue(number: $parentIssueNumber)"`
	} `graphql:"parentRepository: repository(owner: $parentOwner, name: $parentRepo)"`
}

// CreateIssueWithParent creates an issue and attaches it to its parent in one GraphQL mutation.
func CreateIssueWithParent(
	ctx context.Context,
	client *github.Client,
	gqlClient *githubv4.Client,
	owner string,
	repo string,
	title string,
	body string,
	assignees []string,
	labels []string,
	milestoneNumber int,
	issueType string,
	parentIssueNumber int,
	parentOwner string,
	parentRepo string,
) (*mcp.CallToolResult, error) {
	result, _, err := createIssueWithParent(ctx, client, gqlClient, owner, repo, title, body, assignees, labels, milestoneNumber, issueType, parentIssueNumber, parentOwner, parentRepo)
	return result, err
}

func createIssueWithParent(ctx context.Context, client *github.Client, gqlClient *githubv4.Client, owner, repo, title, body string, assignees, labels []string, milestoneNumber int, issueType string, parentIssueNumber int, parentOwner, parentRepo string) (*mcp.CallToolResult, *MinimalResponse, error) {
	if title == "" {
		return utils.NewToolResultError("missing required parameter: title"), nil, nil
	}
	if parentIssueNumber < 1 {
		return utils.NewToolResultError("parent_issue_number must be greater than 0"), nil, nil
	}

	parentOwner, parentRepo = parentRepository(owner, repo, parentOwner, parentRepo)
	repositoryID, parentIssueID, err := resolveCreateIssueParent(ctx, gqlClient, owner, repo, parentOwner, parentRepo, parentIssueNumber)
	if err != nil {
		return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "failed to resolve parent issue", err), nil, nil
	}

	input := CreateIssueInput{
		RepositoryID:  repositoryID,
		Title:         githubv4.String(title),
		ParentIssueID: &parentIssueID,
	}
	if body != "" {
		input.Body = githubv4.NewString(githubv4.String(body))
	}

	if len(labels) > 0 {
		labelIDs := make([]githubv4.ID, 0, len(labels))
		for _, label := range labels {
			labelID, err := getLabelID(ctx, gqlClient, owner, repo, label)
			if err != nil {
				return ghErrors.NewGitHubGraphQLErrorResponse(ctx, fmt.Sprintf("failed to resolve label %q", label), err), nil, nil
			}
			labelIDs = append(labelIDs, labelID)
		}
		input.LabelIDs = &labelIDs
	}

	if len(assignees) > 0 {
		assigneeIDs := make([]githubv4.ID, 0, len(assignees))
		for _, assignee := range assignees {
			assigneeID, err := resolveUserID(ctx, gqlClient, assignee)
			if err != nil {
				return ghErrors.NewGitHubGraphQLErrorResponse(ctx, fmt.Sprintf("failed to resolve assignee %q", assignee), err), nil, nil
			}
			assigneeIDs = append(assigneeIDs, assigneeID)
		}
		input.AssigneeIDs = &assigneeIDs
	}

	if milestoneNumber != 0 {
		milestoneID, err := resolveMilestoneID(ctx, gqlClient, owner, repo, milestoneNumber)
		if err != nil {
			return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "failed to resolve milestone", err), nil, nil
		}
		input.MilestoneID = &milestoneID
	}

	if issueType != "" {
		issueTypeID, resp, err := resolveIssueTypeID(ctx, client, owner, repo, issueType)
		if err != nil {
			return ghErrors.NewGitHubAPIErrorResponse(ctx, fmt.Sprintf("failed to resolve issue type %q", issueType), resp, err), nil, nil
		}
		input.IssueTypeID = &issueTypeID
	}

	var mutation createIssueMutation
	if err := gqlClient.Mutate(ctx, &mutation, input, nil); err != nil {
		return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "failed to create issue", err), nil, nil
	}
	if mutation.CreateIssue.Issue.FullDatabaseID == "" || mutation.CreateIssue.Issue.URL.URL == nil {
		return utils.NewToolResultError("failed to create issue: response did not include the created issue"), nil, nil
	}

	response := MinimalResponse{
		ID:  string(mutation.CreateIssue.Issue.FullDatabaseID),
		URL: mutation.CreateIssue.Issue.URL.String(),
	}
	encoded, err := json.Marshal(response)
	if err != nil {
		return utils.NewToolResultErrorFromErr("failed to marshal response", err), nil, nil
	}
	return utils.NewToolResultText(string(encoded)), &response, nil
}

func parentRepository(owner, repo, parentOwner, parentRepo string) (string, string) {
	if parentOwner == "" && parentRepo == "" {
		return owner, repo
	}
	return parentOwner, parentRepo
}

func validateParentRepository(parentProvided bool, parentOwner, parentRepo string) error {
	if !parentProvided {
		if parentOwner != "" || parentRepo != "" {
			return errors.New("parent_owner and parent_repo can only be used when parent_issue_number is provided")
		}
		return nil
	}
	if (parentOwner == "") != (parentRepo == "") {
		return errors.New("parent_owner and parent_repo must be provided together")
	}
	return nil
}

func resolveCreateIssueParent(ctx context.Context, gqlClient *githubv4.Client, owner, repo, parentOwner, parentRepo string, parentIssueNumber int) (githubv4.ID, githubv4.ID, error) {
	var query createIssueParentMetadataQuery
	variables := map[string]any{
		"owner":             githubv4.String(owner),
		"repo":              githubv4.String(repo),
		"parentOwner":       githubv4.String(parentOwner),
		"parentRepo":        githubv4.String(parentRepo),
		"parentIssueNumber": githubv4.Int(parentIssueNumber), // #nosec G115 - issue numbers are small positive integers
	}
	if err := gqlClient.Query(ctx, &query, variables); err != nil {
		return "", "", err
	}
	if query.ChildRepository.NameWithOwner == "" {
		return "", "", fmt.Errorf("repository %s/%s was not found", owner, repo)
	}
	if query.ParentRepository.Issue.Number == 0 {
		return "", "", fmt.Errorf("parent issue #%d was not found in %s/%s", parentIssueNumber, parentOwner, parentRepo)
	}
	return query.ChildRepository.ID, query.ParentRepository.Issue.ID, nil
}

func resolveUserID(ctx context.Context, gqlClient *githubv4.Client, login string) (githubv4.ID, error) {
	var query struct {
		User struct {
			ID    githubv4.ID
			Login githubv4.String
		} `graphql:"user(login: $login)"`
	}
	if err := gqlClient.Query(ctx, &query, map[string]any{"login": githubv4.String(login)}); err != nil {
		return "", err
	}
	if query.User.Login == "" {
		return "", fmt.Errorf("user %q was not found", login)
	}
	return query.User.ID, nil
}

func resolveMilestoneID(ctx context.Context, gqlClient *githubv4.Client, owner, repo string, milestoneNumber int) (githubv4.ID, error) {
	var query struct {
		Repository struct {
			Milestone struct {
				ID     githubv4.ID
				Number githubv4.Int
			} `graphql:"milestone(number: $milestoneNumber)"`
		} `graphql:"repository(owner: $owner, name: $repo)"`
	}
	variables := map[string]any{
		"owner":           githubv4.String(owner),
		"repo":            githubv4.String(repo),
		"milestoneNumber": githubv4.Int(milestoneNumber), // #nosec G115 - milestone numbers are small positive integers
	}
	if err := gqlClient.Query(ctx, &query, variables); err != nil {
		return "", err
	}
	if query.Repository.Milestone.Number == 0 {
		return "", fmt.Errorf("milestone #%d was not found in %s/%s", milestoneNumber, owner, repo)
	}
	return query.Repository.Milestone.ID, nil
}

func resolveIssueTypeID(ctx context.Context, client *github.Client, owner, repo, issueTypeName string) (githubv4.ID, *github.Response, error) {
	req, err := client.NewRequest(ctx, "GET", fmt.Sprintf("repos/%s/%s/issue-types", owner, repo), nil)
	if err != nil {
		return "", nil, err
	}

	var issueTypes []*github.IssueType
	resp, err := client.Do(req, &issueTypes)
	if resp != nil && resp.Body != nil {
		defer func() { _ = resp.Body.Close() }()
	}
	if err != nil {
		return "", resp, err
	}
	for _, issueType := range issueTypes {
		if issueType != nil && strings.EqualFold(strings.TrimSpace(issueType.GetName()), strings.TrimSpace(issueTypeName)) {
			if issueType.GetNodeID() == "" {
				return "", resp, fmt.Errorf("issue type %q is missing a node ID", issueTypeName)
			}
			return githubv4.ID(issueType.GetNodeID()), resp, nil
		}
	}
	return "", resp, fmt.Errorf("issue type %q was not found in %s/%s", issueTypeName, owner, repo)
}

func unappliedIssueLabelsError(requested []string, issue *github.Issue) error {
	applied := make([]string, 0, len(issue.Labels))
	for _, label := range issue.Labels {
		if label != nil {
			applied = append(applied, label.GetName())
		}
	}

	missing := issueLabelDifference(requested, applied)
	unexpected := issueLabelDifference(applied, requested)
	if len(missing) == 0 && len(unexpected) == 0 {
		return nil
	}

	return fmt.Errorf(
		"requested=%q, applied=%q, missing=%q, unexpected=%q, issue_url=%q; the caller may lack AddLabelsToLabelable permission",
		requested,
		applied,
		missing,
		unexpected,
		issue.GetHTMLURL(),
	)
}

func issueLabelDifference(labels, other []string) []string {
	var difference []string
	for _, label := range labels {
		if containsIssueLabel(other, label) || containsIssueLabel(difference, label) {
			continue
		}
		difference = append(difference, label)
	}
	return difference
}

func containsIssueLabel(labels []string, target string) bool {
	for _, label := range labels {
		if strings.EqualFold(label, target) {
			return true
		}
	}
	return false
}

func CreateIssue(ctx context.Context, client *github.Client, owner string, repo string, title string, body string, assignees []string, labels []string, milestoneNum int, issueType string, issueFieldValues []*github.IssueRequestFieldValue) (*mcp.CallToolResult, error) {
	result, _, err := createIssue(ctx, client, owner, repo, title, body, assignees, labels, milestoneNum, issueType, issueFieldValues)
	return result, err
}

func createIssue(ctx context.Context, client *github.Client, owner string, repo string, title string, body string, assignees []string, labels []string, milestoneNum int, issueType string, issueFieldValues []*github.IssueRequestFieldValue) (*mcp.CallToolResult, *MinimalResponse, error) {
	if title == "" {
		return utils.NewToolResultError("missing required parameter: title"), nil, nil
	}

	// Create the issue request
	issueRequest := github.CreateIssueRequest{
		Title:            title,
		Body:             new(body),
		Assignees:        assignees,
		Labels:           labels,
		IssueFieldValues: issueFieldValues,
	}

	if milestoneNum != 0 {
		issueRequest.Milestone = &milestoneNum
	}

	if issueType != "" {
		issueRequest.Type = new(issueType)
	}

	issue, resp, err := client.Issues.Create(ctx, owner, repo, issueRequest)
	if err != nil {
		return ghErrors.NewGitHubAPIErrorResponse(ctx,
			"failed to create issue",
			resp,
			err,
		), nil, nil
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusCreated {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return utils.NewToolResultErrorFromErr("failed to read response body", err), nil, nil
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to create issue", resp, body), nil, nil
	}

	if len(labels) > 0 {
		if err := unappliedIssueLabelsError(labels, issue); err != nil {
			return ghErrors.NewGitHubAPIErrorResponse(ctx, "issue created but requested labels were not fully applied", resp, err), nil, nil
		}
	}

	// Return minimal response with just essential information
	minimalResponse := MinimalResponse{
		ID:  fmt.Sprintf("%d", issue.GetID()),
		URL: issue.GetHTMLURL(),
	}

	r, err := json.Marshal(minimalResponse)
	if err != nil {
		return utils.NewToolResultErrorFromErr("failed to marshal response", err), nil, nil
	}

	return utils.NewToolResultText(string(r)), &minimalResponse, nil
}

// UpdateIssueOptions controls which optional fields are included in an issue update request.
type UpdateIssueOptions struct {
	// AssigneesProvided sends the assignees field even when the slice is empty.
	AssigneesProvided bool
	// LabelsProvided sends the labels field even when the slice is empty.
	LabelsProvided bool
	// IssueTypeProvided sends the type field, including an explicit clear.
	IssueTypeProvided bool
}

func UpdateIssue(ctx context.Context, client *github.Client, gqlClient *githubv4.Client, owner string, repo string, issueNumber int, title string, body string, assignees []string, labels []string, milestoneNum int, issueType string, issueFieldValues []*github.IssueRequestFieldValue, fieldIDsToDelete []int64, state string, stateReason string, duplicateOf int, opts ...UpdateIssueOptions) (*mcp.CallToolResult, error) {
	result, _, err := updateIssue(ctx, client, gqlClient, owner, repo, issueNumber, title, body, assignees, labels, milestoneNum, issueType, issueFieldValues, fieldIDsToDelete, state, stateReason, duplicateOf, opts...)
	return result, err
}

func updateIssue(ctx context.Context, client *github.Client, gqlClient *githubv4.Client, owner string, repo string, issueNumber int, title string, body string, assignees []string, labels []string, milestoneNum int, issueType string, issueFieldValues []*github.IssueRequestFieldValue, fieldIDsToDelete []int64, state string, stateReason string, duplicateOf int, opts ...UpdateIssueOptions) (*mcp.CallToolResult, *MinimalResponse, error) {
	// UpdateIssue is exported and may be called without the tool handler.
	if err := validateDuplicateState(state, stateReason, duplicateOf); err != nil {
		return utils.NewToolResultError(err.Error()), nil, nil
	}

	updateOptions := UpdateIssueOptions{
		AssigneesProvided: len(assignees) > 0,
		LabelsProvided:    len(labels) > 0,
	}
	for _, opt := range opts {
		updateOptions.AssigneesProvided = updateOptions.AssigneesProvided || opt.AssigneesProvided
		updateOptions.LabelsProvided = updateOptions.LabelsProvided || opt.LabelsProvided
		updateOptions.IssueTypeProvided = updateOptions.IssueTypeProvided || opt.IssueTypeProvided
	}

	// Create the issue request with only provided fields
	issueRequest := github.UpdateIssueRequest{}

	// Set optional parameters if provided
	if title != "" {
		issueRequest.Title = new(title)
	}

	if body != "" {
		issueRequest.Body = new(body)
	}

	if updateOptions.LabelsProvided {
		issueRequest.Labels = labels
	}

	if updateOptions.AssigneesProvided {
		issueRequest.Assignees = assignees
	}

	if milestoneNum != 0 {
		issueRequest.Milestone = &milestoneNum
	}

	if issueType != "" {
		issueRequest.Type = new(issueType)
	}

	// Field IDs to clear via DELETE after the PATCH. See the post-PATCH loop
	// for why we can't just rely on REST set semantics.
	var fallbackDeleteFieldIDs []int64

	if len(issueFieldValues) > 0 || len(fieldIDsToDelete) > 0 {
		// REST PATCH uses set semantics, so fetch existing values, merge in
		// the new ones, then drop anything explicitly deleted.
		existing, err := fetchExistingIssueFieldValues(ctx, gqlClient, owner, repo, issueNumber)
		if err != nil {
			return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "failed to fetch existing issue field values", err), nil, nil
		}
		merged := mergeIssueFieldValues(existing, issueFieldValues)
		if len(fieldIDsToDelete) > 0 {
			deleteSet := make(map[int64]bool, len(fieldIDsToDelete))
			for _, id := range fieldIDsToDelete {
				deleteSet[id] = true
			}
			kept := make([]*github.IssueRequestFieldValue, 0, len(merged))
			for _, v := range merged {
				if !deleteSet[v.FieldID] {
					kept = append(kept, v)
				}
			}
			merged = kept
		}
		if len(merged) == 0 && len(fieldIDsToDelete) > 0 {
			// Only queue DELETEs for fields actually present — the endpoint
			// returns 404 otherwise, and "delete a field that isn't set" should
			// stay a no-op (callers often invoke delete:true idempotently).
			existingIDs := make(map[int64]bool, len(existing))
			for _, e := range existing {
				existingIDs[e.FieldID] = true
			}
			for _, id := range fieldIDsToDelete {
				if existingIDs[id] {
					fallbackDeleteFieldIDs = append(fallbackDeleteFieldIDs, id)
				}
			}
		} else {
			issueRequest.IssueFieldValues = merged
		}
	}

	updatedIssue, resp, err := patchIssue(ctx, client, owner, repo, issueNumber, issueRequest, issueType, updateOptions.IssueTypeProvided)
	if err != nil {
		return ghErrors.NewGitHubAPIErrorResponse(ctx,
			"failed to update issue",
			resp,
			err,
		), nil, nil
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}
		return ghErrors.NewGitHubAPIStatusErrorResponse(ctx, "failed to update issue", resp, body), nil, nil
	}

	// Per-field DELETE fallback. The PATCH can't clear field values when the
	// merged set is empty — go-github's `omitempty` strips the empty slice
	// and the dotcom REST handler skips its issue_field_values block when the
	// key is absent. Errors are aggregated (not short-circuited) so callers
	// can see which fields succeeded and which need retry.
	if len(fallbackDeleteFieldIDs) > 0 {
		var failedIDs, succeededIDs []int64
		var firstFailureErr error
		var firstFailureResp *github.Response
		for _, fieldID := range fallbackDeleteFieldIDs {
			path := fmt.Sprintf("repos/%s/%s/issues/%d/issue-field-values/%d", owner, repo, issueNumber, fieldID)
			req, err := client.NewRequest(ctx, http.MethodDelete, path, nil)
			if err != nil {
				failedIDs = append(failedIDs, fieldID)
				if firstFailureErr == nil {
					firstFailureErr = err
				}
				continue
			}
			delResp, err := client.Do(req, nil)
			if err != nil {
				failedIDs = append(failedIDs, fieldID)
				if firstFailureErr == nil {
					firstFailureErr = err
					firstFailureResp = delResp
				}
				continue
			}
			succeededIDs = append(succeededIDs, fieldID)
			_ = delResp.Body.Close()
		}
		if len(failedIDs) > 0 {
			msg := fmt.Sprintf("failed to clear issue field values: failed=%v, cleared=%v", failedIDs, succeededIDs)
			return ghErrors.NewGitHubAPIErrorResponse(ctx, msg, firstFailureResp, firstFailureErr), nil, nil
		}
	}

	// Use GraphQL API for state updates
	if state != "" {
		// Get target issue ID (and duplicate issue ID if needed)
		issueID, duplicateIssueID, err := fetchIssueIDs(ctx, gqlClient, owner, repo, issueNumber, duplicateOf)
		if err != nil {
			return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "Failed to find issues", err), nil, nil
		}

		switch state {
		case "open":
			// Use ReopenIssue mutation for opening
			var mutation struct {
				ReopenIssue struct {
					Issue struct {
						ID     githubv4.ID
						Number githubv4.Int
						URL    githubv4.String
						State  githubv4.String
					}
				} `graphql:"reopenIssue(input: $input)"`
			}

			err = gqlClient.Mutate(ctx, &mutation, githubv4.ReopenIssueInput{
				IssueID: issueID,
			}, nil)
			if err != nil {
				return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "Failed to reopen issue", err), nil, nil
			}
		case "closed":
			// Use CloseIssue mutation for closing
			var mutation struct {
				CloseIssue struct {
					Issue struct {
						ID     githubv4.ID
						Number githubv4.Int
						URL    githubv4.String
						State  githubv4.String
					}
				} `graphql:"closeIssue(input: $input)"`
			}

			stateReasonValue := getCloseStateReason(stateReason)
			closeInput := CloseIssueInput{
				IssueID:     issueID,
				StateReason: &stateReasonValue,
			}

			// Set duplicate issue ID if needed
			if stateReason == "duplicate" {
				closeInput.DuplicateIssueID = &duplicateIssueID
			}

			err = gqlClient.Mutate(ctx, &mutation, closeInput, nil)
			if err != nil {
				return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "Failed to close issue", err), nil, nil
			}
		}
	}

	if updateOptions.LabelsProvided {
		if err := unappliedIssueLabelsError(labels, updatedIssue); err != nil {
			return ghErrors.NewGitHubAPIErrorResponse(ctx, "issue updated but requested labels were not fully applied", resp, err), nil, nil
		}
	}

	// Return minimal response with just essential information
	minimalResponse := MinimalResponse{
		ID:  fmt.Sprintf("%d", updatedIssue.GetID()),
		URL: updatedIssue.GetHTMLURL(),
	}

	r, err := json.Marshal(minimalResponse)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to marshal response: %w", err)
	}

	return utils.NewToolResultText(string(r)), &minimalResponse, nil
}

func validateDuplicateState(state, stateReason string, duplicateOf int) error {
	if state == "closed" && stateReason == "duplicate" && duplicateOf == 0 {
		return fmt.Errorf("duplicate_of must be provided when state_reason is 'duplicate'")
	}
	return nil
}

type updateIssueRequestWithNullableType struct {
	github.UpdateIssueRequest
	Type *string `json:"type"`
}

func patchIssue(ctx context.Context, client *github.Client, owner, repo string, issueNumber int, issueRequest github.UpdateIssueRequest, issueType string, issueTypeProvided bool) (*github.Issue, *github.Response, error) {
	if !issueTypeProvided || issueType != "" {
		return client.Issues.Update(ctx, owner, repo, issueNumber, issueRequest)
	}

	apiURL := fmt.Sprintf("repos/%s/%s/issues/%d", owner, repo, issueNumber)
	body := &updateIssueRequestWithNullableType{UpdateIssueRequest: issueRequest}
	req, err := client.NewRequest(ctx, http.MethodPatch, apiURL, body)
	if err != nil {
		return nil, nil, err
	}

	issue := &github.Issue{}
	resp, err := client.Do(req, issue)
	return issue, resp, err
}

// ListIssues creates a tool to list issues in a GitHub repository.
type ListIssuesInput struct {
	Owner        string                  `json:"owner"`
	Repo         string                  `json:"repo"`
	State        string                  `json:"state,omitempty"`
	Labels       []string                `json:"labels,omitempty"`
	OrderBy      string                  `json:"orderBy,omitempty"`
	Direction    string                  `json:"direction,omitempty"`
	Since        string                  `json:"since,omitempty"`
	FieldFilters []IssueFieldFilterInput `json:"field_filters,omitempty"`
	Fields       []string                `json:"fields,omitempty"`
	After        string                  `json:"after,omitempty"`
	PerPage      *int                    `json:"perPage,omitempty"`
	Page         json.RawMessage         `json:"page,omitempty"`
}

type IssueFieldFilterInput struct {
	FieldName string `json:"field_name"`
	Value     string `json:"value"`
}

type ListIssuesOutput struct {
	Issues     []ListIssueOutput `json:"issues"`
	TotalCount int               `json:"totalCount"`
	PageInfo   MinimalPageInfo   `json:"pageInfo"`
}

type ListIssueOutput struct {
	Number      *int                 `json:"number,omitempty"`
	Title       *string              `json:"title,omitempty"`
	Body        *string              `json:"body,omitempty"`
	State       *string              `json:"state,omitempty"`
	User        *MinimalUser         `json:"user,omitempty"`
	Labels      *[]string            `json:"labels,omitempty"`
	Assignees   *[]string            `json:"assignees,omitempty"`
	Comments    *int                 `json:"comments,omitempty"`
	CreatedAt   *string              `json:"created_at,omitempty"`
	UpdatedAt   *string              `json:"updated_at,omitempty"`
	FieldValues *[]MinimalFieldValue `json:"field_values,omitempty"`
}

func structuredListIssuesOutput(response MinimalIssuesResponse, fields []string) ListIssuesOutput {
	output := ListIssuesOutput{
		Issues:     make([]ListIssueOutput, 0, len(response.Issues)),
		TotalCount: response.TotalCount,
		PageInfo:   response.PageInfo,
	}
	selected := func(field string) bool {
		return len(fields) == 0 || slices.Contains(fields, field)
	}
	for _, issue := range response.Issues {
		item := ListIssueOutput{}
		if selected("number") {
			item.Number = new(issue.Number)
		}
		if selected("title") {
			item.Title = new(issue.Title)
		}
		if selected("body") && issue.Body != "" {
			item.Body = new(issue.Body)
		}
		if selected("state") {
			item.State = new(issue.State)
		}
		if selected("user") && issue.User != nil {
			item.User = issue.User
		}
		if selected("labels") && len(issue.Labels) > 0 {
			item.Labels = &issue.Labels
		}
		if selected("assignees") {
			item.Assignees = &issue.Assignees
		}
		if selected("comments") && issue.Comments != 0 {
			item.Comments = new(issue.Comments)
		}
		if selected("created_at") && issue.CreatedAt != "" {
			item.CreatedAt = new(issue.CreatedAt)
		}
		if selected("updated_at") && issue.UpdatedAt != "" {
			item.UpdatedAt = new(issue.UpdatedAt)
		}
		if selected("field_values") && len(issue.FieldValues) > 0 {
			item.FieldValues = &issue.FieldValues
		}
		output.Issues = append(output.Issues, item)
	}
	return output
}

func ListIssues(t translations.TranslationHelperFunc) inventory.ServerTool {
	schema := &jsonschema.Schema{
		Type: "object",
		Properties: map[string]*jsonschema.Schema{
			"owner": {
				Type:        "string",
				Description: "Repository owner",
			},
			"repo": {
				Type:        "string",
				Description: "Repository name",
			},
			"state": {
				Type:        "string",
				Description: "Filter by state, by default both open and closed issues are returned when not provided",
				Enum:        []any{"OPEN", "CLOSED"},
			},
			"labels": {
				Type:        "array",
				Description: "Filter by labels",
				Items: &jsonschema.Schema{
					Type: "string",
				},
			},
			"orderBy": {
				Type:        "string",
				Description: "Order issues by field. If provided, the 'direction' also needs to be provided.",
				Enum:        []any{"CREATED_AT", "UPDATED_AT", "COMMENTS"},
			},
			"direction": {
				Type:        "string",
				Description: "Order direction. If provided, the 'orderBy' also needs to be provided.",
				Enum:        []any{"ASC", "DESC"},
			},
			"since": {
				Type:        "string",
				Description: "Filter by date (ISO 8601 timestamp)",
			},
			"field_filters": {
				Type:        "array",
				Description: "Filter by custom issue field values. Each entry takes a field_name and a value; the server looks up the field and coerces the value to its type (single-select option name, text, number, or YYYY-MM-DD date).",
				Items: &jsonschema.Schema{
					Type: "object",
					Properties: map[string]*jsonschema.Schema{
						"field_name": {
							Type:        "string",
							Description: "Name of the custom field (e.g. \"Priority\"). Case-insensitive.",
						},
						"value": {
							Type:        "string",
							Description: "Value to filter on. For single-select fields, the option name (e.g. \"P1\"). For dates, YYYY-MM-DD. For numbers, the numeric value as a string. For text, the text value.",
						},
					},
					Required: []string{"field_name", "value"},
				},
			},
		},
		Required: []string{"owner", "repo"},
	}
	schema.Properties["fields"] = fieldsSchemaProperty(
		"Subset of fields to return for each issue. If omitted, all fields are returned. Use this to reduce response size when you only need specific fields; omitting 'body' and 'field_values' in particular drops the largest per-result data.",
		listIssuesItemFieldEnum,
	)
	WithCursorPagination(schema)

	st := NewTool[ListIssuesInput, ListIssuesOutput](
		ToolsetMetadataIssues,
		mcp.Tool{
			Name:        "list_issues",
			Description: t("TOOL_LIST_ISSUES_DESCRIPTION", "List issues in a GitHub repository. For pagination, use the 'endCursor' from the previous response's 'pageInfo' in the 'after' parameter."),
			Annotations: &mcp.ToolAnnotations{
				Title:        t("TOOL_LIST_ISSUES_USER_TITLE", "List issues"),
				ReadOnlyHint: true,
			},
			InputSchema: schema,
		},
		scopes.PublicRead(scopes.Repo),
		func(ctx context.Context, deps ToolDependencies, _ *mcp.CallToolRequest, input ListIssuesInput) (*mcp.CallToolResult, ListIssuesOutput, error) {
			var output ListIssuesOutput
			var err error
			if input.Owner == "" {
				return utils.NewToolResultError("missing required parameter: owner"), output, nil
			}
			if input.Repo == "" {
				return utils.NewToolResultError("missing required parameter: repo"), output, nil
			}
			owner, repo := input.Owner, input.Repo

			// Set optional parameters if provided
			state := input.State

			// Normalize and filter by state
			state = strings.ToUpper(state)
			var states []githubv4.IssueState

			switch state {
			case "OPEN", "CLOSED":
				states = []githubv4.IssueState{githubv4.IssueState(state)}
			default:
				states = []githubv4.IssueState{githubv4.IssueStateOpen, githubv4.IssueStateClosed}
			}

			// Get labels
			labels := input.Labels
			orderBy := input.OrderBy
			direction := input.Direction

			// Normalize and validate orderBy
			orderBy = strings.ToUpper(orderBy)
			switch orderBy {
			case "CREATED_AT", "UPDATED_AT", "COMMENTS":
				// Valid, keep as is
			default:
				orderBy = "CREATED_AT"
			}

			// Normalize and validate direction
			direction = strings.ToUpper(direction)
			switch direction {
			case "ASC", "DESC":
				// Valid, keep as is
			default:
				direction = "DESC"
			}

			since := input.Since

			// There are two optional parameters: since and labels.
			var sinceTime time.Time
			var hasSince bool
			if since != "" {
				sinceTime, err = parseISOTimestamp(since)
				if err != nil {
					return utils.NewToolResultError(fmt.Sprintf("failed to list issues: %s", err.Error())), output, nil
				}
				hasSince = true
			}
			hasLabels := len(labels) > 0

			rawFilters := make([]rawFieldFilter, 0, len(input.FieldFilters))
			for _, filter := range input.FieldFilters {
				if filter.FieldName == "" {
					return utils.NewToolResultError("field_filters entry: missing required parameter: field_name"), output, nil
				}
				if filter.Value == "" {
					return utils.NewToolResultError(fmt.Sprintf("field_filters entry %q: missing required parameter: value", filter.FieldName)), output, nil
				}
				rawFilters = append(rawFilters, rawFieldFilter{Name: filter.FieldName, Value: filter.Value})
			}

			// Get pagination parameters and convert to GraphQL format
			pagination := CursorPaginationParams{PerPage: 30, After: input.After}
			if input.PerPage != nil {
				pagination.PerPage = *input.PerPage
			}

			// Check if someone tried to use page-based pagination instead of cursor-based
			if len(input.Page) > 0 {
				return utils.NewToolResultError("This tool uses cursor-based pagination. Use the 'after' parameter with the 'endCursor' value from the previous response instead of 'page'."), output, nil
			}

			// Check if pagination parameters were explicitly provided
			paginationExplicit := input.PerPage != nil

			paginationParams, err := pagination.ToGraphQLParams()
			if err != nil {
				return nil, output, err
			}

			// Use default of 30 if pagination was not explicitly provided
			if !paginationExplicit {
				defaultFirst := int32(DefaultGraphQLPageSize)
				paginationParams.First = &defaultFirst
			}

			client, err := deps.GetGQLClient(ctx)
			if err != nil {
				return utils.NewToolResultError(fmt.Sprintf("failed to get GitHub GQL client: %v", err)), output, nil
			}

			// Resolve field filters by looking up the repo's issue fields so we can
			// coerce each value into the right typed slot on IssueFieldValueFilter.
			fieldFilters := []IssueFieldValueFilter{}
			if len(rawFilters) > 0 {
				fields, err := fetchIssueFields(ctx, client, owner, repo)
				if err != nil {
					return ghErrors.NewGitHubGraphQLErrorResponse(ctx, "failed to look up issue fields for field_filters", err), output, nil
				}
				fieldFilters, err = resolveFieldFilters(rawFilters, fields)
				if err != nil {
					return utils.NewToolResultError(err.Error()), output, nil
				}
			}

			vars := map[string]any{
				"owner":            githubv4.String(owner),
				"repo":             githubv4.String(repo),
				"states":           states,
				"orderBy":          githubv4.IssueOrderField(orderBy),
				"direction":        githubv4.OrderDirection(direction),
				"first":            githubv4.Int(*paginationParams.First),
				"issueFieldValues": fieldFilters,
			}

			if paginationParams.After != nil {
				vars["after"] = githubv4.String(*paginationParams.After)
			} else {
				// Used within query, therefore must be set to nil and provided as $after
				vars["after"] = (*githubv4.String)(nil)
			}

			// Ensure optional parameters are set
			if hasLabels {
				// Use query with labels filtering - convert string labels to githubv4.String slice
				labelStrings := make([]githubv4.String, len(labels))
				for i, label := range labels {
					labelStrings[i] = githubv4.String(label)
				}
				vars["labels"] = labelStrings
			}

			if hasSince {
				vars["since"] = githubv4.DateTime{Time: sinceTime}
			}

			issueQuery := getIssueQueryType(hasLabels, hasSince)
			// The list_issues query references the issue_fields-gated IssueFieldValueFilter
			// input type unconditionally, so we always opt into the feature via header. This
			// is a no-op once the flags are globally rolled out.
			ctxWithFeatures := ghcontext.WithGraphQLFeatures(ctx, "issue_fields", "repo_issue_fields")
			issueFieldsErr := client.Query(ctxWithFeatures, issueQuery, vars)

			var resp MinimalIssuesResponse
			var isPrivate bool
			if issueFieldsErr == nil {
				resp = convertToMinimalIssuesResponse(issueQuery.GetIssueFragment())
				isPrivate = issueQuery.GetIsPrivate()
			} else {
				if len(fieldFilters) > 0 || !isUnsupportedListIssuesIssueFieldsError(issueFieldsErr) {
					return ghErrors.NewGitHubGraphQLErrorResponse(
						ctx,
						"failed to list issues",
						issueFieldsErr,
					), output, nil
				}

				issueQueryWithoutFieldValues := getIssueQueryTypeWithoutFieldValues(hasLabels, hasSince)
				varsWithoutFieldValues := make(map[string]any, len(vars)-1)
				for name, value := range vars {
					if name != "issueFieldValues" {
						varsWithoutFieldValues[name] = value
					}
				}
				if fallbackErr := client.Query(ctx, issueQueryWithoutFieldValues, varsWithoutFieldValues); fallbackErr != nil {
					return ghErrors.NewGitHubGraphQLErrorResponse(
						ctx,
						"failed to list issues",
						fmt.Errorf("issue-fields query failed: %w; fallback query failed: %w", issueFieldsErr, fallbackErr),
					), output, nil
				}

				resp = convertToMinimalIssuesResponseWithoutFieldValues(issueQueryWithoutFieldValues.getIssueFragmentWithoutFieldValues())
				isPrivate = issueQueryWithoutFieldValues.GetIsPrivate()
			}

			filtered := false
			var payload any = resp
			if len(input.Fields) > 0 {
				filteredIssues, err := filterEachField(resp.Issues, input.Fields)
				if err != nil {
					return utils.NewToolResultErrorFromErr("failed to filter issues", err), output, nil
				}
				payload = map[string]any{
					"issues":     filteredIssues,
					"totalCount": resp.TotalCount,
					"pageInfo":   resp.PageInfo,
				}
				filtered = true
			}

			r, err := json.Marshal(payload)
			if err != nil {
				return utils.NewToolResultErrorFromErr("failed to marshal response", err), output, nil
			}

			recordFieldsUsageFor(ctx, deps, "list_issues", resp, filtered, len(r))

			result := utils.NewToolResultText(string(r))
			result = attachStaticIFCLabel(ctx, deps, result, ifc.LabelListIssues(isPrivate))
			return result, structuredListIssuesOutput(resp, input.Fields), nil
		},
		normalizeTypedReadArguments([]string{"state", "orderBy", "direction"}, true),
	)
	return st
}

// rawFieldFilter is the user-supplied {field_name, value} pair before type resolution.
type rawFieldFilter struct {
	Name  string
	Value string
}

// resolveFieldFilters matches each raw filter against a known field definition and
// coerces the value into the right typed slot on IssueFieldValueFilter. Matching is
// case-insensitive on field name; option names are also matched case-insensitively for
// single-select fields.
func resolveFieldFilters(rawFilters []rawFieldFilter, fields []IssueField) ([]IssueFieldValueFilter, error) {
	byName := make(map[string]IssueField, len(fields))
	knownNames := make([]string, 0, len(fields))
	for _, f := range fields {
		byName[strings.ToLower(f.Name)] = f
		knownNames = append(knownNames, f.Name)
	}

	out := make([]IssueFieldValueFilter, 0, len(rawFilters))
	for _, rf := range rawFilters {
		field, ok := byName[strings.ToLower(rf.Name)]
		if !ok {
			return nil, fmt.Errorf("field_filters: unknown field %q. Known fields: %s", rf.Name, strings.Join(knownNames, ", "))
		}

		filter := IssueFieldValueFilter{FieldName: githubv4.String(field.Name)}
		switch field.DataType {
		case "SINGLE_SELECT":
			// Validate the option name against the field's options so we fail fast
			// with a useful error instead of an opaque GraphQL one.
			var matched string
			for _, o := range field.Options {
				if strings.EqualFold(o.Name, rf.Value) {
					matched = o.Name
					break
				}
			}
			if matched == "" {
				optionNames := make([]string, 0, len(field.Options))
				for _, o := range field.Options {
					optionNames = append(optionNames, o.Name)
				}
				return nil, fmt.Errorf("field_filters: %q is not a valid option for %q. Valid options: %s", rf.Value, field.Name, strings.Join(optionNames, ", "))
			}
			v := githubv4.String(matched)
			filter.SingleSelectOptionValue = &v
		case "TEXT":
			v := githubv4.String(rf.Value)
			filter.TextValue = &v
		case "DATE":
			if _, err := time.Parse("2006-01-02", rf.Value); err != nil {
				return nil, fmt.Errorf("field_filters: %q is not a valid date for %q (expected YYYY-MM-DD): %s", rf.Value, field.Name, err.Error())
			}
			v := githubv4.String(rf.Value)
			filter.DateValue = &v
		case "NUMBER":
			n, err := strconv.ParseFloat(rf.Value, 64)
			if err != nil {
				return nil, fmt.Errorf("field_filters: %q is not a valid number for %q: %s", rf.Value, field.Name, err.Error())
			}
			v := githubv4.Float(n)
			filter.NumberValue = &v
		default:
			return nil, fmt.Errorf("field_filters: field %q has unsupported data_type %q", field.Name, field.DataType)
		}
		out = append(out, filter)
	}
	return out, nil
}

// parseISOTimestamp parses an ISO 8601 timestamp string into a time.Time object.
// Returns the parsed time or an error if parsing fails.
// Example formats supported: "2023-01-15T14:30:00Z", "2023-01-15"
func parseISOTimestamp(timestamp string) (time.Time, error) {
	if timestamp == "" {
		return time.Time{}, fmt.Errorf("empty timestamp")
	}

	// Try RFC3339 format (standard ISO 8601 with time)
	t, err := time.Parse(time.RFC3339, timestamp)
	if err == nil {
		return t, nil
	}

	// Try simple date format (YYYY-MM-DD)
	t, err = time.Parse("2006-01-02", timestamp)
	if err == nil {
		return t, nil
	}

	// Return error with supported formats
	return time.Time{}, fmt.Errorf("invalid ISO 8601 timestamp: %s (supported formats: YYYY-MM-DDThh:mm:ssZ or YYYY-MM-DD)", timestamp)
}
