import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import test from "node:test";
import { fingerprintOf, fingerprintOfSkill } from "./fingerprint.mjs";
import { publish, rewriteSkillPaths } from "./publish.mjs";

const SKILL = resolve(import.meta.dirname, "..");

function gallery() {
  const repo = mkdtempSync(join(tmpdir(), "anatomy-gallery-"));
  mkdirSync(join(repo, "figures"));
  mkdirSync(join(repo, "scripts"));
  writeFileSync(join(repo, "scripts", "validate.mjs"), "");
  return repo;
}

test("the fingerprint matches the gallery's algorithm", () => {
  assert.equal(fingerprintOf([["kit/a.mjs", "1"], ["kit/b.mjs", "2"], ["scripts/inline-kit.mjs", "3"]]), fingerprintOf([["kit/b.mjs", "2"], ["scripts/inline-kit.mjs", "3"], ["kit/a.mjs", "1"]]));
  assert.equal(fingerprintOf([["kit/a.mjs", "1"], ["kit/b.mjs", "2"], ["scripts/inline-kit.mjs", "3"]]), "sha256:a249319b0f2a8db4899fbb430c782c55b7699df73809c5c0e4c07495c72eae8c");
  assert.match(fingerprintOfSkill(SKILL), /^sha256:[0-9a-f]{64}$/);
});

test("skill paths are rewritten to the gallery's .skill link, and nothing else", () => {
  const source = "/work/fig";
  const text = 'import * as k from "../../kit/iso-kit.mjs";\nimport { kitScript } from "../../scripts/inline-kit.mjs";\nimport "./live.mjs";\nconst x = "/2";';
  const { text: out, outside } = rewriteSkillPaths(text, { fromDir: join(SKILL, "examples", "x"), toDir: "/g/figures/x/src", source: join(SKILL, "examples", "x"), skill: SKILL, skillLink: "/g/.skill" });
  assert.deepEqual(outside, []);
  assert.match(out, /from "\.\.\/\.\.\/\.\.\/\.skill\/kit\/iso-kit\.mjs"/);
  assert.match(out, /from "\.\.\/\.\.\/\.\.\/\.skill\/scripts\/inline-kit\.mjs"/);
  assert.match(out, /import "\.\/live\.mjs"/);
  assert.match(out, /"\/2"/);
  const away = rewriteSkillPaths('import "../../elsewhere/x.mjs";', { fromDir: source, toDir: "/g/figures/x/src", source, skill: SKILL, skillLink: "/g/.skill" });
  assert.deepEqual(away.outside, ["../../elsewhere/x.mjs"]);
});

test("publishing copies only the source, under the author, and it rebuilds byte for byte", () => {
  const repo = gallery();
  try {
    const { dest, figure } = publish({ source: join(SKILL, "examples", "dial-indicator"), into: repo, id: "dial-indicator", title: "Dial indicator", prompt: "/anatomy a dial indicator", author: "Octo-Cat", agent: "Codex", license: "MIT", build: "build.mjs", tags: [], date: "2026-10-12", noPreview: true });
    assert.equal(dest, join(repo, "figures", "octo-cat", "dial-indicator"));
    assert.equal(figure.author, "Octo-Cat");
    assert.ok(!existsSync(join(dest, "src", "dial-indicator.html")) && !existsSync(join(dest, "src", "dial-indicator-light.html")) && !existsSync(join(dest, "poster.png")), "no built pages or poster are left");
    assert.equal(figure.kind, "SVG");
    assert.equal(figure.skill.kit, fingerprintOfSkill(SKILL));
    assert.deepEqual(figure.build, [["src/build.mjs", "--light"], ["src/build.mjs"]]);
    assert.deepEqual(figure.pages, { dark: "src/dial-indicator.html", light: "src/dial-indicator-light.html" });
    for (const command of figure.build) assert.equal(spawnSync(process.execPath, command, { cwd: dest }).status, 0);
    for (const page of ["dial-indicator.html", "dial-indicator-light.html"]) assert.ok(readFileSync(join(dest, "src", page)).equals(readFileSync(join(SKILL, "examples", "dial-indicator", page))), page);
    assert.ok(existsSync(join(repo, ".skill", "kit", "iso-kit.mjs")));
    assert.throws(() => publish({ source: join(SKILL, "examples", "dial-indicator"), into: repo, id: "dial-indicator", title: "x", prompt: "x", author: "octo-cat", agent: "Codex", license: "MIT", build: "build.mjs", tags: [], noPreview: true }), /already exists/);
  } finally {
    rmSync(repo, { recursive: true, force: true });
  }
});

test("publishing refuses a folder that is not a gallery clone", () => {
  const empty = mkdtempSync(join(tmpdir(), "not-gallery-"));
  try {
    assert.throws(() => publish({ source: join(SKILL, "examples", "dial-indicator"), into: empty, id: "x", title: "x", prompt: "x", author: "x", agent: "Codex", license: "MIT", build: "build.mjs", tags: [], noPreview: true }), /doesn't look like a clone of anatomy-community/);
  } finally {
    rmSync(empty, { recursive: true, force: true });
  }
});

import { submitPlan } from "./publish.mjs";

test("--submit: people who can push get a branch; everyone else a fork made for them", () => {
  const owner = submitPlan({ login: "wheresryan22", canPush: true, upstream: "wheresryan22/anatomy-community", author: "wheresryan22", id: "token-bucket", title: "Token bucket" });
  assert.equal(owner.target, "wheresryan22/anatomy-community");
  assert.ok(!owner.steps.some((s) => s.gh?.[1] === "fork"));
  assert.deepEqual(owner.steps.at(-1).pr, { repo: "wheresryan22/anatomy-community", head: "figure/token-bucket", title: "Add Token bucket" });
  const guest = submitPlan({ login: "Octo-Cat", canPush: false, upstream: "wheresryan22/anatomy-community", author: "Octo-Cat", id: "token-bucket", title: "Token bucket" });
  assert.equal(guest.target, "Octo-Cat/anatomy-community");
  assert.deepEqual(guest.steps[0].gh, ["repo", "fork", "wheresryan22/anatomy-community", "--clone=false"]);
  assert.equal(guest.steps.at(-1).pr.head, "Octo-Cat:figure/token-bucket");
  assert.ok(guest.steps.some((s) => s.git?.[0] === "add" && s.git.at(-1) === "figures/octo-cat/token-bucket"), "only the figure's folder is added");
});
